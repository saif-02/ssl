<?php
    include('include/common_functions.php');
    $common = new commonFunctions();
    $connect = $common->connect();

    if (isset($_POST['Requestfor'])) 
    {
        $requestfor = $_POST['Requestfor'];

        
     if ($requestfor == "insertroles") 
        {
             $roleis= $_POST['roles'];
              $sql1 = "delete  from role_assigned where Roleid='".$roleis."'";
             $res1=mysqli_query($connect, $sql1);
             $menuid= implode(',',$_POST['menus']);
             $mid=explode(',',$menuid);
                // echo count($cit_expl);
            for ($i=0;$i<count($mid);$i++){
                $menus=$mid[$i];
             $sql = "INSERT INTO role_assigned(Roleid,MainMenuid) VALUES ('".$roleis."','".$menus."')";
             $res=mysqli_query($connect, $sql);
           
             }
     
             if (isset($res)) {
                 $response= '1';
             }
             else
             {
                 $response= '2';
             } 
             echo $response;
            }

         if ($requestfor == "insertrolemaster") 
        {
             $rolename= $_POST['rolename'];
            
             $sql = "INSERT INTO all_role(Rolename) VALUES ('".$rolename."')";
             $res=mysqli_query($connect, $sql);
          
             if (isset($res)) {
                 $response= '1';
             }
             else
             {
                 $response= '2';
             } 
             echo $response;
        }

     if ($requestfor == "deleteroles") 
            {
                 $roleis= $_POST['roles'];
                 $sql11 = "select count(*) as cnt  from all_users where roleid='".$roleis."'";
                 $res=mysqli_query($connect, $sql11);
                 while($row = $res->fetch_assoc()) {
                        $rescnt=$row["cnt"];
                    }
                if($rescnt<1)
                {
                  $sql1 = "delete  from all_role where Roleid='".$roleis."'";
                 $res=mysqli_query($connect, $sql1);

                 $sql2 = "delete  from role_assigned where Roleid='".$roleis."'";
                 $res2=mysqli_query($connect, $sql2);
         
                 if (isset($res)) {
                     $response= '1';
                 }
                 else
                 {
                     $response= '2';
                 } 
             }else
             {
                $response= '3';
             }

                 echo $response;
            }

            
          if ($requestfor == "delete_fileinfo") 
            {
                 $rid= $_POST['rid'];
          
                  $sql1 = "delete  from speaker_documents where id='".$rid."'";
                 $res=mysqli_query($connect, $sql1);
                 $response= '1';
                 
                 if (isset($res)) {
                     $response= '1';
                 }
                 else
                 {
                     $response= '2';
                 } 
        
                 echo $response;
        }

        if ($requestfor == "delete_fileinfo_new_speaker") 
            {
                 $rid= $_POST['rid'];
          
                  $sql1 = "delete  from new_speaker_documents where id='".$rid."'";
                 $res=mysqli_query($connect, $sql1);
                 $response= '1';
                 
                 if (isset($res)) {
                     $response= '1';
                 }
                 else
                 {
                     $response= '2';
                 } 
        
                 echo $response;
        }

        if ($requestfor == "fetch_noteval") 
            {
                 $roleis= $_POST['row_id'];
                 $sql11 = "select notes  from speaker_notes where id='".$roleis."'";
                 $res=mysqli_query($connect, $sql11);
                 while($row = $res->fetch_assoc()) {
                        $rescnt=$row["notes"];
                    }

                 echo $rescnt;
            }

             if ($requestfor == "fetch_noteval_new") 
            {
                 $roleis= $_POST['row_id'];
                 $sql11 = "select notes  from new_speaker_notes where id='".$roleis."'";
                 $res=mysqli_query($connect, $sql11);
                 while($row = $res->fetch_assoc()) {
                        $rescnt=$row["notes"];
                    }

                 echo $rescnt;
            }

            if ($requestfor == "fetch_EP_noteval") 
            {
                 $roleis= $_POST['row_id'];
                 $sql11 = "select notes  from event_presentation_notes where id='".$roleis."'";
                 $res=mysqli_query($connect, $sql11);
                 while($row = $res->fetch_assoc()) {
                        $rescnt=$row["notes"];
                    }

                 echo $rescnt;
            }

              if ($requestfor == "delete_fileinfo_new_sponsor") 
            {
                 $rid= $_POST['rid'];
          
                  $sql1 = "delete  from new_sponsor_documents where id='".$rid."'";
                 $res=mysqli_query($connect, $sql1);
                 $response= '1';
                 
                 if (isset($res)) {
                     $response= '1';
                 }
                 else
                 {
                     $response= '2';
                 } 
        
                 echo $response;
        }

          if ($requestfor == "fetch_noteval_new_sponsor") 
            {
                 $roleis= $_POST['row_id'];
                 $sql11 = "select notes  from new_sponsor_notes where id='".$roleis."'";
                 $res=mysqli_query($connect, $sql11);
                 while($row = $res->fetch_assoc()) {
                        $rescnt=$row["notes"];
                    }

                 echo $rescnt;
            }

             if ($requestfor == "delete_sponsor_fileinfo") 
            {
                 $rid= $_POST['rid'];
          
                  $sql1 = "delete  from sponsor_documents where id='".$rid."'";
                 $res=mysqli_query($connect, $sql1);
                 $response= '1';
                 
                 if (isset($res)) {
                     $response= '1';
                 }
                 else
                 {
                     $response= '2';
                 } 
        
                 echo $response;
        }

        if ($requestfor == "fetch_noteval_sponsor") 
            {
                 $roleis= $_POST['row_id'];
                 $sql11 = "select notes  from sponsor_notes where id='".$roleis."'";
                 $res=mysqli_query($connect, $sql11);
                 while($row = $res->fetch_assoc()) {
                        $rescnt=$row["notes"];
                    }

                 echo $rescnt;
            }

            if ($requestfor == "delete_new_sponsership") 
            {
                 $rid= $_POST['rid'];
          
                  $sql1 = "delete  from new_sponsorship_type where id='".$rid."'";
                 $res=mysqli_query($connect, $sql1);
                 $response= '1';
                 
                 if (isset($res)) {
                     $response= '1';
                 }
                 else
                 {
                     $response= '2';
                 } 
        
                 echo $response;
        }


            if ($requestfor == "delete_sponsership_type") 
            {
                 $rid= $_POST['rid'];
          
                  $sql1 = "delete  from sponsor_sponsorship_type where id='".$rid."'";
                 $res=mysqli_query($connect, $sql1);
                 $response= '1';
                 
                 if (isset($res)) {
                     $response= '1';
                 }
                 else
                 {
                     $response= '2';
                 } 
        
                 echo $response;
         }

          if ($requestfor == "get_sponsorship_val") 
            {
                 $sponsor_type_id= $_POST['sponsor_type_id'];
                 $committed_unit= $_POST['committed_unit'];

                 $sql11 = "select cost_per_unit  from all_sponsor_types where id='".$sponsor_type_id."'";
                 $res=mysqli_query($connect, $sql11);
                 while($row = $res->fetch_assoc()) {
                        $cost_per_unit=$row["cost_per_unit"];
                    }
                $total_val=$committed_unit*$cost_per_unit;

                 echo $total_val;
            }

             if ($requestfor == "fetch_noteval_master") 
            {
                 $roleis= $_POST['row_id'];
                 $sql11 = "select notes  from master_notes where id='".$roleis."'";
                 $res=mysqli_query($connect, $sql11);
                 while($row = $res->fetch_assoc()) {
                        $rescnt=$row["notes"];
                    }

                 echo $rescnt;
            }

            if ($requestfor == "fetch_noteval_new_colboration") 
            {
                 $roleis= $_POST['row_id'];
                 $sql11 = "select notes  from new_coloboration_notes where id='".$roleis."'";
                 $res=mysqli_query($connect, $sql11);
                 while($row = $res->fetch_assoc()) {
                        $rescnt=$row["notes"];
                    }

                 echo $rescnt;
            }

            if ($requestfor == "fetch_EP_colb_noteval") 
            {
                 $roleis= $_POST['row_id'];
                 $sql11 = "select notes  from event_presentation_coloboration_notes where id='".$roleis."'";
                 $res=mysqli_query($connect, $sql11);
                 while($row = $res->fetch_assoc()) {
                        $rescnt=$row["notes"];
                    }

                 echo $rescnt;
            }
    }

    
?>