<?php
  include("./include/html_codes.php");
  require("include/mysqli_connect.php");

   if(trim(base64_decode($_GET['tk'])) == ''){
  header('Location: 404.php');
  }else
  {
  $token = trim(base64_decode($_GET['tk']));
  $speakerid = trim(base64_decode($_GET['sp']));
    $all_speakers_array = $common->fetch_event_presentation_by_ep_id(base64_decode($_GET['tk'])); 
    foreach($all_speakers_array as $all_speakers){
    $ep_id = $all_speakers['ep_id'];
    $presentation_topic = $all_speakers['presentation_topic'];
    $opportunity_type = $all_speakers['opportunity_type'];
    $location = $all_speakers['location'];
    $abstract = $all_speakers['abstract'];
    $start_time = $all_speakers['start_time'];
    $end_time = $all_speakers['end_time'];
    $topic_owner = $all_speakers['topic_owner'];
    $business_objective = $all_speakers['business_objective'];
    $speakers_id = $all_speakers['speakers_id'];
    $speakers_arr =$speakers = explode(",",$all_speakers['speakers_id']);
    $event_date = $all_speakers['event_date'];
    $event_id = $all_speakers['event_id'];

    $tenant_id=  $common->get_tenant_id_from_eventid($event_id);
    $fetch_tenant = mysqli_query($connect,"SELECT tenant_name FROM `all_tenants` WHERE `id` = '".$tenant_id."' ");
    $res_tenant = mysqli_fetch_array($fetch_tenant);
    $tenant_name = $res_tenant['tenant_name'];

    if($event_date!=null)
      {
          $event_date=date('d-F-Y', strtotime($all_speakers['event_date']));
      }else
      {
          $date1=date("Y-m-d");
          $event_date=date('d-F-Y', strtotime($date1));
      }
  }
      $event_sql = mysqli_query($connect,"SELECT * FROM all_events WHERE id=".$event_id);
       $event_row = mysqli_fetch_array($event_sql);
       $event_url_structure = $event_row['event_name'];
       $user_email =  $_SESSION['user_email'];
        if( strlen($event_url_structure ) > 40 ) 
        {
          $event_url_structure = substr($event_row['event_name'], 0, 40 ) . '...';
        }

    $fetch_speaker = mysqli_query($connect,"SELECT * FROM all_speakers WHERE id=".$speakerid);
    $speaker_row = mysqli_fetch_array($fetch_speaker);
    $speaker_name = $speaker_row['speaker_name'];

$speakers_array = $common->fetch_all_speaker_for_event_presentation();

$fetch_sp_ppt = $common->fetch_all_ep_documents(base64_decode($_GET['tk']));

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="images/favicon.ico">
<title>Speaker Engage</title>
<link href="css/event/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" href="css/event/css/custom.css">
<link rel="stylesheet" href="css/event/css/croppie.css">
<link rel="stylesheet" href="apply-to-speak/css/custom.css">
<link href="css/dropzone.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="css/custom_aby.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
   <script src="js/custom.js"></script>
<!--<link href="//use.fontawesome.com/releases/v5.1.0/css/all.css" rel="stylesheet">-->
<!------ Include the above in your HEAD tag ---------->
 
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css'>
<style>
  .input-group {
    width: 100%;
  }
  .borderForm .form-control {
    border-radius: 0px;
  }
  .dropzone.dz-clickable span {
      font-size: 14px;
      color: #5a5a5a;
      margin-left: 50px;
  }
  .dz-default.dz-message {
    margin-top: 44px !important;
  }
  .datepicker {
    margin-top: -10px;
  }
  .dropzone.dz-clickable span::before {
    left: -10px;
      margin-left: -40px;
      width: 35px;
      top: -13px;
      background: url(../images/doc.png) no-repeat center center;
      background-size: cover !important;
      height: 45px;
      opacity: 0.7;
  }
  .dropzone {
    border: 1px solid rgba(112, 112, 112, 0.35); 
  }
  .dropzone.dz-clickable::before {
    border: 0px;
  }
  .sp_opertunity .table>thead>tr>th:nth-child(3), .sp_opertunity .table>thead>tr>th:nth-child(4) {
    text-align: left;
}
  table.dataTable.listtable .form-control, .listtable .multiselect.dropdown-toggle.btn.btn-default {
    margin-bottom: 0px !important;
  }
  .listtable .multiselect.dropdown-toggle.btn.btn-default {
    top: 1px;
  }
  .table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    vertical-align: middle;
  }
  .table>tbody>tr>td {
    padding-top: 15px;
    padding-bottom: 15px;
  }
  .dltImg {
    position: absolute;
      right: 10px;
      top: 10px;
      color: red;
      width: 40px;
      height: 40px;
      float: left;
      font-size: 18px;
      background: rgba(255, 255, 255, 0.82);
      text-align: center;
      line-height: 40px;
      border-radius: 40px;
  }
  .checkbox input[type=checkbox], .checkbox-inline input[type=checkbox], .radio input[type=radio], .radio-inline input[type=radio]{margin-top:-15px;}
  .blue-n-color, h3{color:#0283A3;}
  h3{font-size:16px;}
  .bdr-light{border:solid 1px #707070; background:#fff; min-height:90px;}
  .bdr-light .form-group{margin-bottom:10px !important;}
  .upload-btn-wrapper {
  position: relative;
  overflow: hidden;
  display: inline-block;
}
.btn-success{background-color: #0283A3 !important;
    border-color: #0283A3 !important; border-radius:0 !important;}
.btn1 {
  border: none;
  color: black;
  background-color: white;
  
  border-radius:0;
  box-shadow:none;
  font-size: 20px;
  font-weight: bold;
}

.upload-btn-wrapper input[type=file] {
  font-size: 100px;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
}
.collabrationSec .table tr p {
  font-size: 12px;
}
@media (min-width: 768px){
#search-resource .modal-dialog {
    width: 70%;
    margin: 30px auto;
}

}
@media (max-width: 768px){
  .collecteventpresent {
  padding-left: 15px !important;
    padding-right: 15px !important;
}
}

  #search-resource .modal-title{    background: #007db7;    color: #fff;    text-align: left;    padding: 15px;}
  #search-resource .modal-header{padding: 0; border:none;}
  #search-resource  .modal-header .close {
    margin-top: 8px;
    margin-right: 5px;
}
#datatable_length, #datatable_info, #datatable_paginate{display: none !important}
#datatable_filter{width:100% !important;}
.dataTables_filter label{width:100% !important; text-align: left; font-size: 0 !important;}
.dataTables_filter input{width: 100% !important; font-size: 16px !important; background: url(images/search.png) no-repeat;     padding-left: 18px;        background-position: 2px center;}
table.dataTable thead .sorting_desc, table.dataTable thead .sorting_asc{background: none !important;}
.form_datetime {
    padding-left: 37px;
    position: relative;
    background: url(images/calendar-with-a-clock-time-tools_blue.png) no-repeat left center;
    background-position-x:6px ;
    margin-bottom: 5px !important;
}
.collecteventpresent {
  padding-left: 50px;
  padding-right: 50px;
}
.collecteventpresent header h3 {
      margin: 0;
    color: #fff;
    font-size: 18px;
}
aside.control-sidebar {
  display: none;
}
h1 {
  font-size: 42px;
}
</style>
<!-- Content Wrapper. Contains page content -->
<div class="collecteventpresent">
<header class="navbar-fixed-top">
    <div class="container">
      <div class="row">
        <div class="pull-left">
          <h3><?php echo 'Organization Name: '. $tenant_name;?> | <?php echo 'Event Name: '. $event_url_structure;?></h3>
          
        </div>
      <!--  <div class="rightlogo pull-right">
            <img src="images/ideagenlogo.png">
          </div> -->
        <!-- <div class="pull-right">
          <a href="#" class="btn btn-yellow">Contact Us</a>
        </div> -->
      </div>
    </div>  
  </header>
<div class="content-wrapper innerpageSec formPage container" style="margin-top:20px !important;padding: 0px;">
   <!-- Content Header (Page header) -->
  
   <div class="clearfix"></div>
   <div class="info-collect-success" style="text-align: center;color: green;font-size: 18px;padding: 19px;display:none;margin-top: 50px;">
  <p>Thank you for completing your profile.<br>If you have any questions, please send an email: <?php echo 'support@speakerengage.com'; //echo $user_email;?></p>
      </div>
   <!-- Main content -->
   <section class="content pad-5">
    <br>
     <h1 class="font-sem-bold text-center">Review Your Presentation Details</h1> 
     <p class="text-center font-sem-bold" style="margin-top: 15px;display:none;">If you have any questions, please send an email: < Email Address ></p>
    <div class="speakerDashboard createPages">
      <div class="">
          <div class="col-xs-12 text-center">
         
       </div>
      <!--  <div class="col-xs-12 col-md-6 text-right "> 
        <button type="button" class="btn btn-success createBtn" name="create_speaker_top"  id="create_speaker_top" style="display:inline-block; margin-top: 11px;margin-right: 15px;">Save</button>

        <button type="button" class="btn btn-saveExit createBtn" name=""  id="" style="display:inline-block; margin-top: 11px;margin-right: 15px;padding-left: 12px;text-align: center;background: #FD6F61;color: #fff;">Save & Exit</button>
      </div> -->
      </div>
    
      <!-- Small boxes (Stat box) -->
      <div class="">
   <div class="clearfix"></div>
      <!-- Small boxes (Stat box) -->
      <div class="borderForm">
            <section style="padding-bottom: 1px;padding-top: 0px;">

               <form method="post" action="include/form_submits.php" id="edit_event_presentation">
                  <div class="card-box" style="padding-top: 20px;margin: 20px;border: 1px solid #cacaca;">
                    
            <div class="box box-primary" style="background:none; box-shadow:none;">
        <div class="col-xs-12">
                
                     <div class="row">
                      <div class="col-md-12">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                               <label>Presentation Name</label> 
                               <input type="text" class="form-control required" placeholder="Presenting Topic" required name="p_topic" id="p_topic" value="<?php echo $presentation_topic; ?>" disabled/>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="row">
                              <div class="col-md-6">
                                <div class="form-group">
                                   <label>Presentation Type</label> 
                                   <select type="text" class="form-control" id="opportunity_type" name="opportunity_type" disabled>
                                    <option value="">Select Type</option>
                                    <?php  
                    
                                    $all_speakers_types_array = $common->fetch_all_speaker_types_asc($event_id);
                                    foreach($all_speakers_types_array as $all_speakers_type){
                                          $speaker_type_name = $all_speakers_type['speaker_type_name'];
                                           $sel = "";
                                      if ($opportunity_type==$all_speakers_type['id']) $sel = " selected ";
                                          echo "<option value='".$all_speakers_type['id']."' ".$sel.">".$speaker_type_name."</option>";
                                        }
                                      ?>
                                   </select>
                                </div>
                              </div>
                              <div class="col-md-6">
                                <div class="form-group">
                                   <label>Topic Owner</label> 
                                   <input type="text" class="form-control required" name="topic_owner" id="topic_owner" value="<?php echo $topic_owner; ?>" required disabled/>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div class="row">
                          <div class="col-md-4">
                            <div class="form-group">
                               <label>Location</label> 
                               <input type="text" class="form-control" name="location" id="location" placeholder="Location Name" value="<?php echo $location; ?>" required disabled/>
                            </div>
                          </div>
                          <div class="col-md-8">
                            <div class="row">
                              <div class="col-md-3">
                                <div class="form-group" >
                                    <label>Date</label> 
                                    

                                      <div  class="input-group date " data-date-format="mm-dd-yyyy">
                                        <input class="form-control form_datetime" type="text"  name="event_date" id="event_date" value="<?php echo date('d-M-Y', strtotime($event_date)); ?>" required disabled/>
                                        <span class="input-group-addon" ><i class="glyphicon glyphicon-calendar"></i></span>
                                    </div>

                                  </div>
                              </div>
                              <div class="col-md-3">
                                <div class="form-group">
                                   <label>Start Time</label> 
                                   <div class="input-group timepicker"  style="margin-bottom: 5px;">
                                     <span class="input-group-append input-group-addon"></span> <input class="form-control time" name="start_time" id="start_time" value="<?php echo $start_time; ?>" required disabled/>
                                    </div>
                                </div>
                              </div>
                              <div class="col-md-3">
                                <div class="form-group">
                                   <label>End Time</label> 
                                   <div class="input-group timepicker" style="margin-bottom: 5px;">
                                     <span class="input-group-append input-group-addon"></span> <input class="form-control time" name="end_time" id="end_time" value="<?php echo $end_time; ?>" required disabled/>
                                      <span class="error edtime" id="edtime" style="font-size: 11px;color: red;position: absolute;bottom: -25px;left: 0;height: 26px;line-height: 14px;"></span>
                                    </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          

                        </div>
                        <div class="form-group">
                    <label>Speaker Name</label> 
                 </div>
                  <div class="clearfix"></div>
                  <div class="container-fluid">
             <?php

                $speaker_details = mysqli_query($connect,"select ep.*,(select group_concat(speaker_name separator ', ') from all_speakers als where id in (select speaker_id from event_agenda_speakers where ep_id='$ep_id')) as speaker_name from event_presentation ep where ep.ep_id='$ep_id'");

                         $event_row = mysqli_fetch_array($speaker_details);
                         $speaker_name = $event_row['speaker_name'];
                          echo "
                                      <p>".$speaker_name."</p>
                                    ";
                            ?>
                    </div>
                        


                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                           <label>Abstract</label> 
                           <textarea type="text" class="form-control" placeholder="Abstract" required name="abstract" id="abstract" style="min-height: 100px;"><?php echo $abstract; ?></textarea>
                        </div>
                      </div>

                      <div class="col-md-12">
                        <div class="form-group">
                           <label>Business Objectives</label> 
                           <textarea type="text" class="form-control" placeholder=""  name="bussiness_objective" id="bussiness_objective" style="min-height: 100px;"><?php echo $business_objective; ?></textarea>
                        </div>
                      </div>
                                   
                     </div>
   
                      
            </div>

            </div>
            
            <div class="container-fluid">
                <label>Upload Presentations</label> 
          </div>
            <div class="container-fluid">
            <div class="border-div" style="margin-bottom: 30px;padding: 0px 15px;" >
            <div class="row">
              <div class="box box-primary" id="ppt_main_div" style="background:none; box-shadow:none; padding-top: 15px;padding-bottom: 15px;">               
                      <div>
                        <div class="container-fluid"></div>
                        <?php $ppt_token = uniqid(); ?>
                           <div class="container-fluid document_upload_sec ">
                            <table   style="width: 100%;">
                              <thead>
                              <tr>
                                <th></th>
                                <th style="width: 100px;"></th>
                                <th style="width: 100px;"></th>
                              </tr>
                              </thead>
                              <tbody id="delete_docs_ep">
                                  <?php  
                                       if(count($fetch_sp_ppt) > 0){

                                          foreach ($fetch_sp_ppt as $ppt_data) {
                                             echo "<tr>
                                                <td><a class='linkurl'>".$ppt_data['file_name']."</a></td>
                                                <td> <a href='documents/".$ppt_data['file_name']."' class='download' download>Download</a></td>
                                               </tr>";     
                                                 // <td> <button type='button' class='btn delete dlt_ppt' id='".$ppt_data['id']."'>Delete</button></td>                                
                                          }
                                         }

                                       ?>
                              </tbody>
                            </table>

                            </div>
                     
                                <div class="clearfix"></div>
                                  <!-- <p style="padding-left: 15px; color: #007eb7;">Maximum allowed file size 100 MB</p> -->
                                  <div class="container-fluid" style="position: relative;">

                                    <div class="dropzone dz-clickable" id="dropzone_ppt" action="include/upload_event_presentation_docs.php?doc_token=<?php echo $ppt_token; ?>">                                       
                                    <div class="dz-default dz-message"><span>Drag and drop or <font style="color: rgba(0, 125, 183, 0.59);">browse files</font></span></div>
                                  </div>
                                  </div>                                
                    
                    
                    <div class="clearfix"></div>
                    <div class="container-fluid">

                      <button type="button" id="save_ppt" class="btn btnDownload pull-right" style="margin-top: 15px;">Upload</button>
                    </div>
                      </div><div class="clearfix"></div>
                  </div>      

            </div>
          </div>
          </div>
                     <div class="modal fade darkHeaderModal" id="addNote" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width: 100% !important;border-radius: 0px;">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><img src="images/cancel.png" width="20"></button>
                      <h4 class="modal-title " id="" style="margin-bottom: 0px;font-size: 18px;color: #fff;">Add New Note</h4>
                    </div>

                    <div class="modal-body">
                  <form>
                           <div class="row" id="">
                                 <div class="col-md-12 form-group">
                                                 <label class="blue-n-color"> WRITE YOUR NOTE</label> 
                                               <!--   <textarea class="form-control" placeholder="Start Typing.."  name="" id="up_name" value="" style="min-height: 160px;margin-bottom: 5px;"></textarea> -->
                                                 <div class="note-info" ><textarea id="dynamic_add_note_txt" class="form-control" placeholder="Start Typing.." style="min-height: 160px;margin-bottom: 5px;" name="speaker_note"> </textarea><div class="clearfix"></div></div>
                                      </div> 
                      
                                   </div>
                               

                              <div class="sendBtn text-right">
                                <button type="button" id="dynamic_add_note_btn" class="btn btn-success createBtn">Save</button>
                              <!--   <button type="button" id="" class="btn btn-success createBtn">Save</button> -->
                              </div>
                            
                             </form>
                              </div>
                          </div>
                        </div>
        </div>

                 <div class="modal fade darkHeaderModal" id="EditNote" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width: 100% !important;border-radius: 0px;">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><img src="images/cancel.png" width="20"></button>
                      <h4 class="modal-title " id="" style="margin-bottom: 0px;font-size: 18px;color: #fff;">Edit Note</h4>
                    </div>

                    <div class="modal-body">
                  <form>
                           <div class="row" id="">
                                 <div class="col-md-12 form-group">
                                                 <label class="blue-n-color"> WRITE YOUR NOTE</label> 
                                                 <div class="note-info"><textarea id="edit_note_txt" class="form-control" placeholder="Start Typing.." style="min-height: 160px;margin-bottom: 5px;" name="speaker_note"> </textarea><div class="clearfix"></div></div>
                                      </div> 
                      
                                   </div>
                               

                              <div class="sendBtn text-right">
                                <button type="button" id="edit_note_btn" onclick="save_EditNote();" class="btn btn-success createBtn">Save</button>
                              <!--   <button type="button" id="" class="btn btn-success createBtn">Save</button> -->
                              </div>
                            
                             </form>
                              </div>
                          </div>
                        </div>
                  </div>
                            
                     
                      <div style="margin-right: 15px;margin-left: 15px;margin-bottom: 15px;" class="collabrationSec">
                         <h3 class="innerH3 text-uppercase" style="margin-top: 20px;">A/V Needs</h3>

                        <a id="add_note_edit_speaker" style="float: right;margin-top: 0px !important;cursor:pointer;"><img src="images/add1.png" width="10" style="position: relative;top: -2px;"> &nbsp;<span class="font-sem-bold">Add New Note</span></a>
                            <div class="new_add_note">

                            </div>
                            
                             <div class="clearfix"></div>
                             <center><p id="note_added_status" style="color: green; display: none;" >Note added successfully!</p></center>
                             <div class="table-responsive">
                        <table class="table table-bordered table-responsive listtable " style="width:100%">
                          <tr>
                            <th ><p>Note</p></th>
                            <th style="min-width: 150px;"><p class="text-center">Date</p></th>
                            <th style="min-width: 150px;"><p class="text-center">Added By</p></th>
                            <th style="min-width: 50px;"><p class="text-center">Manage</p></th>
                          </tr>
                          <tbody id="old_notes">
                         
                             <?php              
                                $all_sponsor_types_array = $common->fetch_event_presentation_note_by_id($ep_id); 
                                     foreach($all_sponsor_types_array as $all_sponsor_types){
                           
                                        echo "<tr class='test'>
                                          <td><p>".$all_sponsor_types['notes']."</p></td>
                                          <td>".date('d-M-Y', strtotime($all_sponsor_types['created_at']))."</td>
                                          <td>".$all_sponsor_types['addedby']."</td>
                                          <td><button type='button' onClick='Assign_noteid(".$all_sponsor_types['id'].")' class='pull-left blue-n-color edit_note' style='background:none; border:none; box-shadow:none; '><img src='images/edit.png' alt='Edit' width='15' title='Edit'></button></td>
                                        </tr>";
                                     }
                                ?>
                          </tbody>
                        </table>
                        </div>
                      </div>

                       <div style="margin-right: 15px;margin-left: 15px;margin-bottom: 15px;" class="collabrationSec">
                        <h3 style="float: left;margin-top: 0px;padding-left: 0px;">Notes to Event Planner</h3> 
                        <a id="add_new_coloboration_note" style="float: right;margin-top: 0px !important;cursor:pointer;"><img src="images/add1.png" width="10" style="position: relative;top: -2px;"> &nbsp;<span class="font-sem-bold">Add New Note</span></a>
                            <div class="new_coloboration_add_note">

                            </div>
                            
                             <div class="clearfix"></div>
                             <center><p id="note_added_status" style="color: green; display: none;" >Note added successfully!</p></center>
                        <table class="table table-bordered table-responsive listtable " style="width:100%">
                          <tr>
                            <th ><p>Note</p></th>
                           <th style="min-width: 150px;"><p class="text-center">Date</p></th>
                            <th style="min-width: 150px;"><p class="text-center">Added By</p></th>
                            <th style="min-width: 50px;"><p class="text-center">Manage</p></th>
                          </tr>
                          <tbody id="old_coloboration_notes">
                         
                             <?php              
                                $all_sponsor_types_array = $common->fetch_event_presentation_coloboration_note_by_id($ep_id); 
                                     foreach($all_sponsor_types_array as $all_sponsor_types){
                           
                                        echo "<tr class='test'>
                                          <td><p>".$all_sponsor_types['notes']."</p></td>
                                          <td>".date('d-M-Y', strtotime($all_sponsor_types['created_at']))."</td>
                                          <td>".$all_sponsor_types['addedby']."</td>
                                          <td><button type='button' onClick='Assign_colo_noteid(".$all_sponsor_types['id'].")' class='pull-left blue-n-color edit_note' style='background:none; border:none; box-shadow:none; '><img src='images/edit.png' alt='Edit' width='15' title='Edit'></button></td>
                                        </tr>";
                                     }
                                ?>
                          </tbody>
                        </table>
                      </div>

              <div class="modal fade darkHeaderModal" id="addColoborationNote" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width: 100% !important;border-radius: 0px;">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><img src="images/cancel.png" width="20"></button>
                      <h4 class="modal-title " id="" style="margin-bottom: 0px;font-size: 18px;color: #fff;">Add New Note</h4>
                    </div>

                    <div class="modal-body">
                  <form>
                           <div class="row" id="">
                                 <div class="col-md-12 form-group">
                                                 <label class="blue-n-color"> WRITE YOUR NOTE</label> 
                                            
                                                 <div class="note-info"><textarea id="colb_note_txt" class="form-control" placeholder="Start Typing.." style="min-height: 160px;margin-bottom: 5px;" name="colb_note_txt"> </textarea><div class="clearfix"></div></div>
                                      </div> 
                      
                                   </div>
                               

                              <div class="sendBtn text-right">
                                <button type="button" id="dynamic_add_colb_note_btn" class="btn btn-success createBtn">Save</button>
                              </div>
                            
                             </form>
                              </div>
                          </div>
                        </div>
                  </div>

            <div class="modal fade darkHeaderModal" id="EditNote_coloboration" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width: 100% !important;border-radius: 0px;">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><img src="images/cancel.png" width="20"></button>
                      <h4 class="modal-title " id="" style="margin-bottom: 0px;font-size: 18px;color: #fff;">Edit Note</h4>
                    </div>

                    <div class="modal-body">
                  <form>
                           <div class="row" id="">
                                 <div class="col-md-12 form-group">
                                                 <label class="blue-n-color"> WRITE YOUR NOTE</label> 
                                                 <div class="note-info" style="padding-left:15px;padding-right:15px;"><textarea id="edit_colob_note_txt" class="form-control" placeholder="Start Typing.." style="min-height: 160px;margin-bottom: 5px;" name="edit_colob_note_txt"> </textarea><div class="clearfix"></div></div>
                                      </div> 
                      
                                   </div>
                               

                              <div class="sendBtn text-right">
                                <input type="hidden" id="hidden_colboration_noteid" name="hidden_colboration_noteid"/>
                                <button type="button" id="edit_note_btn_colobo" onclick="save_EditNote_colboration();" class="btn btn-success createBtn">Save</button>
                              <!--   <button type="button" id="" class="btn btn-success createBtn">Save</button> -->
                              </div>
                            
                             </form>
                              </div>
                          </div>
                        </div>
                  </div>

                      <div class="clearfix"></div>
                       <div class="">
                        <div class="col-xs-12 text-right">
                           <input type="hidden" name="action" value="request_info_event_presentation">
                           <input type="hidden" name="loggedin_userid" id="loggedin_userid" value="<?php echo $speakerid; ?>">
                           <input type="hidden" name="token" value="<?php echo $token; ?>">
                           <input type="hidden" name="uid" value="<?php echo $ep_id; ?>">
                            <input type="hidden" id="hidden_rowid" name="hidden_rowid"/>
                           <input type="hidden" id="hidden_noteid" name="hidden_noteid"/>
                            <input type="hidden" name="speakers_list" id="speakers_list">
                           <button type="submit" class="btn btnSubmit" name="edit_presentation"  id="edit_presentation" style="display:inline-block; margin-top: 20px;padding-right: 20px;"><img src="images/enter-arrow.png" style="width: 20px;margin-right: 5px;"> Submit</button>                           
                            <div class="clearfix"></div><br/>
                        </div>
                        <div class="clearfix"></div>
                     </div>
                  </div>
               </form>
            </section>
         </div>
      </div>
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <!-- /.row (main row) -->
   </section>
   <!-- /.content -->
</div>

<div class="modal fade" id="search-resource"  >
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="width: 100% !important;border-radius: 0px;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><img src="images/cancel.png" width="20"></button>
        <h4 class="modal-title" id="myModalLabel">Search From Database</h4>
      </div>

      <div class="modal-body">
            <table id="datatable" class="display" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th><!-- <input type="checkbox" name="select_all" value="1" id="example-select-all"> --></th>
                  <th>Speaker Name</th>
                  <th>Email</th>
                  <th>Comapny</th>
               
                </tr>
              </thead>
              <tbody style="text-align: left;">
                <?php
                 foreach($speakers_array as $resource){         
                  echo "<tr>
                          <td><input type='checkbox' name='selected_resource' value='".$resource['id']."' class='selected_resource'></td>
                          <td>".$resource['speaker_name']."</td>
                          <td>".$resource['email_id']."</td>
                          <td>".$resource['company']."</td>
                        </tr>";
                      }
                ?>
               
              </tbody>
            </table>

            <input type="button" name="resource_submit" id="resource_submit" class="btn btn-success" style="margin-top: 5px;" disabled="true" value="Add">
        </div>
    </div>
  </div>
</div>

  
  <?php all_speaker_footer(); ?>


       
        <link href="//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/build/css/bootstrap-datetimepicker.css" rel="stylesheet">
        <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js"></script>
        <script src="//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/src/js/bootstrap-datetimepicker.js"></script>
    
    <script  src="https://code.jquery.com/jquery-3.3.1.js" ></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/eonasdan-bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js'></script>
    <script src="js/dropzone.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
    <script type="text/javascript">
    var uploadedCount = 1;



    Dropzone.autoDiscover = false;
  //$('#save_ppt').prop('disabled', true);
        // $(document).ready(function(){

          // var c_uid = "<?php echo $current_uid; ?>";
          // alert(uid);
        $(".dropzone").dropzone({
            addRemoveLinks: true,
      
            removedfile: function(file) {
                var name = file.name;
                //var uid = c_uid;  
                 
                
                $.ajax({
                    type: 'POST',
                    url: 'include/upload.php',
                    data: {name: name,request: 2},
                    sucess: function(data){
                        console.log('success: ' + data);
            
                    }
                });
                var _ref;
                return (_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
            }
            });
        // });


    $( "input[type='number']" ).keypress(function( event ) {
      if ( event.which == 45  ||event.which==101) { // preventing minus key and 'e' key
       event.preventDefault();
      }
    });
  
    $('#create_speaker').click(function(e){
      if($('.cropme img').length){
        $('#banner_image_txt').val($('.cropme img').attr('src'));
        $('.banner_error').hide();
      }
      /*else{
        document.location.href="#banner_error";
        $('#banner_error').show().focus();
        //$('html, body').animate({ scrollTop: $("#banner_error").offset().top }, 500);
        return false;
      }*/
    });
    
    $(function () {
      $('#datetimepicker6').datetimepicker({
        
        format:'DD-MM-YYYY h:mm A',
        minDate: new Date(),
        useCurrent: false //Important! See issue #1075
      }).on("dp.change", function (e) {
        $('input[name="time_slot_to"]').val($('input[name="time_slot_from"]').val());
        $('#datetimepicker7').data("DateTimePicker").minDate(e.date);
      });
      
      $('#datetimepicker7').datetimepicker({
        minDate: new Date(),
        format:'DD-MM-YYYY h:mm A',
        useCurrent: false //Important! See issue #1075
      }).on("dp.change", function (e) {
        $('#datetimepicker6').data("DateTimePicker").maxDate(e.date);
      });
      
      $('#datetimepicker8,#datetimepicker9').datetimepicker({
        
        format:'DD-MM-YYYY',
        minDate: new Date(),
        useCurrent: false //Important! See issue #1075
      });
    });
    
    $("#file").change(function(event) {

  
        var file = $('input[type="file"]').val();
        var exts = ['doc','docx','txt','jpg','jpeg','gif','pdf','xls','xlsx','png','mov','mp3','mp4','avi','doc','csv'];
        // first check if file field has any value
        if ( file ) {
        // split file name at dot
        
        

        var flag=0; 
        for (var i = 0; i < $("input[type='file']").get(0).files.length; ++i) {
            var get_ext = $("input[type='file']").get(0).files[i].name.split('.');
            get_ext = get_ext.reverse();
             if ( $.inArray ( get_ext[0].toLowerCase(), exts ) < 0 ){ flag=1;  }
        }
        // check file type is valid as given in 'exts' array
        if ( flag==0 ){
            
            if(uploadedCount<100){
              $("#loading_imag").css('display','inline-block');
              $("#file").attr('disabled','disabled');
              $("#uploadIcon").css("display","none");

              var fd = new FormData(); 
              var output = document.getElementById("result");
              fd.append('action', 'multipleImageUpload');
              fd.append('id', uploadedCount);
              fd.append('user_id', '<?php $user_id = $common->idUser(); echo $user_id; ?>');
              jQuery.each(jQuery('#file')[0].files, function(i, file) {
                fd.append('image[]', file);
              }); 
              $.ajax({
                url: "ajaxCalls.php", // Url to which the request is send
                type: "POST",             // Type of request to be send, called as method
                data: fd, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                contentType: false,       // The content type used when sending data to the server.
                cache: false,             // To unable request pages to be cached
                processData:false,        // To send DOMDocument or non processed data file it is set to false
                success: function(data)   // A function to be called if request succeeds
                {
                  
                  console.log(data);
                  $("#loading_imag").hide();
                  $("#file").removeAttr('disabled');
                  $("#result").append(data);
                  
                }
              });
                
              uploadedCount++;
            }else{
              alert("Maximum 100 number of files are allowed to upload!");
            }
            
        } 
        else {
              $('input[type="file"]').val('');
              alert( 'Invalid file!' );
            }
      
    }
    });


    </script>

     <!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js'></script> -->
<!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js'></script> -->

    <script type="text/javascript">
      if (/Mobi/.test(navigator.userAgent)) {
  // if mobile device, use native pickers
  $(".time input").attr("type", "date");
} else {
  // if desktop device, use DateTimePicker
  
  $(".timepicker").datetimepicker({
    format: "LT",
    icons: {
      up: "fa fa-chevron-up",
      down: "fa fa-chevron-down"
    }
  });

}
    </script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 
<script type="text/javascript">
 $(document).ready (function () { 
$('#datatable_filter input').attr('placeholder','Search');
   
  $("#open-modal-resource").click(function(){ 
   $('#search-resource').modal('show'); 
  })
     
})

   $("input[name='selected_resource']").change(function() {
      var resource_array = [];
        var all_resource = '';
        $.each($("input[name='selected_resource']:checked"), function(){            
            resource_array.push($(this).val());
        });
        all_resource = resource_array.join(",");

        if(all_resource != ''){
           $("#resource_submit").prop('disabled', false);
        }else{
          $("#resource_submit").prop('disabled', true);
        }
  });


    $( "#resource_submit" ).click(function() {

        var resource_array = [];
        var all_resource = '';
        $.each($("input[name='selected_resource']:checked"), function(){            
            resource_array.push($(this).val());
        });
        all_resource = resource_array.join(",");
        var delete_flag=1;
         $("#speakers_list").val(all_resource);
        if(all_resource != ''){

            $.ajax({
                      type: "POST",
                      url: "api.php",
                      //dataType: "json",
                      //contentType: "application/json",
                       //dataType: "json",
                       data: {"action": "get_speaker_info_EP", "resource_ids":all_resource,"delete_flag":delete_flag },
                      success: function(data){
                        $("#search-resource").modal('hide');
                        $('.selected_resource').prop('checked', false);
                        var speaker_deatils='';
                        //alert(data);
                        // for(var i=0; i<data.length; i++){
                        //          alert(data[i]['speaker_name']);
                        //         speaker_deatils += '<tr class="test"><td>'+data[i].speaker_name+'</td><td>'+data[i].email_id+'</td><td>'+data[i].company+'</td><td>'+data[i].phone+'</td><td>'+data[i].status_name+'</td><td>'+data[i].influencer+'</td><td></td></tr>';
                        //       }
                               $("#speaker_info").append(data);
                           }
                    }); // end of ajax

        }

      



    });

     $("#add_note_edit_speaker").click(function () {
        $('#addNote').modal('show');
    });

     $("#edit_info").click(function () {
        $('#EditModal').modal('show');
    });

      $("#add_new_coloboration_note").click(function () {
        $('#addColoborationNote').modal('show');
    });

          $(document).on("click","#dynamic_add_colb_note_btn",function(e) {
    e.preventDefault();
    var loggedin_userid = $("#loggedin_userid").val();
    var ep_id = "<?php echo $ep_id ?>";
    var note_val = $.trim($("#colb_note_txt").val());
    var event_id = "<?php echo $event_id ?>";
    if(note_val != '' && note_val != null){

      if(note_val != '' && note_val != null){
      //alert(speaker_id);

      $.ajax({
        type: "POST",
        url: "ajaxCalls.php",
        async:false,
        data: {"event_id":event_id,"note_val":note_val,"loggedin_userid":loggedin_userid,"ep_id":ep_id ,"action":"add_ep_colloboration_note"} ,
        success: function(data) {
        if(data == 'success'){
          $('#addColoborationNote').modal('hide');
          $("#colb_note_txt").val('');
          $(".new_coloboration_add_note").html('');
          $("#note_coloboration_added_status").text('Note created successfully!').show();
          setTimeout(function() { $("#note_coloboration_added_status").hide(); }, 4000);
           fetch_coloboration_notes(ep_id);
        }       
        }
      });
    }


    }else{
      $("#colb_note_txt").addClass('emptyField');

    }

    

            
    });

   function Assign_colo_noteid(row_id)
    {
      $('#EditNote_coloboration').modal('show');
      $("#hidden_colboration_noteid").val(row_id);
      GetDatatoEditNote_colboration();
    }

    function GetDatatoEditNote_colboration() {
       var row_id2 = $("#hidden_colboration_noteid").val();
         $.ajax({
          url: 'insert_assignroles.php',
          type: 'POST',
          data: {'Requestfor':'fetch_EP_colb_noteval','row_id': row_id2},
          //dataType: 'JSON',
          success: function(response){
             if (response != null) {
                          document.getElementById('edit_colob_note_txt').value = response;
                    }
           }
      });      
  }

   function save_EditNote_colboration()
    {
        var note_id2 = $("#hidden_colboration_noteid").val();
        var loggedin_userid2 = $("#loggedin_userid").val();
        var note_text2 = $.trim($("#edit_colob_note_txt").val());
        var ep_id = "<?php echo $ep_id ?>";
        $.ajax({
          type: "POST",
          url: "ajaxCalls.php",
          async:false,
          data: {"note_id":note_id2,"note_val":note_text2,"loggedin_userid":loggedin_userid2,"ep_id":ep_id ,"action":"update_ep_colb_note"} ,
          success: function(data) {
          if(data == 'success'){
             $('#EditNote_coloboration').modal('hide');
            $("#note_coloboration_added_status").text('Note has been updated successfully').show();
          setTimeout(function() { $("#note_coloboration_added_status").hide(); }, 4000);
             fetch_coloboration_notes(ep_id);
          }       
          }
        });

    }

       function  fetch_coloboration_notes(ep_id){

      $.ajax({
                type: "POST",
                url: "ajaxCalls.php",
                //contentType: "application/json",
                dataType: "json",
                // async:false,
                data: {"action": "fetch_ep_coloboration_notes_by_id", "ep_id" : ep_id },
                success: function(data) { 

                  var old_notes_html = '';

                  for(var i=0; i<data.length; i++){
                    // alert(data[i].notes);
                    old_notes_html += '<tr class="test"><td><p>'+data[i].notes+' </p></td><td>'+data[i].created_at+'</td><td>'+data[i].addedby+'</td><td><button type="button" onClick="Assign_colo_noteid(' + data[i].id + ')" id="edit_note_info" class="blue-n-color" style="background:none; border:none; box-shadow:none; "><img src="images/edit.png" alt="Edit" width="15" title="Edit"></button></td></tr>';

                  }
                   $("#old_coloboration_notes").empty();
                  $("#old_coloboration_notes").append(old_notes_html);

                }
           });

    }

  
    function Assign_noteid(row_id)
    {
      $('#EditNote').modal('show');
      $("#hidden_noteid").val(row_id);
      GetDatatoEditNote();
    }

     function GetDatatoEditNote() {
       var row_id = $("#hidden_noteid").val();
         $.ajax({
          url: 'insert_assignroles.php',
          type: 'POST',
          data: {'Requestfor':'fetch_EP_noteval','row_id': row_id},
          //dataType: 'JSON',
          success: function(response){
             if (response != null) {
                          document.getElementById('edit_note_txt').value = response;
                    }
           }
      });      
  }

  function save_EditNote()
  {
    var note_id = $("#hidden_noteid").val();
    var loggedin_userid = $("#loggedin_userid").val();
    var ep_id = "<?php echo $ep_id ?>";
    var note_text = $.trim($("#edit_note_txt").val());
      $.ajax({
        type: "POST",
        url: "ajaxCalls.php",
        async:false,
        data: {"note_id":note_id,"note_val":note_text,"loggedin_userid":loggedin_userid,"ep_id":ep_id ,"action":"update_ep_note"} ,
        success: function(data) {
        if(data == 'success'){
          //call old notes function
          // $(".new_add_note").html('');
          $('#EditNote').modal('hide');
          $("#note_added_status").text('Note has been updated successfully').show();
          setTimeout(function() { $("#note_added_status").hide(); }, 4000);
           fetch_speaker_notes(ep_id);
        }       
        }
      });

  }

   function  fetch_speaker_notes(ep_id){
  //  alert("function in ");

      $.ajax({
                type: "POST",
                url: "ajaxCalls.php",
                //contentType: "application/json",
                dataType: "json",
                // async:false,
                data: {"action": "fetch_ep_notes_by_id", "ep_id" : ep_id },
                success: function(data) { 

                  var old_notes_html = '';

                  for(var i=0; i<data.length; i++){
                    // alert(data[i].notes);
                    old_notes_html += '<tr class="test"><td><p>'+data[i].notes+' </p></td><td>'+data[i].created_at+'</td><td>'+data[i].addedby+'</td><td><button type="button" onClick="Assign_noteid(' + data[i].id + ')" id="edit_note_info" class="blue-n-color" style="background:none; border:none; box-shadow:none; "><img src="images/edit.png" alt="Edit" width="15" title="Edit"></button></td></tr>';

                  }
                  $("#old_notes").empty();
                  $("#old_notes").append(old_notes_html);

                }
           });

    }

    $(document).on("click","#dynamic_add_note_btn",function(e) {
    e.preventDefault();
    var loggedin_userid = $("#loggedin_userid").val();
    var ep_id = "<?php echo $ep_id ?>";
    var note_val = $.trim($("#dynamic_add_note_txt").val());
    var event_id = "<?php echo $event_id ?>";
    if(note_val != '' && note_val != null){

      if(note_val != '' && note_val != null){
      //alert(speaker_id);

      $.ajax({
        type: "POST",
        url: "ajaxCalls.php",
        async:false,
        data: {"event_id":event_id,"note_val":note_val,"loggedin_userid":loggedin_userid,"ep_id":ep_id ,"action":"add_ep_note"} ,
        success: function(data) {
        if(data == 'success'){
          //call old notes function
           $('#addNote').modal('hide');
          $("#dynamic_add_note_txt").val('');
          $(".new_add_note").html('');
          $("#note_added_status").text('Note created successfully!').show();
          setTimeout(function() { $("#note_added_status").hide(); }, 4000);
           fetch_speaker_notes(ep_id);
        }       
        }
      });
    }


    }else{
      $("#dynamic_add_note_txt").addClass('emptyField');

    }

    

            
    });

  $( ".dlt_ppt" ).click(function() {
          var res = confirm('Are you sure?');
          if(res){
          var doc_id = $(this).attr('id');
          var ep_id = "<?php echo $ep_id ?>";
          $.ajax({
                      type: "POST",
                      url: "api.php",
                      //contentType: "application/json",
                       dataType: "json",
                       data: {"action": "delete_EP_docs", "ep_id":ep_id,"doc_id":doc_id},
                      success: function(response){
                        Swal.fire({
                                    type: 'success',
                                    title: 'Success',
                                    text: 'Deleted Successfully.',
                                    allowOutsideClick: false
                                  }).then(okay => {
                                       if (okay) {
                                          var len = response.length;
                                         var row='';
                                        for(var i=0; i<len; i++){
                                           var rid = response[i].id;
                                            var file_name = response[i].file_name;
                                              if(rid>0)
                                              {
                                                row += '<tr><td><a class="linkurl">'+file_name+'</a></td><td><a href="documents/'+file_name+'" class="download" download>Download</a></td></tr>';
                                                // <td> <button type="button" class="btn delete dlt_ppt" id="'+rid+'" onclick="deleteClick('+rid+');">Delete</button></td>
                                              }else
                                              {
                                               $("#delete_docs_ep").empty(); 
                                              }
                                            }
                                              
                                            
                                            $("#delete_docs_ep").empty();
                                            $('#delete_docs_ep').append(row);
                                      }
                                    });
                                //$('#document_upload_sec').html(row);
                      }
                           
                    }); // end of ajax
          }
        });

function deleteClick(id)
{
      var res = confirm('Are you sure?');
          if(res){
          var doc_id = id;
          var ep_id = "<?php echo $ep_id ?>";
          $.ajax({
                      type: "POST",
                      url: "api.php",
                      //contentType: "application/json",
                       dataType: "json",
                       data: {"action": "delete_EP_docs", "ep_id":ep_id,"doc_id":doc_id},
                      success: function(response){
                          Swal.fire({
                                    type: 'success',
                                    title: 'Success',
                                    text: 'Deleted Successfully.',
                                    allowOutsideClick: false
                                  }).then(okay => {
                                       if (okay) {
                                        var len = response.length;
                                         var row='';
                                        for(var i=0; i<len; i++){
                                           var rid = response[i].id;
                                            var file_name = response[i].file_name;
                                              if(rid>0)
                                              {
                                                row += '<tr><td><a class="linkurl">'+file_name+'</a></td><td><a href="documents/'+file_name+'" class="download" download>Download</a></td></tr>';
                                                // <td> <button type="button" class="btn delete dlt_ppt" id="'+rid+'" onclick="deleteClick('+rid+');">Delete</button></td>
                                              }else
                                              {
                                               $("#delete_docs_ep").empty(); 
                                              }
                                              
                                            } 
                                            $("#delete_docs_ep").empty();
                                            $('#delete_docs_ep').append(row);
                                      }
                                    });
                             
                                //$('#document_upload_sec').html(row);
                      }
                           
                    }); // 
        }
  }

          $( "#save_ppt" ).click(function() {

           var ppt_token = "<?php echo $ppt_token; ?>";
           var ep_id = "<?php echo $ep_id ?>";
           var event_id = "<?php echo $event_id ?>";
          $.ajax({
                      type: "POST",
                      url: "api.php",
                      //contentType: "application/json",
                       dataType: "json",
                       data: {"action": "insert_EP_docs","ppt_token":ppt_token,"ep_id":ep_id,"event_id":event_id},
                      success: function(data){
                                 if(data[0].status == 'success'){
                                                  Swal.fire({
                                    type: 'success',
                                    title: 'Success',
                                    text: data[0].message,
                                    allowOutsideClick: false
                                  }).then(okay => {
                                       if (okay) {
                                        $('.dz-preview').remove();
                                        //$('#dropzone_ppt').load('edit_presentation.php?id="'+ep_id+'"');
                                        //$("#dropzone_ppt").html('');
                                       BindDocs();
                                      }
                                    });

                                               }else{
                                                 Swal.fire({
                                    type: 'error',
                                    title: 'Oops...',
                                    text: data[0].message
                                  })
                                               }  
                                        },
                                          error: function() {
                                            Swal.fire({
                                    type: 'error',
                                    title: 'Oops...',
                                    text: 'Something went wrong! Please try again'
                                  })
                           }
                    }); // end of ajax     
    }); // end of save ppt click

    function BindDocs()
    {
      var ep_id = "<?php echo $ep_id ?>";
      var event_id = "<?php echo $event_id ?>";
      $.ajax({
                      type: "POST",
                      url: "api.php",
                      //contentType: "application/json",
                       dataType: "json",
                       data: {"action": "Get_EP_docs", "ep_id":ep_id},
                      success: function(response){
                             var len = response.length;
                             var row='';
                            for(var i=0; i<len; i++){
                               var rid = response[i].id;
                                var file_name = response[i].file_name;
                                  if(rid>0)
                                  {
                                    row += '<tr><td><a class="linkurl">'+file_name+'</a></td><td><a href="documents/'+file_name+'" class="download" download>Download</a></td></tr>';
                                    // <td> <button type="button" class="btn delete dlt_ppt" id="'+rid+'" onclick="deleteClick('+rid+');">Delete</button></td>
                                  }else
                                  {
                                   $("#delete_docs_ep").empty(); 
                                  }
                                }
                                  
                                
                                $("#delete_docs_ep").empty();
                                $('#delete_docs_ep').append(row);
                                //$('#document_upload_sec').html(row);
                      }
                           
                    }); // end of ajax
    }

    function confirmDeleteSpeaker(sid)
    {
      var ep_id = "<?php echo $ep_id ?>";
              $.ajax({
                      type: "POST",
                      url: "api.php",
                       data: {"action": "delete_speaker_info_EP", "ep_id":ep_id,"speaker_id":sid },
                      success: function(data){
                        var speaker_deatils='';
                            Swal.fire({
                                    type: 'success',
                                    title: 'Success',
                                    text: 'Deleted Successfully.',
                                    allowOutsideClick: false
                                  }).then(okay => {
                                       if (okay) {
                                         $("#speaker_info").empty();
                                          $("#speaker_info").append(data);
                                      }
                                    });
                               
                           }
                    }); // end of ajax
    }

    if(window.location.href.indexOf("info-collect-success") > -1) {
       $('.info-collect-success').fadeIn(200).delay(2000).fadeOut(2000);
  }

  $(document).ready(function() {
  $("#p_topic").on('keyup', function() {
    var words = this.value.match(/\S+/g).length;

    if (words > 100) {
      // Split the string on first 200 words and rejoin on spaces
      var trimmed = $(this).val().split(/\s+/, 100).join(" ");
      // Add a space at the end to make sure more typing creates new words
      $(this).val(trimmed + " ");
    }
    else {
      //$('#display_count').text(words);
      $('#word_left').text(100-words);
    }
  });
});   

  $(document).ready(function() {
  $("#abstract").on('keyup', function() {
    var words = this.value.match(/\S+/g).length;

    if (words > 500) {
      // Split the string on first 200 words and rejoin on spaces
      var trimmed = $(this).val().split(/\s+/, 500).join(" ");
      // Add a space at the end to make sure more typing creates new words
      $(this).val(trimmed + " ");
    }
    else {
      //$('#word_left_abs').text(words);
      $('#word_left_abs').text(500-words);
    }
  });
});

  $(document).ready(function() {
  $("#bussiness_objective").on('keyup', function() {
    var words = this.value.match(/\S+/g).length;

    if (words > 200) {
      // Split the string on first 200 words and rejoin on spaces
      var trimmed = $(this).val().split(/\s+/, 200).join(" ");
      // Add a space at the end to make sure more typing creates new words
      $(this).val(trimmed + " ");
    }
    else {
      //$('#display_count').text(words);
      $('#word_left_bobj').text(200-words);
    }
  });
});

jQuery(document).on('blur', '#end_time', function () {
     var stt = new Date("November 13, 2013 " + $('#start_time').val());
   var ett = new Date("November 13, 2013 " + $('#end_time').val());
     if(stt >= ett){
      document.getElementById("edtime").innerHTML = "End time should be greater than start time";
      errorFlag=1;
      $("#edit_presentation").attr("disabled", true);
       
    }else
    {
      $("#edit_presentation").attr("disabled", false);
      document.getElementById("edtime").innerHTML = "";
    }

  });

</script>

 

  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js'></script>
<script type="text/javascript">$(function () {
  $("#datepicker1").datepicker({ 
        format:'dd-MM-yyyy',
        minDate: new Date(),
        autoclose: true
  }).datepicker();
});</script>
</div>