<?php
  include("./include/html_codes.php");
  require("include/mysqli_connect.php");
  $event_id_res=$common->get_eventid(trim($_GET['eid']));
  $event_id = $common->check_event_id($event_id_res);
  admin_way_top();
  admin_top_bar($event_id);
  admin_left_menu($event_id);

  $current_uid = uniqid();

  $_SESSION['current_uid'] = $current_uid;
  $fetch_url_query = mysqli_query($connect,"SELECT site_url FROM site_details where id=2");
    if(mysqli_num_rows($fetch_url_query) > 0)
        {            
            while($row1 = mysqli_fetch_array($fetch_url_query))
            {
                $site_url = $row1['site_url'];
            }
         } 

       $event_sql = mysqli_query($connect,"SELECT * FROM all_events WHERE id=".$event_id);
       $event_row = mysqli_fetch_array($event_sql);
       $event_url_structure = $event_row['event_name'];
        if( strlen($event_url_structure ) > 40 ) 
        {
          $event_url_structure = substr($event_row['event_name'], 0, 40 ) . '...';
        }
$speakers_array = $common->fetch_all_speaker_for_event_presentation($event_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Speaker Engage</title>
<link href="css/event/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" href="css/event/css/custom.css">
<link rel="stylesheet" href="css/event/css/croppie.css">
<link href="css/dropzone.css" rel="stylesheet" type="text/css">
  <link href="css/custom_aby.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
<!--<link href="//use.fontawesome.com/releases/v5.1.0/css/all.css" rel="stylesheet">-->
<!------ Include the above in your HEAD tag ---------->
 
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css'>
<style>
  .input-group {
    z-index: 9;
  }
  .sp_opertunity .table>thead>tr>th:nth-child(3), .sp_opertunity .table>thead>tr>th:nth-child(4) {
    text-align: left;
}
  table.dataTable.listtable .form-control, .listtable .multiselect.dropdown-toggle.btn.btn-default {
    margin-bottom: 0px !important;
  }
  .listtable .multiselect.dropdown-toggle.btn.btn-default {
    top: 1px;
  }
  .table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    vertical-align: middle;
  }
  .table>tbody>tr>td {
    padding-top: 15px;
    padding-bottom: 15px;
  }
  .dltImg {
    position: absolute;
      right: 10px;
      top: 10px;
      color: red;
      width: 40px;
      height: 40px;
      float: left;
      font-size: 18px;
      background: rgba(255, 255, 255, 0.82);
      text-align: center;
      line-height: 40px;
      border-radius: 40px;
  }
  .checkbox input[type=checkbox], .checkbox-inline input[type=checkbox], .radio input[type=radio], .radio-inline input[type=radio]{margin-top:-15px;}
  .blue-n-color, h3{color:#0283A3;}
  h3{font-size:16px;}
  .bdr-light{border:solid 1px #707070; background:#fff; min-height:90px;}
  .bdr-light .form-group{margin-bottom:10px !important;}
  .upload-btn-wrapper {
  position: relative;
  overflow: hidden;
  display: inline-block;
}
.btn-success{background-color: #0283A3 !important;
    border-color: #0283A3 !important; border-radius:0 !important;}
.btn1 {
  border: none;
  color: black;
  background-color: white;
  
  border-radius:0;
  box-shadow:none;
  font-size: 20px;
  font-weight: bold;
}

.upload-btn-wrapper input[type=file] {
  font-size: 100px;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
}
@media (min-width: 768px){
#search-resource .modal-dialog {
    width: 70%;
    margin: 30px auto;
}
}

  #search-resource .modal-title{    background: #007db7;    color: #fff;    text-align: left;    padding: 15px;}
  #search-resource .modal-header{padding: 0; border:none;}
  #search-resource  .modal-header .close {
    margin-top: 8px;
    margin-right: 5px;
}
#datatable_length{display: none !important}
#datatable_filter{width:100% !important;}
.dataTables_filter label{width:100% !important; text-align: left; font-size: 0 !important;}
.dataTables_filter input{width: 100% !important; font-size: 16px !important; background: url(images/search.png) no-repeat;     padding-left: 18px;        background-position: 2px center;}
table.dataTable thead .sorting_desc, table.dataTable thead .sorting_asc{background: none !important;}
.form_datetime {
    padding-left: 37px;
    position: relative;
    background: url(images/calendar-with-a-clock-time-tools_blue.png) no-repeat left center;
    background-position-x:6px ;
    margin-bottom: 5px !important;
}
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper innerpageSec formPage" style="margin-top:0 !important;">
   <!-- Content Header (Page header) -->
   <section class="content-header pad-5">
      
      <ol class="breadcrumb new-breadcrumb">
       <?php breadcrumb(); ?>
         <li><a><?php echo $event_url_structure;?></a></li>
         <li><a href="all-speakers.php?eid=<?php echo base64_encode($event_id);?>:<?php echo base64_encode(rand(100,999));?>">Speaker Management</a></li>
         <li><a href="all_presentation.php?eid=<?php echo base64_encode($event_id);?>:<?php echo base64_encode(rand(100,999));?>">Event Agenda</a></li>
         <li class="active">New Event Agenda</li>
         <!-- <li class="active">Untitled Template</li>-->
      </ol>
      <div class="clearfix"></div>
   </section>
   <div class="clearfix"></div>
      <div class="created-success" style="text-align: center;color: green;font-size: 18px;padding: 19px;display:none">A Event Presentation has been created successfully!</div>
   <!-- Main content -->
   <section class="content pad-5">
    <div class="speakerDashboard createPages">
      <div class="row">
          <div class="col-xs-12 col-md-9 text-left">
          <h3 class="font-sem-bold"><?php echo $event_url_structure;?>: CREATE NEW EVENT AGENDA</h3> 
       </div>
       <div class="col-xs-12 col-md-3 text-right "> 
        <!-- <button type="button" class="btn btn-success createBtn" name="create_speaker_top"  id="create_speaker_top" style="display:inline-block; margin-top: 11px;margin-right: 15px;">Save</button> -->

        <a href="all_presentation.php?eid=<?php echo base64_encode($event_id);?>:<?php echo base64_encode(rand(100,999));?>"><button type="button" class="btn btn-danger" style="display:inline-block; margin-top: 11px;margin-right: 15px;width: 77px;">Exit</button></a>
      </div>
      </div>
    
      <!-- Small boxes (Stat box) -->
      <div class="">
         <div class="container-fluid brdrHr">
    <hr>
  </div>
  
   <div class="clearfix"></div>
      <!-- Small boxes (Stat box) -->
      <div class="borderForm">
            <section >
               <form method="post" action="include/form_submits.php" id="create_event_presentation">
                  <div class="card-box" style="padding-top:0;">
                    
            <div class="box box-primary" style="background:none; box-shadow:none;">
        <div class="col-xs-12">
                
                     <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                           <label>Presenting Topic* <span class="blue-n-color">(<span id="word_left">100</span> Characters)</span></label>
                           <input type="text" class="form-control required" placeholder="Presenting Topic" required name="p_topic" id="p_topic" />
                          
                            <!-- Total word count: <span id="display_count">0</span> words. Words left: <span id="word_left">200</span> -->
                        </div>

                        <div class="form-group">
                           <label>Type</label> 
                           <select type="text" class="form-control" id="opportunity_type" name="opportunity_type">
                            <option value="">Select Type</option>
                            <?php  
            
                            $all_speakers_types_array = $common->fetch_all_speaker_types_asc($event_id);
                            foreach($all_speakers_types_array as $all_speakers_type){
                                  $speaker_type_name = $all_speakers_type['speaker_type_name'];
                                  echo "<option value='".$all_speakers_type['id']."'>".$speaker_type_name."</option>";
                                }
                              ?>
                           </select>
                        </div>

                        <div class="form-group">
                           <label>Location*</label> 
                           <input type="text" class="form-control" name="location" id="location" placeholder="Location Name" required/>
                        </div>


                      </div>
                      <div class="col-md-8">
                        <div class="form-group">
                           <label>Abstract* <span class="blue-n-color">(<span id="word_left_abs">500</span> Characters)</span></label> 
                           <textarea type="text" class="form-control" placeholder="Abstract" required name="abstract" id="abstract" style="min-height: 192px;"></textarea>
                        </div>
                      </div>
                                   
                        <div class="clearfix"></div>
                     </div>

                     <div class="row">
                      <div class="col-md-4">
                        <div class="row">
                            <div class="col-md-10 form-group">
                              <label>Date</label> 
                              <div id="datepicker1" class="input-group date " data-date-format="mm-dd-yyyy">
                                <input class="form-control form_datetime" type="text"  name="event_date" id="event_date" required/>
                                <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                            </div>
                            </div>
                            <div class="clearfix"></div>

                          <div class="col-md-5 form-group">
                           <label>Start Time*</label> 
                           <div class="input-group timepicker date"  style="margin-bottom: 5px;">
                             <span class="input-group-append input-group-addon"></span> <input class="form-control time" name="start_time" id="start_time" required/>
                            </div>
                        </div>

                        <div class="col-md-5 form-group">
                           <label>End Time*</label> 
                           <div class="input-group timepicker date" style="margin-bottom: 5px;">
                             <span class="input-group-append input-group-addon"></span> <input class="form-control time " name="end_time" id="end_time" required/>
                             <span class="error edtime" id="edtime" style="font-size: 11px;color: red;position: absolute;bottom: -25px;left: 0;height: 26px;line-height: 14px;"></span>
                            </div>
                        </div>

                        </div>
                        
                        <div class="form-group">
                           <label>Topic Owner*</label> 
                           <input type="text" class="form-control" name="topic_owner" id="topic_owner" required/>
                        </div>


                      </div>
                      <div class="col-md-8">
                        <div class="form-group">
                           <label>Business Objectives <span class="blue-n-color">(<span id="word_left_bobj">200</span> Characters)</span></label> 
                           <textarea type="text" class="form-control" placeholder=""  name="bussiness_objective" id="bussiness_objective" style="min-height: 188px;"></textarea>
                        </div>
                      </div>
                        
            
                                   
                        <div class="clearfix"></div>
                     </div>
                      
            </div>
<div class="clearfix"></div>
            </div>
            <h3 class="pull-left">Add Speakers</h3>
            <a  id="open-modal-resource" style="margin-top: 28px;margin-right: 12px;" class="pull-right"><button class="blue-n-color" type="button" style="background:none; border:none; box-shadow:none; "><img src="images/add1.png" width="10" style="position: relative;top: -2px;"> &nbsp;<span class="font-sem-bold">Add Speakers</span></button></a>
            <div class="clearfix"></div>
            <div class="box box-primary sp_opertunity" style="background:none; box-shadow:none;">
            <div class="card-box table-responsive" style="padding: 17px; padding-top:0;">

   <div class="clearfix"></div>
   <button class="pull-right" style="background:none; border:none; box-shadow:none; display:none;"><img src="images/add.png" width="15" /> &nbsp; <b>Add Field</b></button><div class="clearfix"></div>
                  <!-- <table id="datatable" class="table table-responsive listtable" style="width:100%"> -->
                    <div class="border-div" style="margin-bottom: 30px;padding: 0px 15px;" >
                     <table  class="table table-responsive listtable" style="width:100%;margin-bottom: 0px;">
                     <thead>
                        <tr>
                           
                           <th style="min-width: 120px;">Speaker Name</th>
               <th style="min-width: 120px;">Speaker Email</th>
                            <th style="min-width: 100px;">Company</th>
                            <th style="min-width: 100px;">Contact</th>
                            
                           <th style="min-width: 120px;">Status</th>
                      
                           <th style="min-width: 150px;">Influencer Score</th>
                           
                           
                          <!--  <th style="min-width: 60px;">Manage</th> -->
                        </tr>
                     </thead>
                     <tbody id="speaker_info">
                    
                     </tbody>
                  </table>
                </div>
                  <?php 
                     if(!count($all_speakers_array)){
                      echo "<script>$('.table-responsive').html('<center>No Data Found!</center>')</script>";
                     } 
                     ?>
                   </div>
               </div>
            <h3>UPLOAD PRESENTATIONS</h3> 
             <div class="box box-primary" style="background:none; box-shadow:none;padding-bottom: 15px !important;">

                        <div class="col-lg-12" style="margin-top: 10px;">
                         <div class="clearfix"></div>
                          <div class="dropzone" action="include/upload.php" id="myAwesomeDropzone"> </div>
                          <div class="clearfix"></div>
                              </div>
                        <div class="clearfix"></div>
                        </div>
    
            
                            
               <h3 style="float: left;margin-top: 10px;margin-bottom: 15px;">A/V Needs</h3> 
                            <a id="add_new_note" style="cursor:pointer;float: right;margin-top: 15px;margin-right: 20px;"><img src="images/add1.png" width="10" style="position: relative;top: -2px;"> &nbsp;<span class="font-sem-bold">Add New Note</span></a>
                      <div class="clearfix"></div>
                          <div class="" style="background:none; box-shadow:none;">
                         <div class="clearfix"></div>
                        <div class="col-lg-12">
                        <div class="row">
                           
                            <div class="new_add_note">

                            </div>
                            
                             <div class="clearfix"></div>
                             <center><p id="note_added_status" style="color: green; display: none;" >Note added successfully!</p></center>
                             <div class="container-fluid collabrationSec ">
                              <table  class="table table-bordered table-responsive" style="width: 100%;">
                                <thead>
                                <tr>
                                  <th style="min-width: 500px;"><p>Note</p></th>
                                  <th style="min-width: 160px;"><p>Date</p></th>
                                  <th style="min-width: 160px;"><p>Added by</p></th>
                                  <th style="min-width: 100px;"><p>Actions</p></th>
                                </tr>
                                </thead>
                                <tbody id="old_notes">
                                  
                                </tbody>
                              </table>

                              </div>
                         </div>
             </div>
              <h3 style="float: left;margin-top: 10px;margin-bottom: 15px;">COLLABORATION NOTES</h3> 
                            <a id="add_new_coloboration_note" style="cursor:pointer;float: right;margin-top: 15px;margin-right: 20px;"><img src="images/add1.png" width="10" style="position: relative;top: -2px;"> &nbsp;<span class="font-sem-bold">Add New Note</span></a>
                      <div class="clearfix"></div>
                        <div class="col-lg-12">
                        <div class="row">
                           
                            <div class="new_coloboration_add_note">

                            </div>
                            
                             <div class="clearfix"></div>
                             <center><p id="note_coloboration_added_status" style="color: green; display: none;" >Note added successfully!</p></center>
                             <div class="container-fluid collabrationSec ">
                              <table  class="table table-bordered table-responsive" style="width: 100%;">
                                <thead>
                                <tr>
                                  <th style="min-width: 500px;"><p>Note</p></th>
                                  <th style="min-width: 160px;"><p>Date</p></th>
                                  <th style="min-width: 160px;"><p>Added by</p></th>
                                  <th style="min-width: 100px;"><p>Actions</p></th>
                                </tr>
                                </thead>
                                <tbody id="old_coloboration_notes">
                                  
                                </tbody>
                              </table>

                              </div>
                         </div>
             </div>
             <div class="clearfix"></div>
              </div>

              <div class="modal fade darkHeaderModal" id="addNote" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width: 100% !important;border-radius: 0px;">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><img src="images/cancel.png" width="20"></button>
                      <h4 class="modal-title " id="" style="margin-bottom: 0px;font-size: 18px;color: #fff;">Add New Note</h4>
                    </div>

                    <div class="modal-body">
                  <form>
                           <div class="row" id="">
                                 <div class="col-md-12 form-group">
                                                 <label class="blue-n-color"> WRITE YOUR NOTE</label> 
                                            
                                                 <div class="note-info"><textarea id="dynamic_add_note_txt" class="form-control" placeholder="Start Typing.." style="min-height: 160px;margin-bottom: 5px;" name="speaker_note"> </textarea><div class="clearfix"></div></div>
                                      </div> 
                      
                                   </div>
                               

                              <div class="sendBtn text-right">
                                <button type="button" id="dynamic_add_note_btn" class="btn btn-success createBtn">Save</button>
                              </div>
                            
                             </form>
                              </div>
                          </div>
                        </div>
                  </div>

              <div class="modal fade darkHeaderModal" id="EditNote" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width: 100% !important;border-radius: 0px;">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><img src="images/cancel.png" width="20"></button>
                      <h4 class="modal-title " id="" style="margin-bottom: 0px;font-size: 18px;color: #fff;">Edit Note</h4>
                    </div>

                    <div class="modal-body">
                  <form>
                           <div class="row" id="">
                                 <div class="col-md-12 form-group">
                                                 <label class="blue-n-color"> WRITE YOUR NOTE</label> 
                                                 <div class="note-info" style="padding-left:15px;padding-right:15px;"><textarea id="edit_note_txt" class="form-control" placeholder="Start Typing.." style="min-height: 160px;margin-bottom: 5px;" name="speaker_note"> </textarea><div class="clearfix"></div></div>
                                      </div> 
                      
                                   </div>
                               

                              <div class="sendBtn text-right">
                                <button type="button" id="edit_note_btn" onclick="save_EditNote();" class="btn btn-success createBtn">Save</button>
                              <!--   <button type="button" id="" class="btn btn-success createBtn">Save</button> -->
                              </div>
                            
                             </form>
                              </div>
                          </div>
                        </div>
                  </div>


                <div class="modal fade darkHeaderModal" id="addColoborationNote" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width: 100% !important;border-radius: 0px;">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><img src="images/cancel.png" width="20"></button>
                      <h4 class="modal-title " id="" style="margin-bottom: 0px;font-size: 18px;color: #fff;">Add New Note</h4>
                    </div>

                    <div class="modal-body">
                  <form>
                           <div class="row" id="">
                                 <div class="col-md-12 form-group">
                                                 <label class="blue-n-color"> WRITE YOUR NOTE</label> 
                                            
                                                 <div class="note-info"><textarea id="colb_note_txt" class="form-control" placeholder="Start Typing.." style="min-height: 160px;margin-bottom: 5px;" name="colb_note_txt"> </textarea><div class="clearfix"></div></div>
                                      </div> 
                      
                                   </div>
                               

                              <div class="sendBtn text-right">
                                <button type="button" id="dynamic_add_colb_note_btn" class="btn btn-success createBtn">Save</button>
                              </div>
                            
                             </form>
                              </div>
                          </div>
                        </div>
                  </div>

            <div class="modal fade darkHeaderModal" id="EditNote_coloboration" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width: 100% !important;border-radius: 0px;">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><img src="images/cancel.png" width="20"></button>
                      <h4 class="modal-title " id="" style="margin-bottom: 0px;font-size: 18px;color: #fff;">Edit Note</h4>
                    </div>

                    <div class="modal-body">
                  <form>
                           <div class="row" id="">
                                 <div class="col-md-12 form-group">
                                                 <label class="blue-n-color"> WRITE YOUR NOTE</label> 
                                                 <div class="note-info" style="padding-left:15px;padding-right:15px;"><textarea id="edit_colob_note_txt" class="form-control" placeholder="Start Typing.." style="min-height: 160px;margin-bottom: 5px;" name="edit_colob_note_txt"> </textarea><div class="clearfix"></div></div>
                                      </div> 
                      
                                   </div>
                               

                              <div class="sendBtn text-right">
                                <input type="hidden" id="hidden_colboration_noteid" name="hidden_colboration_noteid"/>
                                <button type="button" id="edit_note_btn_colobo" onclick="save_EditNote_colboration();" class="btn btn-success createBtn">Save</button>
                              <!--   <button type="button" id="" class="btn btn-success createBtn">Save</button> -->
                              </div>
                            
                             </form>
                              </div>
                          </div>
                        </div>
                  </div>

                      <div class="clearfix"></div>
                       <div class="">
                        <div class="col-xs-12 text-right">
                           <input type="hidden" id="timezone" name="timezone" value=""/>
                           <input type="hidden" name="action" value="create_event_presentation">
                           <input type="hidden" name="loggedin_userid" id="loggedin_userid" value="<?php echo $_SESSION['user_id']; ?>">
                           <input type="hidden" name="evt_id" value="<?php echo $event_id; ?>" id="evt_id" >
                           <input type="hidden" id="hidden_noteid" name="hidden_noteid"/>
                           <input type="hidden" name="uid" value="<?php echo $current_uid; ?>">
                           <input type="hidden" name="speakers_list" id="speakers_list">
                            <button type="submit" class="btn btn-success" name="create_presentation_save_exit"  id="create_presentation_save_exit" style="display:inline-block; margin-top: 20px;">Save & Exit</button>                           
                            <div class="clearfix"></div><br/>
                        </div>
                        <div class="clearfix"></div>
                     </div>
                  </div>
               </form>
            </section>
         </div>
      </div>
      </div>
   </section>
   <!-- /.content -->
</div>

<div class="modal fade" id="search-resource"  data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="width: 100% !important;border-radius: 0px;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><img src="images/cancel.png" width="20"></button>
        <h4 class="modal-title" id="myModalLabel">Search From Database</h4>
      </div>

      <div class="modal-body">
            <table  class="dtTable" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th><!-- <input type="checkbox" name="select_all" value="1" id="example-select-all"> --></th>
                  <th>Speaker Name</th>
                  <th>Email</th>
                  <th>Comapny</th>
               
                </tr>
              </thead>
              <tbody style="text-align: left;" id="speaker_attach">
               
              </tbody>
            </table>

            <input type="button" name="resource_submit" id="resource_submit" class="btn btn-success" style="margin-top: 5px;" disabled="true" value="Add">
        </div>
    </div>
  </div>
</div>

  
  <?php all_speaker_footer(); ?>
  <?php version_footer(); ?>
    
    <script  src="https://code.jquery.com/jquery-3.3.1.js" ></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/eonasdan-bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js'></script>
    <script src="js/dropzone.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
    <script type="text/javascript">


    $("#add_new_note").click(function () {
        $('#addNote').modal('show');
    });

    $("#add_new_coloboration_note").click(function () {
        $('#addColoborationNote').modal('show');
    });

    var uploadedCount = 1;



    Dropzone.autoDiscover = false;

        // $(document).ready(function(){

          // var c_uid = "<?php echo $current_uid; ?>";
          // alert(uid);
        $(".dropzone").dropzone({
            addRemoveLinks: true,
      
            removedfile: function(file) {
                var name = file.name;
                //var uid = c_uid;  
                 
                
                $.ajax({
                    type: 'POST',
                    url: 'include/upload.php',
                    data: {name: name,request: 2},
                    sucess: function(data){
                        console.log('success: ' + data);
            
                    }
                });
                var _ref;
                return (_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
            }
            });
        // });


    $( "input[type='number']" ).keypress(function( event ) {
      if ( event.which == 45  ||event.which==101) { // preventing minus key and 'e' key
       event.preventDefault();
      }
    });
  
    $('#create_speaker').click(function(e){
      if($('.cropme img').length){
        $('#banner_image_txt').val($('.cropme img').attr('src'));
        $('.banner_error').hide();
      }
      /*else{
        document.location.href="#banner_error";
        $('#banner_error').show().focus();
        //$('html, body').animate({ scrollTop: $("#banner_error").offset().top }, 500);
        return false;
      }*/
    });
    
    $(function () {
      $('#datetimepicker6').datetimepicker({
        
        format:'DD-MM-YYYY h:mm A',
        minDate: new Date(),
        useCurrent: false //Important! See issue #1075
      }).on("dp.change", function (e) {
        $('input[name="time_slot_to"]').val($('input[name="time_slot_from"]').val());
        $('#datetimepicker7').data("DateTimePicker").minDate(e.date);
      });
      
      $('#datetimepicker7').datetimepicker({
        minDate: new Date(),
        format:'DD-MM-YYYY h:mm A',
        useCurrent: false //Important! See issue #1075
      }).on("dp.change", function (e) {
        $('#datetimepicker6').data("DateTimePicker").maxDate(e.date);
      });
      
      $('#datetimepicker8,#datetimepicker9').datetimepicker({
        
        format:'DD-MM-YYYY',
        minDate: new Date(),
        useCurrent: false //Important! See issue #1075
      });
    });
    
    $("#file").change(function(event) {

  
        var file = $('input[type="file"]').val();
        var exts = ['doc','docx','txt','jpg','jpeg','gif','pdf','xls','xlsx','png','mov','mp3','mp4','avi','doc','csv'];
        // first check if file field has any value
        if ( file ) {
        // split file name at dot
        
        

        var flag=0; 
        for (var i = 0; i < $("input[type='file']").get(0).files.length; ++i) {
            var get_ext = $("input[type='file']").get(0).files[i].name.split('.');
            get_ext = get_ext.reverse();
             if ( $.inArray ( get_ext[0].toLowerCase(), exts ) < 0 ){ flag=1;  }
        }
        // check file type is valid as given in 'exts' array
        if ( flag==0 ){
            
            if(uploadedCount<100){
              $("#loading_imag").css('display','inline-block');
              $("#file").attr('disabled','disabled');
              $("#uploadIcon").css("display","none");

              var fd = new FormData(); 
              var output = document.getElementById("result");
              fd.append('action', 'multipleImageUpload');
              fd.append('id', uploadedCount);
              fd.append('user_id', '<?php $user_id = $common->idUser(); echo $user_id; ?>');
              jQuery.each(jQuery('#file')[0].files, function(i, file) {
                fd.append('image[]', file);
              }); 
              $.ajax({
                url: "ajaxCalls.php", // Url to which the request is send
                type: "POST",             // Type of request to be send, called as method
                data: fd, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                contentType: false,       // The content type used when sending data to the server.
                cache: false,             // To unable request pages to be cached
                processData:false,        // To send DOMDocument or non processed data file it is set to false
                success: function(data)   // A function to be called if request succeeds
                {
                  
                  console.log(data);
                  $("#loading_imag").hide();
                  $("#file").removeAttr('disabled');
                  $("#result").append(data);
                  
                }
              });
                
              uploadedCount++;
            }else{
              alert("Maximum 100 number of files are allowed to upload!");
            }
            
        } 
        else {
              $('input[type="file"]').val('');
              alert( 'Invalid file!' );
            }
      
    }
    });
 
   
    </script>

     <!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js'></script> -->
<!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js'></script> -->

    <script type="text/javascript">
      if (/Mobi/.test(navigator.userAgent)) {
  // if mobile device, use native pickers
  $(".time input").attr("type", "date");
} else {
  // if desktop device, use DateTimePicker
  
  $(".timepicker").datetimepicker({
    format: "LT",
    icons: {
      up: "fa fa-chevron-up",
      down: "fa fa-chevron-down"
    }
  });

}

var cur_time=formatAMPM(new Date);
function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  return strTime;
}
$('#start_time').val(cur_time);
$('#end_time').val(cur_time);
    </script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jstimezonedetect/1.0.4/jstz.min.js">
    </script>
<script type="text/javascript">

  $( document ).ready(function() {
      var tz = jstz.determine(); // Determines the time zone of the browser client
        var timezone = tz.name(); //'Asia/Kolhata' for Indian Time.
        //alert(timezone);
        $("#timezone").val(timezone);
  });
 $(document).ready (function () { 
$('#datatable_filter input').attr('placeholder','Search');
   
  $("#open-modal-resource").click(function(){ 
   $('#search-resource').modal('show'); 
   var uniq_token = "<?php echo $current_uid; ?>";
   var event_id = "<?php echo $event_id; ?>";
    $.ajax({
                type: "POST",
                url: "ajaxCalls.php",
                dataType: "json",
                data: {"action": "fetch_all_speaker_for_event_presentation_new", "uniq_token" : uniq_token,"event_id" : event_id},
                success: function(data) { 
                   destroy_datatable();
                  var old_notes_html = '';

                  for(var i=0; i<data.length; i++){
                         old_notes_html += '<tr><td><input type="checkbox" name="selected_resource" value='+data[i].id+' class="selected_resource" /></td><td>'+data[i].speaker_name+'</td><td>'+data[i].email_id+'</td><td>'+data[i].company+'</td></tr>';

                  } 
                  $("#speaker_attach").empty();
                  $("#speaker_attach").append(old_notes_html);
                   $('.dtTable').DataTable();

                }
           });
  })
     
})

    $(document).on("change", "input[name='selected_resource']" , function() {
      var resource_array = [];
        var all_resource = '';
        $.each($("input[name='selected_resource']:checked"), function(){            
            resource_array.push($(this).val());
        });
        all_resource = resource_array.join(",");

        if(all_resource != ''){
           $("#resource_submit").prop('disabled', false);
        }else{
          $("#resource_submit").prop('disabled', true);
        }
  });


    $( "#resource_submit" ).click(function() {
      var oTable;
      var resource_array = [];
      var all_resource = '';
      oTable = $('.dtTable').dataTable();
      var sData = $('input', oTable.fnGetNodes()).serialize();
       var spk_id_arr = sData.split('selected_resource=');

       for (var i = 1; i < spk_id_arr.length; ++i) {
            var usr_id = spk_id_arr[i].replace('&', '');
            resource_array.push(usr_id);

        }
        // console.log(resource_array);
        // var resource_array = [];
        // var all_resource = '';
        // $.each($("input[name='selected_resource']:checked"), function(){            
        //     resource_array.push($(this).val());
        // });
       all_resource = resource_array.join(",");
        //all_resource = resource_array;

         $("#speakers_list").val(resource_array);
         var uniq_token = "<?php echo $current_uid; ?>";

        if(all_resource != ''){

            $.ajax({
                      type: "POST",
                      url: "api.php",
                      //dataType: "json",
                      //contentType: "application/json",
                       //dataType: "json",
                       data: {"action": "get_speaker_info_EP_new", "resource_ids":all_resource, "uniq_token":uniq_token },
                      success: function(data){
                        $("#search-resource").modal('hide');
                        $('.selected_resource').prop('checked', false);
                        var speaker_deatils='';
                        //alert(data);
                        for(var i=0; i<data.length; i++){
                                speaker_deatils += '<tr class="test"><td>'+data[i].speaker_name+'</td><td>'+data[i].email_id+'</td><td>'+data[i].company+'</td><td>'+data[i].phone+'</td><td>'+data[i].status_name+'</td><td>'+data[i].influencer+'</td><td></td></tr>';
                              }
                               $("#speaker_info").append(data);
                           }
                    }); // end of ajax

        }

    });

     function confirmDeleteSpeaker(sid)
      {
        var uniq_token = "<?php echo $current_uid; ?>";
        var conf = confirm("Are you sure?");

        if(conf){
              $.ajax({
                      type: "POST",
                      url: "api.php",
                       data: {"action": "delete_speaker_info_EP_new","row_id":sid, "uniq_token":uniq_token  },
                      success: function(data){
                        var speaker_deatils='';
                            Swal.fire({
                                    type: 'success',
                                    title: 'Success',
                                    text: 'Deleted Successfully.',
                                    allowOutsideClick: false
                                  }).then(okay => {
                                       if (okay) {
                                         $("#speaker_info").empty();
                                          $("#speaker_info").append(data);
                                      }
                                    });
                               
                           }
                    }); // end of ajax
            }
    }

     $('#add_note').click(function(e){
    e.preventDefault();

    $(".new_add_note").html('');
    $(".new_add_note").html('<div class="note-info"><textarea class="bdr-light col-xs-12 text-left" style="padding:10px; min-height: 150px; margin-bottom: 15px;border-radius: 20px;" name="speaker_note"> </textarea><div class="clearfix"></div></div>');
        
  });

  // $('#add_note_edit_speaker').click(function(evnt){
  //   evnt.preventDefault();
  //   $(".new_add_note").html('');
  //   $(".new_add_note").html('<div class="note-info"><textarea id="dynamic_add_note_txt" class="bdr-light col-xs-12 text-left" style="padding:10px; min-height: 150px; margin-bottom: 5px;border-radius: 20px;" name="speaker_note"> </textarea><div class="clearfix"></div><button type="button" id="dynamic_add_note_btn" class="pull-right blue-n-color" style="background:none; border:none; box-shadow:none; "><img src="images/save.png" width="15" title="Add Note" ></button></div>');
      

  // });

  $(document).on("click","#dynamic_add_note_btn",function(e) {
    e.preventDefault();
    var loggedin_userid = $("#loggedin_userid").val();
    var uniq_token = "<?php echo $current_uid; ?>";
    var note_val = $.trim($("#dynamic_add_note_txt").val());
    if(note_val != '' && note_val != null){

      if(note_val != '' && note_val != null){
      //alert(speaker_id);

      $.ajax({
        type: "POST",
        url: "ajaxCalls.php",
        async:false,
        data: {"note_val":note_val,"loggedin_userid":loggedin_userid,"uniq_token":uniq_token ,"action":"add_new_speaker_note"} ,
        success: function(data) {
        if(data == 'success'){
          $('#addNote').modal('hide');
          $("#dynamic_add_note_txt").val('');
          //call old notes function
          $(".new_add_note").html('');
          $("#note_added_status").text('Note created successfully!').show();
          setTimeout(function() { $("#note_added_status").hide(); }, 4000);
           fetch_speaker_notes(uniq_token);
        }       
        }
      });
    }


    }else{
      $("#dynamic_add_note_txt").addClass('emptyField');

    }

    

            
    });

  function  fetch_speaker_notes(uniq_token){
  //  alert("function in ");
  //var uniq_token = "<?php echo $current_uid; ?>";
      $.ajax({
                type: "POST",
                url: "ajaxCalls.php",
                //contentType: "application/json",
                dataType: "json",
                // async:false,
                data: {"action": "fetch_speaker_notes_by_uniqueid", "uniq_token" : uniq_token },
                success: function(data) { 

                  var old_notes_html = '';

                  for(var i=0; i<data.length; i++){
                    // alert(data[i].notes);
                    old_notes_html += '<tr class="test"><td><p>'+data[i].notes+' </p></td><td>'+data[i].createdon+'</td><td>'+data[i].created_by_name+'</td><td><p style="display:table;margin:auto;"><button type="button" onClick="Assign_noteid(' + data[i].id + ')" id="edit_note_info" style="background:none; border:none; box-shadow:none; "><img src="images/edit.png" alt="Edit" width="15" title="Edit"></button></p></td></tr>';

                  }
                  $("#old_notes").empty();
                  $("#old_notes").append(old_notes_html);
                     // alert(data[0].notes);
                  // alert(data[0]);
                  //window.location.href= page_name+"?delete-success";

                }
           });

    }

     function Assign_noteid(row_id)
    {
      $('#EditNote').modal('show');
      $("#hidden_noteid").val(row_id);
      GetDatatoEditNote();
    }


    function GetDatatoEditNote() {
       var row_id = $("#hidden_noteid").val();
         $.ajax({
          url: 'insert_assignroles.php',
          type: 'POST',
          data: {'Requestfor':'fetch_noteval_new','row_id': row_id},
          //dataType: 'JSON',
          success: function(response){
             if (response != null) {
                          document.getElementById('edit_note_txt').value = response;
                    }
           }
      });      
  }

   function save_EditNote()
  {
    var note_id = $("#hidden_noteid").val();
    var loggedin_userid = $("#loggedin_userid").val();
    var note_text = $.trim($("#edit_note_txt").val());
   var uniq_token = "<?php echo $current_uid; ?>";

      $.ajax({
        type: "POST",
        url: "ajaxCalls.php",
        async:false,
        data: {"note_id":note_id,"note_val":note_text,"loggedin_userid":loggedin_userid,"uniq_token":uniq_token ,"action":"update_new_speaker_note"} ,
        success: function(data) {
        if(data == 'success'){
           $('#EditNote').modal('hide');
          $("#note_added_status").text('Note has been updated successfully').show();
          setTimeout(function() { $("#note_added_status").hide(); }, 4000);
           fetch_speaker_notes(uniq_token);
        }       
        }
      });

  }

    $(document).on("click","#dynamic_add_colb_note_btn",function(e) {
    e.preventDefault();
    var loggedin_userid2 = $("#loggedin_userid").val();
    var uniq_token2 = "<?php echo $current_uid; ?>";
    var note_val2 = $.trim($("#colb_note_txt").val());
    if(note_val2 != '' && note_val2 != null){

      if(note_val2 != '' && note_val2 != null){
      //alert(speaker_id);

      $.ajax({
        type: "POST",
        url: "ajaxCalls.php",
        async:false,
        data: {"note_val":note_val2,"loggedin_userid":loggedin_userid2,"uniq_token":uniq_token2 ,"action":"add_new_coloboration_note"} ,
        success: function(data) {
        if(data == 'success'){
          $('#addColoborationNote').modal('hide');
          $("#colb_note_txt").val('');
          //call old notes function
          $(".new_coloboration_add_note").html('');
          $("#note_coloboration_added_status").text('Note created successfully!').show();
          setTimeout(function() { $("#note_coloboration_added_status").hide(); }, 4000);
           fetch_coloboration_notes(uniq_token2);
        }       
        }
      });
    }


    }else{
      $("#colb_note_txt").addClass('emptyField');

    }
       
    });

    function  fetch_coloboration_notes(uniq_token){
      $.ajax({
                type: "POST",
                url: "ajaxCalls.php",
                //contentType: "application/json",
                dataType: "json",
                // async:false,
                data: {"action": "fetch_coloboration_notes_by_uniqueid", "uniq_token" : uniq_token },
                success: function(data) { 

                  var old_notes_html = '';

                  for(var i=0; i<data.length; i++){
                    // alert(data[i].notes);
                    old_notes_html += '<tr class="test"><td><p>'+data[i].notes+' </p></td><td>'+data[i].createdon+'</td><td>'+data[i].created_by_name+'</td><td><p style="display:table;margin:auto;"><button type="button" onClick="Assign_colo_noteid(' + data[i].id + ')" id="edit_note_info_c" style="background:none; border:none; box-shadow:none; "><img src="images/edit.png" alt="Edit" width="15" title="Edit"></button></p></td></tr>';

                  }
                  $("#old_coloboration_notes").empty();
                  $("#old_coloboration_notes").append(old_notes_html);
                     // alert(data[0].notes);
                  // alert(data[0]);
                  //window.location.href= page_name+"?delete-success";

                }
           });

    }

     function Assign_colo_noteid(row_id)
    {
      $('#EditNote_coloboration').modal('show');
      $("#hidden_colboration_noteid").val(row_id);
      GetDatatoEditNote_colboration();
    }

    function GetDatatoEditNote_colboration() {
       var row_id2 = $("#hidden_colboration_noteid").val();
         $.ajax({
          url: 'insert_assignroles.php',
          type: 'POST',
          data: {'Requestfor':'fetch_noteval_new_colboration','row_id': row_id2},
          //dataType: 'JSON',
          success: function(response){
             if (response != null) {
                          document.getElementById('edit_colob_note_txt').value = response;
                    }
           }
      });      
  }

   function save_EditNote_colboration()
  {
    var note_id2 = $("#hidden_colboration_noteid").val();
    var loggedin_userid2 = $("#loggedin_userid").val();
    var note_text2 = $.trim($("#edit_colob_note_txt").val());
   var uniq_token2 = "<?php echo $current_uid; ?>";

      $.ajax({
        type: "POST",
        url: "ajaxCalls.php",
        async:false,
        data: {"note_id":note_id2,"note_val":note_text2,"loggedin_userid":loggedin_userid2,"uniq_token":uniq_token2 ,"action":"update_new_coloboration_note"} ,
        success: function(data) {
        if(data == 'success'){
           $('#EditNote_coloboration').modal('hide');
          $("#note_coloboration_added_status").text('Note has been updated successfully').show();
          setTimeout(function() { $("#note_coloboration_added_status").hide(); }, 4000);
           fetch_coloboration_notes(uniq_token2);
        }       
        }
      });

  }


  $(document).ready(function() {
  $("#p_topic").on('keyup', function() {
    var words = $(this).val().length;

    if (words > 100) {
      // Split the string on first 200 words and rejoin on spaces
      var trimmed = $(this).val().substring(0, 99);
      // Add a space at the end to make sure more typing creates new words
      $(this).val(trimmed);
    }
    else {
      //$('#display_count').text(words);
      $('#word_left').text(100-words);
    }
   });
});   

  $(document).ready(function() {
  $("#abstract").on('keyup', function() {
    var words = $(this).val().length;

    if (words > 500) {
      // Split the string on first 200 words and rejoin on spaces
      var trimmed = $(this).val().substring(0, 500);
      // Add a space at the end to make sure more typing creates new words
      $(this).val(trimmed);
    }
    else {
      //$('#word_left_abs').text(words);
      $('#word_left_abs').text(500-words);
    }
  });
});

  $(document).ready(function() {
  $("#bussiness_objective").on('keyup', function() {
    var words = $(this).val().length;

    if (words > 200) {
      // Split the string on first 200 words and rejoin on spaces
      var trimmed = $(this).val().substring(0, 200);
      // Add a space at the end to make sure more typing creates new words
      $(this).val(trimmed);
    }
    else {
      //$('#display_count').text(words);
      $('#word_left_bobj').text(200-words);
    }
  });
});
    if(window.location.href.indexOf("created-success") > -1) {
       $('.created-success').fadeIn(200).delay(2000).fadeOut(2000);
  }

jQuery(document).on('blur', '#end_time', function () {
     var stt = new Date("November 13, 2013 " + $('#start_time').val());
   var ett = new Date("November 13, 2013 " + $('#end_time').val());
     if(stt >= ett){
      document.getElementById("edtime").innerHTML = "End time should be greater than start time";
      errorFlag=1;
      $("#create_presentation").attr("disabled", true);
      $("#create_presentation_save_exit").attr("disabled", true);
       
    }else
    {
      $("#create_presentation").attr("disabled", false);
      $("#create_presentation_save_exit").attr("disabled", false);
      document.getElementById("edtime").innerHTML = "";
    }

  });
  
</script>

 <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js'></script>
<script type="text/javascript">$(function () {
  $("#datepicker1").datepicker({ 
        format:'dd-M-yyyy',
        startDate: new Date(),
        autoclose: true, 
        todayHighlight: true
  }).datepicker('update', new Date());
  // $("#datepicker1").datepicker({ 
  //       format:'dd-MM-yyyy',
  //       minDate: new Date(),
  //       autoclose: true, 
  //       todayHighlight: true
  // }).datepicker('update', new Date());
});</script>

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript">
function destroy_datatable()
  {
   jQuery('.dtTable').DataTable().destroy(); 
  }
</script>
<script type="text/javascript">
  $('.timepicker').click(function(){
    $('.datepicker-dropdown').hide();
  });
</script>