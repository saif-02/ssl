<?php

class commonFunctions{
  
    var $connect;
    var $connection;
    function connect()
    {
        //$this->connect = new mysqli("localhost", "root", "", "kb_db_live_jan16");
        $this->connect = new mysqli("speakerengage.mysql.database.azure.com", "speakerengage@speakerengage", "nX9qW65s47w3KegJ", "speakerengage_live");
        return $this->connect;
    }
    
    function Login()
    {

        if(empty($_POST['email']))
        {
            $this->HandleError("email address is empty!");
            return false;
        }
        
        if(empty($_POST['password']))
        {
            $this->HandleError("Password is empty!");
            return false;
        }
        
        $username = trim($_POST['email']);
        $password = trim($_POST['password']);
        

        
        if(!isset($_SESSION)){ session_start(); }
        if(!$this->CheckLoginInDB($username,$password))
        {
            
            return false;
        }
        $_SESSION[$this->GetLoginSessionVar()] = $username;
        
        return true;
    }
    
    function CheckLogin()
    {
         if(!isset($_SESSION)){ session_start(); }

         //$sessionvar = $this->GetLoginSessionVar();
         // var_dump("Hiiii Dude: ".$); exit();
         
         if(empty($_SESSION['user_id']) || is_null($_SESSION['user_id']) )
         {
            return false;
         }
         return true;
    }

    function CheckEventSession()
    {
         if(!isset($_SESSION)){ session_start(); }

         //$sessionvar = $this->GetLoginSessionVar();
         
         if(empty($_SESSION['current_event_id']) || $_SESSION['current_event_id'] == null)
         {
            $this->RedirectToURL('login.php');
         }
         return true;
    }


    function checkUserSession()
    {
        if(!isset($_SESSION)){ session_start(); }
        if(empty($_SESSION['user_id']) || $_SESSION['user_id'] == null)
         {
            $this->RedirectToURL('login.php');
         }
         return true;
    }



     function RedirectToURL($url)
    {
        header("Location: $url");
        exit;
    }
    function DBLogin()
    {
        
       
        $this->connect = $this->connect();

        return true;
    }    
     function SanitizeForSQL($str)
    {
        if( function_exists( "mysqli_real_escape_string" ) )
        {
              $ret_str = mysqli_real_escape_string($this->connection,$str );
        }
        else
        {
              $ret_str = addslashes( $str );
        }
        return $ret_str;
    }
    function GetLoginSessionVar()
    {
        $retvar = md5('0iQx5oBks3266oVZdep');
        $retvar = 'wap_'.substr($retvar,0,10);
        return $retvar;
    }
    
    function CheckLoginInDB($username,$password)
    {
        if(!$this->DBLogin())
        {
            $this->HandleError("Database login failed!");
            return false;
        } 
         $tanent_id=0;
        $username = $username;
        $qry = "SELECT * from all_users where email='$username' AND confirmcode = 'y' ";
        $result = mysqli_query($this->connect,$qry);
        $error_flag=0;
        if(!$result || mysqli_num_rows($result) <= 0)
        {
            $error_flag=1;           
        }        
        $row = mysqli_fetch_assoc($result);
        $checking = password_verify($password,$row['password']);
        if ($checking) {
            $tenant_id_fetched = $row['tanent_id'];
           
            //set tenant id in session
            $fetch_tenant_subscription_id =  mysqli_query($this->connect,"SELECT * FROM all_users WHERE  tanent_id='".$tenant_id_fetched."' ");
            $res_sub = mysqli_fetch_array($fetch_tenant_subscription_id);
            // $subscription_id = $res_sub['subscription_id'];
            // $_SESSION['subscription_id'] = $subscription_id;

            $_SESSION['user_email']         =   $username;
            $_SESSION['user_id']            =   $row['user_id'];
            $_SESSION['user_role']          =   $_SESSION['role'] = $row['role'];
            
            /*if( @$row['customer_id'] OR @$row['subscription_id'])
            {
                $_SESSION['customer_id']        =   $row['customer_id'];
            }*/

            $user_id    =   $row['user_id'];
            $client_ip  =   $_SERVER['REMOTE_ADDR'];
            $tanent_id  =   $row['tanent_id'];

            $ua=$this->getBrowser();
            $yourbrowser= $ua['name'];

            

             $sql = "INSERT INTO all_login_logs(tanent_id,email_id,client_ip,created_at,login_status,login_type,browser_name,user_id) VALUES ('".$tanent_id."','".$username."','".$client_ip."',now(),'success','Web','".$yourbrowser."','".$user_id."')";
              mysqli_query($this->connect, $sql);

            return true;
        }else{
            $error_flag=1;
           
        }   
        if($error_flag==1){
             $client_ip=$_SERVER['REMOTE_ADDR'];
             $ua=$this->getBrowser();
             $yourbrowser= $ua['name'];

             $sql = "INSERT INTO all_login_logs(tanent_id,email_id,client_ip,created_at,login_status,login_type,browser_name) VALUES ('".$tanent_id."','".$username."','".$client_ip."',now(),'failed','Web','".$yourbrowser."')";
              mysqli_query($this->connect, $sql);
              
             $this->HandleError("Error logging in. The email address or password does not match.");
            return false;
        }       
         
    }

    function getBrowser()
    {
    $u_agent = $_SERVER['HTTP_USER_AGENT'];
    $bname = 'Unknown';
    $platform = 'Unknown';
    $version= "";

    //First get the platform?
    if (preg_match('/linux/i', $u_agent)) {
        $platform = 'linux';
    }
    elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        $platform = 'mac';
    }
    elseif (preg_match('/windows|win32/i', $u_agent)) {
        $platform = 'windows';
    }

    // Next get the name of the useragent yes seperately and for good reason
    if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent))
    {
        $bname = 'Internet Explorer';
        $ub = "MSIE";
    }
    elseif(preg_match('/Firefox/i',$u_agent))
    {
        $bname = 'Mozilla Firefox';
        $ub = "Firefox";
    }
    elseif(preg_match('/Chrome/i',$u_agent))
    {
        $bname = 'Google Chrome';
        $ub = "Chrome";
    }
    elseif(preg_match('/Safari/i',$u_agent))
    {
        $bname = 'Apple Safari';
        $ub = "Safari";
    }
    elseif(preg_match('/Opera/i',$u_agent))
    {
        $bname = 'Opera';
        $ub = "Opera";
    }
    elseif(preg_match('/Netscape/i',$u_agent))
    {
        $bname = 'Netscape';
        $ub = "Netscape";
    }

    // finally get the correct version number
    $known = array('Version', $ub, 'other');
    $pattern = '#(?<browser>' . join('|', $known) .
    ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $u_agent, $matches)) {
        // we have no matching number just continue
    }

    // see how many we have
    $i = count($matches['browser']);
    if ($i != 1) {
        //we will have two since we are not using 'other' argument yet
        //see if version is before or after the name
        if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
            $version= $matches['version'][0];
        }
        else {
            $version= $matches['version'][1];
        }
    }
    else {
        $version= $matches['version'][0];
    }

    // check if we have a number
    if ($version==null || $version=="") {$version="?";}

    return array(
        'userAgent' => $u_agent,
        'name'      => $bname,
        'version'   => $version,
        'platform'  => $platform,
        'pattern'    => $pattern
    );
    }
    
    function subscription_retrive()
    {
        include("./payment/config.php");
        
        $result = ChargeBee_Subscription::retrieve($_SESSION['subscription_id']);
        $user['subscription'] = $result->subscription(); 
        $user['customer'] = $result->customer();
        $user['card'] = $result->card();    
        
        return  $user;  
    }

    function subscription_retrive_by_subscription_id($subscription_id=null)
    {
        include("../payment/config.php");
        $user = array();
        $result = ChargeBee_Subscription::retrieve($subscription_id);
        $user['subscription'] = $result->subscription();
        $user['customer'] = $result->customer();
        $user['card'] = $result->card();    
        
        return  $user;  
    }

     function subscription_retrive_by_subscription_id_new($subscription_id=null)
    {
        include("./payment/config.php");
        $user = array();
        $result = ChargeBee_Subscription::retrieve($subscription_id);
        $user['subscription'] = $result->subscription();
        $user['customer'] = $result->customer();
        $user['card'] = $result->card();    
        
        return  $user;  
    }
    
    function add_subscription_id($subscription_id, $email, $tenant_id, $plan_id)
        {
        //mysqli_query($this->connect, "UPDATE all_users SET `subscription_id` = '".$subscription_id."' WHERE email = '".$email."'");
                //subscription_status

                 
                 mysqli_query($this->connect, "UPDATE all_users SET `subscription_id` = '".$subscription_id."', subscription_status = '".$plan_id."' WHERE tanent_id = '".$tenant_id."'");

                $update_query_plan_id = "UPDATE all_tenants SET plan_id = '".$plan_id."' WHERE id = '".$tenant_id."'";
                mysqli_query($this->connect, $update_query_plan_id);
        }



    function check_trial_period($user_id=null){
        //var_dump($user_id); 

        $sql = mysqli_query($this->connect,"SELECT * FROM all_users WHERE user_id=".$user_id);
        $row = mysqli_fetch_array($sql);        
        $tanent_id_f= $row['tanent_id'];
        $subscription_id_f= $row['subscription_id'];
        // $subscription_status = $row2['subscription_status'];

        $check_tenant_subs = mysqli_query($this->connect,"SELECT * FROM `all_tenants` WHERE `id` = '".$tanent_id_f."' ");
        $res_ten = mysqli_fetch_array($check_tenant_subs);
        $tenant_created_at = date('Y-m-d',strtotime($res_ten['created_at']));

        $subscription_status = $res_ten['status'];

        $now = time(); // or your date as well
        $your_date = strtotime($tenant_created_at);
        $datediff = $now - $your_date;

        $final_date= round($datediff / (60 * 60 * 24));

        if($final_date > 100){
            
            if($subscription_status != 'active')
            {
              echo "<script>
                    window.location = 'subscribe-package.php';
                    </script>";              
            }

            /*if( $subs_status == "active"){              
                header("location:choose-package.php");  
            }*/

        }


    }

    
    function UserFullName()
    {
        return isset($_SESSION['name_of_user'])?$_SESSION['name_of_user']:'';
    }
    
    function UserEmail()
    {
        return isset($_SESSION['user_email'])?$_SESSION['user_email']:'';
    }
    
    function PhoneNumber()
    {
        return isset($_SESSION['phone_number'])?$_SESSION['phone_number']:'';
    }
    
    function UserName()
    {
        return isset($_SESSION['username_of_user'])?$_SESSION['username_of_user']:'';
    }
    
    function UserPassword()
    {
        return isset($_SESSION['password_of_user'])?$_SESSION['password_of_user']:'';
    }
    
    function UserRole()
    {
        return isset($_SESSION['user_role'])?$_SESSION['user_role']:'';
    }
    
    function ProfilePic()
    {
        return isset($_SESSION['profile_pic'])?$_SESSION['profile_pic']:'';
    }
    
    function idUser()
    {
        return isset($_SESSION['user_id'])?$_SESSION['user_id']:'';
    }
    
    function role()
    {
        return isset($_SESSION['role'])?$_SESSION['role']:'';
    }
    
    function LogOut()
    {
        session_start();
        
        $sessionvar = $this->GetLoginSessionVar();
        
        //$_SESSION[$sessionvar]=NULL;        
        //unset($_SESSION[$sessionvar]);
        session_unset(); 
        
        session_destroy();
    }
    
     function GetErrorMessage()
    {
        if(empty($this->error_message))
        {
            return '';
        }
        $errormsg = nl2br(htmlentities($this->error_message));
        return $errormsg;
    }    
    //-------Private Helper functions-----------
    
    function HandleError($err)
    {
        $this->error_message = $err."\r\n";
    }
    
    function HandleDBError($err)
    {
        $this->HandleError($err."\r\n Error inserting into database");
    }



    function sendEmail($to, $from, $subject, $body, $fromName=null, $cc_mails=null){
        
        $url = 'https://api.sendgrid.com/';
         $user = 'Meylahcorp';
         $pass = 'Em@ils19!';

        $json_string = array(

          'to' =>$to,
          'category' => 'test_category'
        );

        /*if(empty($from)){
            $from = "support@speakerengage.com";
        }*/
        $new_form = "notify@speakerengage.com";    
            

        if($fromName != null){

            if( !empty($from) ){
               $fromName = $fromName." (".$from.") via" ;
            }

            $param_middle = array();

            if($cc_mails != null || $cc_mails != '' ){
                $cc_array = explode(",", $cc_mails);

            $params = array(
                'api_user'  => $user,
                'api_key'   => $pass,
                'to'        => $to,
                'cc[0]'     => $cc_array[0],
                'cc[1]'     => $cc_array[1],
                'cc[2]'     => $cc_array[2],
                'cc[3]'     => $cc_array[3],
                'cc[4]'     => $cc_array[4],
                'subject'   => $subject,
                'html'      => $body,
                'text'      => "",
                'from'      => $new_form,
                'fromname'  => $fromName,
                'replyto'   => $from,          
              );

          }else{

             $params = array(
                'api_user'  => $user,
                'api_key'   => $pass,
                'to'        => $to,
                'subject'   => $subject,
                'html'      => $body,
                'text'      => "",
                'from'      => $new_form,
                'fromname'  => $fromName,
                'replyto'   => $from,             
              );
          }
        }else{
            $fromName = "Speaker Engage Team";
            
            $params = array(
            'api_user'  => $user,
            'api_key'   => $pass,
            'to'        => $to,
            'subject'   => $subject,
            'html'      => $body,
            'text'      => "",
            'from'      => $new_form,
            'fromname'  => $fromName,
            'replyto'   => $from,   
          );
        }   

        $request =  $url.'api/mail.send.json';

        // Generate curl request
        $session = curl_init($request);
        // Tell curl to use HTTP POST
        curl_setopt ($session, CURLOPT_POST, true);
        // Tell curl that this is the body of the POST
        curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
        // Tell curl not to return headers, but do return the response
        curl_setopt($session, CURLOPT_HEADER, false);
        // Tell PHP not to use SSLv3 (instead opting for TLS)
        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
        // obtain response
        $response = curl_exec($session);
        curl_close($session);
        // print everything out
        //print_r($response);exit;
    }


    function array_push_assoc($array, $key, $value){
        $array[$key] = $value;
        return $array;
    }


     function GetAbsoluteURLFolder()
    {
        $scriptFolder = (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on')) ? 'https://' : 'http://';
        $scriptFolder .= $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']);
        $clean_link = str_replace('\\','',$scriptFolder);
        return $clean_link;
    }
    
     function GetResetPasswordCode($email)
    {
       return substr(md5($email.$this->sitename.$this->rand_key),0,10);
    }
    
     function SendResetPasswordLink($user_rec)
    {
        $to = $user_rec['email'];
        $email=$user_rec['email'];
        $link = $this->GetAbsoluteURLFolder().
                '/resetpwd.php?email='.
                urlencode($email).'&code='.
                urlencode($this->GetResetPasswordCode($email));
        $messageparam = '<table border="0" cellpadding="0" cellspacing="0"> 
        <tr> 
            <td colspan="3" height="20"></td> 
        </tr> 
        <tr> 
            <td width="20"></td> 
            <td align="left" style="font-size:16px; color:#000001; font-family:serif;"> 
            Hello '.$user_rec['first_name'].' <br><br> You recently requested to reset your password for your Grays Harbor account.  <br>Please click the below link to reset the password.<br>Link:<br><br>'.$link.'<br><br>If you did not request a password reset, please ignore this email or send an email to support@support.com to let us know.<br><br>Yours,<br>Grays Harbor Team<br>.
            </td> 
            <td width="20"></td> 
        </tr> 
        <tr> 
            <td colspan="3" height="20"></td> 
        </tr> 
        </table>';
        $subject = " Reset your Password";
        $this->sendEmail($to,$subject,"noreplay@meylah.com",$messageparam);
        
    }
    
    
     function EmailResetPasswordLink()
    {
        $user_rec = array();
        if(empty($_POST['email']))
        {
            $this->HandleError("Email address is empty!");
            return false;
        }
        
        else if(false === $this->GetUserFromEmail($_POST['email'], $user_rec))
        {
            return false;
        }
        else if(false === $this->SendResetPasswordLink($user_rec))
        {
            return false;
        }else{
             $this->HandleError("Email is Successfully sent to '".$_POST['email']."'");
        return true;
        }
       
    }
    
    function ResetPassword()
    {
        if(empty($_GET['email']))
        {
            $this->HandleError("Email address is empty!");
            return false;
        }
        if(empty($_GET['code']))
        {
            $this->HandleError("reset code is empty!");
            return false;
        }
        $email = trim($_GET['email']);
        $code = trim($_GET['code']);
        
        if($this->GetResetPasswordCode($email) != $code)
        {
            $this->HandleError("Bad reset code!");
            return false;
        }
        
        $user_rec = array();
        if(!$this->GetUserFromEmail($email,$user_rec))
        {
            return false;
        }
        
        $new_password = $this->ResetUserPasswordInDB($user_rec);
        if(false === $new_password || empty($new_password))
        {
            $this->HandleError("Error updating new password");
            return false;
        }
        
        if(false == $this->SendNewPassword($user_rec,$new_password))
        {
            $this->HandleError("Error sending new password");
            return false;
        }
        return true;
    }
    
    function ChangePassword()
    {
        if(!$this->CheckLogin())
        {
            $this->HandleError("Not logged in!");
            return false;
        }
        
        if(empty($_POST['old_password']))
        {
            $this->HandleError("Old password is empty!");
            return false;
        }
        if(empty($_POST['new_password']))
        {
            $this->HandleError("New password is empty!");
            return false;
        }
        
        $user_rec = array();
        if(!$this->GetUserFromEmail($this->UserEmail(),$user_rec))
        {
            return false;
        }
        
        $pwd = trim($_POST['old_password']);
        $password = "";
        if(password_verify($pwd,$user_rec['password']))
        {
            $newpwd = trim($_POST['new_password']);
            $newpwd = $this->SanitizeForSQL($newpwd);
            $password = password_hash($newpwd, PASSWORD_DEFAULT, ['cost' => 11]);
        }
        else{
            $this->HandleError("The old password does not match!");
            return false;
        }
        if(!$this->ChangePasswordInDB($user_rec, $password))
        {
            return false;
        }
        return true;
    }
    
    
    
    function sendSms($to,$body){
        $data = "workingkey=A4e27a5bfda4ca2ca00c3267513ee1792&sender=CARZIP&to=".$to."&message=".$body;
        $ch = curl_init('http://trans.kapsystem.com/api/web2sms.php');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
    }
    
    function pagination($table_name, $where_condition, $adjacents, $limit, $page, $targetpage, $join=Null, $star = Null )
        {
            
            $mysqliConnect = new mysqliConnect();
            $connect = $mysqliConnect->connect();
            
            $sql = "SELECT * from ".$table_name." WHERE 1 ".$where_condition."";
            if($star){
                $sql = "SELECT *".$star." from ".$table_name."  WHERE 1 ".$where_condition."";
            }
            if($join){
                $sql = "SELECT *".$star." from ".$table_name." ".$join." WHERE 1 ".$where_condition."";
            }
            
            $query = $sql;
            $ss = mysqli_query($connect,$query);
            $total_pages = mysqli_num_rows($ss);

            //your file name  (the name of this file)
            
            if($page)
                $start = ($page - 1) * $limit;          //first item to display on this page
            else
                $start = 0;                             //if no page var is given, set start to 0

            /* Get data. */
            $sql = $sql." LIMIT $start, $limit";
            $result = mysqli_query($connect,$sql);

            /* Setup page vars for display. */
            if ($page == 0) $page = 1;                  //if no page var is given, default to 1.
            $prev = $page - 1;                          //previous page is page - 1
            $next = $page + 1;                          //next page is page + 1
            $lastpage = ceil($total_pages/$limit);      //lastpage is = total pages / items per page, rounded up.
            $lpm1 = $lastpage - 1;                      //last page minus 1

            /*
                Now we apply our rules and draw the pagination object.
                We're actually saving the code to a variable in case we want to draw it more than once.
            */
            $pagination = "";
            
            if($lastpage > 1)
            {
                $pagination .= "<div class=\"pagination dataTables_paginate paging_simple_numbers\" id=\"datatable_paginate\">";
                //previous button
                if ($page > 1)
                    $pagination.= "<a href=\"$targetpage&page=$prev\" class=\"paginate_button previous\">Previous</a>";
                else
                    $pagination.= "<span class=\"disabled paginate_button previous\">Previous</span>";

                //pages
                if ($lastpage < 7 + ($adjacents * 2))    //not enough pages to bother breaking it up
                {
                    for ($counter = 1; $counter <= $lastpage; $counter++)
                    {
                        if ($counter == $page)
                            $pagination.= "<span class=\"current paginate_button \">$counter</span>";
                        else
                            $pagination.= "<a href=\"$targetpage&page=$counter\" class=\"paginate_button \">$counter</a>";
                    }
                }
                elseif($lastpage > 5 + ($adjacents * 2)) //enough pages to hide some
                {
                    //close to beginning; only hide later pages
                    if($page < 1 + ($adjacents * 2))
                    {
                        for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
                        {
                            if ($counter == $page)
                                $pagination.= "<span class=\"current paginate_button \">$counter</span>";
                            else
                                $pagination.= "<a href=\"$targetpage&page=$counter\" class=\"paginate_button \">$counter</a>";
                        }
                        $pagination.= "...";
                        $pagination.= "<a href=\"$targetpage&page=$lpm1\" class=\"paginate_button \">$lpm1</a>";
                        $pagination.= "<a href=\"$targetpage&page=$lastpage\" class=\"paginate_button \">$lastpage</a>";
                    }
                    //in middle; hide some front and some back
                    elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
                    {
                        $pagination.= "<a href=\"$targetpage&page=1\" class=\"paginate_button \">1</a>";
                        $pagination.= "<a href=\"$targetpage&page=2\" class=\"paginate_button \">2</a>";
                        $pagination.= "...";
                        for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
                        {
                            if ($counter == $page)
                                $pagination.= "<span class=\"current paginate_button\">$counter</span>";
                            else
                                $pagination.= "<a href=\"$targetpage&page=$counter\" class=\"paginate_button \">$counter</a>";
                        }
                        $pagination.= "...";
                        $pagination.= "<a href=\"$targetpage&page=$lpm1\" class=\"paginate_button \">$lpm1</a>";
                        $pagination.= "<a href=\"$targetpage&page=$lastpage\" class=\"paginate_button \">$lastpage</a>";
                    }
                    //close to end; only hide early pages
                    else
                    {
                        $pagination.= "<a href=\"$targetpage&page=1\">1</a>";
                        $pagination.= "<a href=\"$targetpage&page=2\">2</a>";
                        $pagination.= "...";
                        for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
                        {
                            if ($counter == $page)
                                $pagination.= "<span class=\"current paginate_button\">$counter</span>";
                            else
                                $pagination.= "<a href=\"$targetpage&page=$counter\" class=\"paginate_button \">$counter</a>";
                        }
                    }
                }

                //next button
                if ($page < $counter - 1)
                    $pagination.= "<a href=\"$targetpage&page=$next\">Next</a>";
                else
                    $pagination.= "<span class=\"disabled \">Next</span>";
                $pagination.= "</div>\n";
            }
            return $sql."~".$pagination;
        }
        
      function fetch_all_status($val,$evt_id=null){
        $event_id= $evt_id;
       $fetch_all_status = mysqli_query($this->connect,"SELECT * FROM all_status WHERE all_status.status_for='".$val."' and event_id='".$event_id."'");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_status) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_status)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_roles_master($var){

        $fetch_all_roles = mysqli_query($this->connect,"SELECT * FROM manage_master WHERE code = '$var' ORDER BY line_order ASC");
        $rinner_array = array();
        if(mysqli_num_rows($fetch_all_roles) > 0)
        {
            while($row = mysqli_fetch_array($fetch_all_roles)){
                $rinner_array[] = $row;
            }
            return $rinner_array;
        }
        else{
            return $rinner_array;
        }
    }

    function fetch_master($var){

        $fetch_all_roles = mysqli_query($this->connect,"SELECT * FROM manage_master WHERE code = '$var' ORDER BY line_order ASC");
        $rinner_array = array();
        if(mysqli_num_rows($fetch_all_roles) > 0)
        {
            while($row = mysqli_fetch_array($fetch_all_roles)){
                $rinner_array[] = $row;
            }
            return $rinner_array;
        }
        else{
            return $rinner_array;
        }
    }
    
     function fetch_all_status_asc($val, $event_id=null){

          // $event_id= $_SESSION['current_event_id'];
        $fetch_all_status = mysqli_query($this->connect,"SELECT * FROM all_status WHERE all_status.status_for='".$val."' and event_id='".$event_id."' ORDER BY status_name ASC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_status) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_status)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    

    function fetch_master_approval_status(){

        $fetch_all_status = mysqli_query($this->connect,"SELECT * FROM master_approval_staus  ORDER BY id ASC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_status) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_status)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_master_approval_new_status(){

        $fetch_all_status = mysqli_query($this->connect,"SELECT * FROM master_approval_staus WHERE id not in(1) ORDER BY id ASC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_status) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_status)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    
    
    function fetch_all_speakers($start=1,$limit=null,$evtid=null){

        $event_id= $evtid;
        $fetch_all_speakers = mysqli_query($this->connect,"SELECT all_status.status_name,company,phone,speaker_type,profile_completeness,speaker_name,email_id,social_media_total_score,all_status.id as status_id,all_speakers.id as id,0 as log_id,now() as created_at,'AA' as template_name,0 as template_id,mail_sent_count as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.status != '' and all_speakers.event_id = '".$event_id."'  ORDER BY all_speakers.id DESC LIMIT $start, $limit");

         // $fetch_all_speakers = mysqli_query($this->connect,"SELECT all_status.status_name,company,phone,speaker_type,profile_completeness,speaker_name,email_id,social_media_total_score,all_status.id as status_id,all_speakers.id as id,0 as log_id,(select created_at from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as created_at,'AA' as template_name,(select other_column_value from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as template_id,(select count(*) from all_logs  WHERE table_id=all_speakers.id AND (operation='sent email to speaker' OR operation='sent email to speaker scheduled' OR all_logs.operation='request missing information' OR all_logs.operation='request missing documents' OR all_logs.operation='request missing information scheduled' OR all_logs.operation='request missing documents scheduled')) as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.status != '' and all_speakers.event_id = '".$event_id."'  ORDER BY all_speakers.id DESC LIMIT $start, $limit");

        // $fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_status.id as status_id,all_speakers.id as id, (select other_column_value from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as created_at, (select count(*) from all_logs  WHERE table_id=all_speakers.id AND (operation='sent email to speaker' OR operation='sent email to speaker scheduled' OR all_logs.operation='request missing information' OR all_logs.operation='request missing documents' OR all_logs.operation='request missing information scheduled' OR all_logs.operation='request missing documents scheduled')) as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.status != '' and all_speakers.event_id = '".$event_id."'  ORDER BY all_speakers.id DESC");   

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    function fetch_all_speakers_new($start=1,$limit=null,$evtid=null){

        $event_id= $evtid;

         $fetch_all_speakers = mysqli_query($this->connect,"SELECT all_status.status_name,company,phone,speaker_type,profile_completeness,speaker_name,email_id,social_media_total_score,all_status.id as status_id,all_speakers.id as id,0 as log_id,now() as created_at,'AA' as template_name,0 as template_id,mail_sent_count as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.status = '' and all_speakers.event_id = '".$event_id."'  ORDER BY all_speakers.id DESC LIMIT $start, $limit");

        // $fetch_all_speakers = mysqli_query($this->connect,"SELECT all_status.status_name,company,phone,speaker_type,profile_completeness,speaker_name,email_id,social_media_total_score,all_status.id as status_id,all_speakers.id as id,0 as log_id,(select created_at from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as created_at,'AA' as template_name,(select other_column_value from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as template_id,(select count(*) from all_logs  WHERE table_id=all_speakers.id AND (operation='sent email to speaker' OR operation='sent email to speaker scheduled' OR all_logs.operation='request missing information' OR all_logs.operation='request missing documents' OR all_logs.operation='request missing information scheduled' OR all_logs.operation='request missing documents scheduled')) as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.status = '' and all_speakers.event_id = '".$event_id."'  ORDER BY all_speakers.id DESC LIMIT $start, $limit");

        // $event_id= $evtid;

        //     $fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_status.id as status_id,all_speakers.id as id, (select other_column_value from all_logs WHERE table_id=all_speakers.id AND
        //      operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as template_id,
        //      (select id from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as log_id,
        //      (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name,
        //      (select created_at from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as created_at,
        //      (select count(*) from all_logs  WHERE table_id=all_speakers.id AND (operation='sent email to speaker' OR operation='sent email to speaker scheduled' OR
        //      all_logs.operation='request missing information' OR all_logs.operation='request missing documents' OR
        //      all_logs.operation='request missing information scheduled' OR all_logs.operation='request missing documents scheduled')) as count_email_sent 
        //      FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.status = '' and
        //      all_speakers.event_id = '".$event_id."'  ORDER BY all_speakers.id DESC;");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_all_masters($start=1,$limit=null,$evt_id){

            $event_id= $evt_id;

            // $fetch_all_masters = mysqli_query($this->connect,"SELECT am.id,am.company,am.master_type,am.master_name,am.email_id,am.phone,am.job_title,(select other_column_value from all_logs WHERE table_id=am.id AND (operation='sent email to master' OR operation='sent email to master scheduled') ORDER BY id DESC LIMIT 1) as template_id,(select count(id)  from all_logs WHERE table_id=am.id AND (operation='sent email to master' OR operation='sent email to master scheduled') AND event_id = '".$event_id."' ) as total_email_sent, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name FROM all_masters am WHERE event_id = '".$event_id."' AND is_approved = '1'  ORDER BY am.id DESC LIMIT $start, $limit");

            $fetch_all_masters = mysqli_query($this->connect,"SELECT am.id,am.company,am.master_type,am.master_name,am.email_id,am.phone,am.job_title,'0' as template_id,mail_sent_count as total_email_sent, 'AA' as template_name FROM all_masters am WHERE event_id = '".$event_id."' AND is_approved = '1'  ORDER BY am.id DESC LIMIT $start, $limit");

            $inner_array = array();
            if(mysqli_num_rows($fetch_all_masters) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_all_masters)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }
        }

        function fetch_all_masters_with_condition($tid,$start=1, $limit=null,$evt_id){

            $event_id= $evt_id;

            $fetch_all_masters = mysqli_query($this->connect,"SELECT am.id,am.company,am.master_type,am.master_name,am.email_id,am.phone,am.job_title,'0' as template_id,mail_sent_count as total_email_sent, 'AA' as template_name FROM all_masters am WHERE event_id = '".$event_id."' AND FIND_IN_SET('".base64_decode($tid)."', am.master_type)  ORDER BY am.id DESC LIMIT $start, $limit");
            // $fetch_all_masters = mysqli_query($this->connect,"SELECT *,all_masters.id as id, (select other_column_value from all_logs WHERE table_id=all_masters.id AND operation='sent email to master'
            // ORDER BY id DESC LIMIT 1) as template_id,(select count(id)  from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' AND event_id = '".$event_id."' )as total_email_sent, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as created_at   FROM all_masters WHERE event_id = '".$event_id."' AND FIND_IN_SET('".base64_decode($tid)."', all_masters.master_type)  ORDER BY all_masters.id DESC LIMIT $start, $limit");
            $inner_array = array();
            if(mysqli_num_rows($fetch_all_masters) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_all_masters)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }
        }


        function fetch_all_new_masters($start=1,$limit=null,$event_id=null){

            // $event_id= $_SESSION['current_event_id'];

            $fetch_all_masters = mysqli_query($this->connect,"SELECT am.id,am.company,am.master_type,am.master_name,am.email_id,am.phone,am.job_title,'0' as template_id,mail_sent_count as total_email_sent, 'AA' as template_name FROM all_masters am WHERE event_id = '".$event_id."' AND is_approved != '1'  ORDER BY am.id DESC LIMIT $start, $limit");

             // $fetch_all_masters = mysqli_query($this->connect,"SELECT am.id,am.company,am.master_type,am.master_name,am.email_id,am.phone,am.job_title,(select other_column_value from all_logs WHERE table_id=am.id AND (operation='sent email to master' OR operation='sent email to master scheduled') ORDER BY id DESC LIMIT 1) as template_id,(select count(id)  from all_logs WHERE table_id=am.id AND (operation='sent email to master' OR operation='sent email to master scheduled') AND event_id = '".$event_id."' ) as total_email_sent, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name FROM all_masters am WHERE event_id = '".$event_id."' AND is_approved != '1'  ORDER BY am.id DESC LIMIT $start, $limit");
             
            // $fetch_all_masters = mysqli_query($this->connect,"SELECT *,all_masters.id as id, (select other_column_value from all_logs WHERE table_id=all_masters.id AND operation='sent email to master'
            // ORDER BY id DESC LIMIT 1) as template_id,(select count(id)  from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' AND event_id = '".$event_id."' )as total_email_sent, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as created_at   FROM all_masters WHERE event_id = '".$event_id."'  AND is_approved != '1' ORDER BY all_masters.id DESC");
            $inner_array = array();
            if(mysqli_num_rows($fetch_all_masters) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_all_masters)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }
        }


    function fetch_all_masters_event_dashboard(){
        $fetch_all_masters = mysqli_query($this->connect,"SELECT *,all_masters.id as id, (select other_column_value from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as created_at   FROM all_masters WHERE event_id !=0 ORDER BY all_masters.id DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }


    }

     function fetch_all_events(){
        if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");   
         
         $res_sql = mysqli_fetch_array($fetch_sql);
         $tanent_id= $res_sql['tanent_id'];

        $fetch_all_events = mysqli_query($this->connect,"SELECT *  FROM all_events where tanent_id='".$tanent_id."' ORDER BY id DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_events) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_events)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }



    function fetch_all_speakers_with_conditions($var,$id,$section,$evt_id,$start=1, $limit){
    

        //$fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_status.id as status_id,all_speakers.id as id FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id");

        $event_id= $evt_id;
        
        if($section == "speakers_with_no_twitter_handles"){
            
            $condition = " all_speakers.linkedin_handle='' ";
            
        }else if($section == "speakers_with_no_linked_handles"){
            
            $condition = " all_speakers.linkedin_url='' ";
            
        }else if($section == "speakers_with_no_manager"){
            
            $condition = " all_speakers.speaker_manager='' ";
            
        }else if($section == "speakers_with_no_address"){
            
            $condition = " all_speakers.address1='' ";
            
        }else if($section == "speakers_with_no_bio"){
            
            $condition = " all_speakers.short_bio='' ";
            
        }else if($section == "speakers_with_no_headshots"){
            
            $condition = "(all_speakers.head_shot='' OR all_speakers.head_shot is null OR all_speakers.head_shot='null')";
            
        }else if($section == "speakers_with_no_mobile"){
            
            $condition = " all_speakers.phone='' ";
            
        }else if($section == "speakers_with_no_speaker_type"){
            $condition = " all_speakers.speaker_type='' ";
            
        }else if($section == "speakers_with_missing_presentation"){
            $condition = " (all_speakers.presentation_title1='' AND all_speakers.presentation_title2='' AND all_speakers.presentation_title3='') ";
            
        }else if(empty($id)){
            
            $condition = " all_status.status_name='".$var."' ";
        
        }else{
            
            $condition = "FIND_IN_SET('".base64_decode($id)."', all_speakers.speaker_type)";
            
        }
         $fetch_all_speakers = mysqli_query($this->connect,"SELECT all_status.status_name,company,phone,speaker_type,profile_completeness,speaker_name,email_id,social_media_total_score,all_status.id as status_id,all_speakers.id as id,0 as log_id,now() as created_at,'AA' as template_name,0 as template_id,mail_sent_count as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE ".$condition."  AND all_speakers.event_id = '".$event_id."' ORDER BY all_speakers.id DESC LIMIT $start, $limit");
        // $fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_status.status_name,all_status.id as status_id,all_speakers.linkedin_url,all_speakers.id as id, (select other_column_value from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as created_at,  (select count(all_logs.id) from all_logs RIGHT JOIN all_email_templates ON all_email_templates.id = all_logs.other_column_value WHERE table_id=all_speakers.id AND operation='sent email to speaker') as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE ".$condition."  AND all_speakers.event_id = '".$event_id."' ORDER BY all_speakers.id DESC LIMIT $start, $limit");
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_all_speakers_event_dashboard(){

        $fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_status.status_name,all_status.id as status_id,all_speakers.linkedin_url,all_speakers.id as id, (select other_column_value from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as created_at,  (select count(all_logs.id) from all_logs RIGHT JOIN all_email_templates ON all_email_templates.id = all_logs.other_column_value WHERE table_id=all_speakers.id AND operation='sent email to speaker') as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.event_id != 0 AND all_speakers.status !=''  ORDER BY all_speakers.id DESC");
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
       function fetch_all_speakers_with_conditions_new($var,$id,$section,$evt_id){
    

        $event_id= $evt_id;
        
        if($section == "speakers_with_no_twitter_handles"){
            
            $condition = " all_speakers.linkedin_handle='' ";
            
        }else if($section == "speakers_with_no_linked_handles"){
            
            $condition = " all_speakers.linkedin_url='' ";
            
        }else if($section == "speakers_with_no_manager"){
            
            $condition = " all_speakers.speaker_manager='' ";
            
        }else if($section == "speakers_with_no_address"){
            
            $condition = " all_speakers.address1='' ";
            
        }else if($section == "speakers_with_no_bio"){
            
            $condition = " all_speakers.short_bio='' ";
            
        }else if($section == "speakers_with_no_headshots"){
            
            $condition = " all_speakers.head_shot='' ";
            
        }else if($section == "speakers_with_no_mobile"){
            
            $condition = " all_speakers.phone='' ";
            
        }else if($section == "speakers_with_no_speaker_type"){
            $condition = " all_speakers.speaker_type='' ";
            
        }else if(empty($id)){
            
            $condition = " all_status.status_name='".$var."' ";
        
        }else{
            
            $condition = "FIND_IN_SET('".base64_decode($id)."', all_speakers.speaker_type)";
            
        }
         $fetch_all_speakers = mysqli_query($this->connect,"SELECT all_status.status_name,company,phone,speaker_type,profile_completeness,speaker_name,email_id,social_media_total_score,all_status.id as status_id,all_speakers.id as id,0 as log_id,now() as created_at,'AA' as template_name,0 as template_id,mail_sent_count as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE ".$condition." AND all_speakers.status =''  AND all_speakers.event_id = '".$event_id."' ORDER BY all_speakers.id DESC");
        // $fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_status.status_name,all_status.id as status_id,all_speakers.linkedin_url,all_speakers.id as id, (select other_column_value from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as created_at,  (select count(all_logs.id) from all_logs RIGHT JOIN all_email_templates ON all_email_templates.id = all_logs.other_column_value WHERE table_id=all_speakers.id AND operation='sent email to speaker') as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE ".$condition." AND all_speakers.status =''  AND all_speakers.event_id = '".$event_id."' ORDER BY all_speakers.id DESC");
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
            function fetch_all_sponsors_with_conditions($var,$id,$section,$evt_id,$start=1, $limit){

        $event_id= $evt_id;
        
        if($section == "sponsors_with_no_twitter_handles"){
            
            $condition = " all_sponsors.twitter_url='' ";
            
        }else if($section == "sponsors_with_no_linked_handles"){
            
            $condition = " all_sponsors.linkedin_url='' ";
            
        }else if($section == "sponsors_with_no_fb_handles"){
            
            $condition = " all_sponsors.facebook_url='' ";
            
        }else if($section == "sponsors_with_no_instagram_handles"){
            
            $condition = " all_sponsors.instagram_url='' ";
            
        }else if($section == "sponsors_with_no_address"){
            
            $condition = " all_sponsors.address1='' ";
            
        }else if($section == "sponsors_with_no_bio"){
            
            $condition = " all_sponsors.sponsor_bio='' ";
            
        }else if($section == "sponsors_with_no_headshots"){
            
            $condition = " all_sponsors.head_shot='' ";
            
        }else if($section == "sponsors_with_no_mobile"){
            
            $condition = " all_sponsors.sponsor_contact_number='' ";
            
        }else if($section == "sponsors_with_no_secondary1_sponsor"){
            
            $condition = " all_sponsors.secondary1_sponsor_contact_person='' ";
            
        }else if($section == "sponsors_with_no_sponsor_type"){
            $condition = " all_sponsors.sponsor_type='' ";
            
        }else if($section == "sponsors_with_no_company_profile"){
            $condition = " all_sponsors.sponsor_company_name='' ";
            
        }else if($section == "sponsors_with_no_logo"){
            $condition = " (all_sponsors.sponsor_logo='' OR all_sponsors.sponsor_logo is null) ";
            
        }else if($section == "event_dashboard"){           
            $condition = "all_sponsors.event_id != 0 ";
            
        }else if($section == "Sponsors Secured"){           
            $condition = "all_sponsors.`status` in (select id from all_status where status_name like '%Sponsors Secured%') ";
            
        }else if($section == "Sponsors Not Ready"){           
            $condition = "all_sponsors.`status` in (select id from all_status where status_name like '%Sponsors Not Ready%')";
            
        }else if($section == "Sponsors In-pipeline"){           
            $condition = "all_sponsors.`status` in (select id from all_status where status_name like '%Sponsors In-pipeline%')";
            
        }else if(empty($id)){
            
            $condition = " all_status.status_name='".$var."' AND all_sponsors.event_id = '".$event_id."' ";
        
        }else{
            
            $condition = "FIND_IN_SET('".base64_decode($id)."', all_sponsors.sponsor_type) AND all_sponsors.event_id = '".$event_id."'";            
        }

        $fetch_all_sponsors = mysqli_query($this->connect,"SELECT  `status`,all_sponsors.id,sponsor_type,sponsor_company_name,sponsor_contact_person,sponsor_contact_email_address,sponsor_contact_number,'AA' as template_name,mail_sent_count as count_email_sent,now() as created_at FROM all_sponsors LEFT JOIN all_status ON all_sponsors.status = all_status.id WHERE ".$condition." AND all_sponsors.event_id = '".$event_id."' ORDER BY all_sponsors.id DESC LIMIT $start, $limit");

        
        // $fetch_all_sponsors = mysqli_query($this->connect,"SELECT *,all_sponsors.id as id,(SELECT GROUP_CONCAT(d.sponsor_type_name)  FROM all_sponsor_types d WHERE find_in_set(d.id,all_sponsors.sponsor_type)) as sponsor_type_name, (select other_column_value from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as created_at,  (select count(all_logs.id) from all_logs RIGHT JOIN all_email_templates ON all_email_templates.id = all_logs.other_column_value WHERE table_id=all_sponsors.id AND operation='sent email to sponsor') as count_email_sent FROM all_sponsors LEFT JOIN all_status ON all_sponsors.status = all_status.id WHERE ".$condition." AND all_sponsors.event_id = '".$event_id."' ORDER BY all_sponsors.id DESC LIMIT $start, $limit");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsors) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsors)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    
    function fetch_all_speakers_asc($evt_id=null){
        
          $event_id= $evt_id;

          $fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_status.id as status_id,all_speakers.id as id, (select other_column_value from all_logs WHERE table_id=all_speakers.id ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_speakers.id ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE  all_speakers.event_id = '".$event_id."'  ORDER BY all_speakers.speaker_name ASC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    function fetch_all_sponsors_asc($event_id){
          //   $event_id= $_SESSION['current_event_id'];
        //$fetch_all_sponsors = mysqli_query($this->connect,"SELECT *,all_status.id as status_id,all_sponsors.id as id FROM all_sponsors LEFT JOIN all_status ON all_sponsors.status = all_status.id");
          $fetch_all_sponsors = mysqli_query($this->connect,"SELECT *,all_status.id as status_id,all_sponsors.id as id, (select other_column_value from all_logs WHERE table_id=all_sponsors.id ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_sponsors.id ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name FROM all_sponsors LEFT JOIN all_status ON all_sponsors.status = all_status.id where all_sponsors.event_id='".$event_id."' ORDER BY all_sponsors.sponsor_company_name ASC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsors) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsors)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    
   function fetch_all_masters_asc($evt_id){

        $event_id= $evt_id;

        $fetch_all_masters = mysqli_query($this->connect,"SELECT *,all_masters.id as id, (select other_column_value from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as created_at   FROM all_masters WHERE all_masters.event_id = '".$event_id."' ORDER BY all_masters.id DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

     function fetch_all_masters_asc_list($evt_id){

        $event_id= $evt_id;

        $fetch_all_masters = mysqli_query($this->connect,"SELECT id,master_name,master_lastname FROM all_masters WHERE all_masters.event_id = '".$event_id."' ORDER BY all_masters.id DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    
    function fetch_a_speaker($id){

        $fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_status.id as status_id FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.id=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_a_event($id){

        $fetch_all_events = mysqli_query($this->connect,"SELECT * FROM all_events WHERE id='$id' ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_events) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_events)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }



    function fetch_all_email_templates($ev_id=null){

        $event_id = $ev_id;

         $fetch_all_email_templates = mysqli_query($this->connect," SELECT * FROM (select aet.id,aet.template_name,
             aet.template_subject,aet.template_data,aet.template_type,aet.updated_date,aet.is_edited,aet.event_id,
            ifnull((select total_usage from all_email_template_usage_info where template_id=aet.id and event_id='".$event_id."'),0) as count,ifnull((select total_read from all_email_template_usage_info where template_id=aet.id and event_id='".$event_id."'),0) as read_count,(select GROUP_CONCAT(d.status_name) as status_names from all_status d where find_in_set(d.id,aet.status_id)) as status_names from all_email_templates aet left outer join all_email_template_usage_info aui ON aet.id=aui.template_id where (aet.event_id='all' OR aet.event_id='".$event_id."') AND  aet.id not in(select aetu.template_id from all_email_template_usage_info aetu where aetu.event_id='".$event_id."' and aetu.is_delete=1) order by updated_date desc) AS t GROUP BY template_name having count(*)>0");
         
        // $fetch_all_email_templates = mysqli_query($this->connect,"SELECT * FROM (select id,template_name,template_subject,template_data,template_type,updated_date,is_edited,event_id,ifnull((select total_usage from all_email_template_usage_info where template_id=all_email_templates.id and event_id='".$event_id."'),0) as count,ifnull((select total_read from all_email_template_usage_info where template_id=all_email_templates.id and event_id='".$event_id."'),0) as read_count,(select GROUP_CONCAT(d.status_name) as status_names from all_status d where find_in_set(d.id,all_email_templates.status_id)) as status_names from all_email_templates where (event_id='all' OR event_id='".$event_id."') order by updated_date desc) AS t GROUP BY template_name having count(*)>0");

        $inner_array = array();
        
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    function fetch_all_email_templates_asc(){

        //$fetch_all_email_templates = mysqli_query($this->connect,"select *, e.id, e.status_id, e.template_name, e.template_data,e.updated_date,e.id, all_logs.other_column_value, GROUP_CONCAT(d.status_name) as status_names from all_email_templates e LEFT join all_status d on find_in_set(d.id,e.status_id) group by e.id");
        
        $fetch_all_email_templates = mysqli_query($this->connect,"select (SELECT count(*) FROM all_logs WHERE other_column_name='template_id' AND all_logs.other_column_value=e.id GROUP BY other_column_name ) as count, e.id, e.status_id, e.template_name, e.template_data,e.updated_date, GROUP_CONCAT(d.status_name) as status_names from all_email_templates e LEFT join all_status d on find_in_set(d.id,e.status_id) group by e.id   ORDER BY e.template_name ASC");
        $inner_array = array();
        
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
function fetch_all_email_templates_master_asc($evt_id){
        $event_id = $evt_id;

        $fetch_all_email_templates = mysqli_query($this->connect,"SELECT * FROM (select id,template_name,template_subject,template_data,template_type,updated_date,is_edited,(select count(*) from all_logs where other_column_name='template_id' AND other_column_value=all_email_templates.id and all_logs.event_id='".$event_id."') as count,(select count(*) from all_logs where other_column_name='template_id' AND other_column_value=all_email_templates.id and email_read='y' and all_logs.event_id='".$event_id."') as read_count,(select GROUP_CONCAT(d.status_name) as status_names from all_status d where find_in_set(d.id,all_email_templates.status_id)) as status_names from all_email_templates where (event_id='all' OR event_id='".$event_id."') AND all_email_templates.template_type LIKE '%master%' order by updated_date desc) AS t GROUP BY template_name having count(*)>0");
        
        $inner_array = array();
        
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    function fetch_all_email_templates_speaker_asc($evt_id=null){

        $event_id= $evt_id;

        $fetch_all_email_templates = mysqli_query($this->connect,"SELECT * FROM (select id,template_name,template_subject,template_data,template_type,updated_date,is_edited,(select count(*) from all_logs where other_column_name='template_id' AND other_column_value=all_email_templates.id and all_logs.event_id='".$event_id."') as count,(select count(*) from all_logs where other_column_name='template_id' AND other_column_value=all_email_templates.id and email_read='y' and all_logs.event_id='".$event_id."') as read_count,(select GROUP_CONCAT(d.status_name) as status_names from all_status d where find_in_set(d.id,all_email_templates.status_id)) as status_names from all_email_templates where (event_id='all' OR event_id='".$event_id."') AND all_email_templates.template_type LIKE '%speaker%' order by updated_date desc) AS t GROUP BY template_name having count(*)>0");
        $inner_array = array();
        
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    function fetch_all_email_templates_sponsor_asc(){
        
        $event_id= $_SESSION['current_event_id'];
        //$fetch_all_email_templates = mysqli_query($this->connect,"select *, e.id, e.status_id, e.template_name, e.template_data,e.updated_date,e.id, all_logs.other_column_value, GROUP_CONCAT(d.status_name) as status_names from all_email_templates e LEFT join all_status d on find_in_set(d.id,e.status_id) group by e.id");
        
        // $fetch_all_email_templates = mysqli_query($this->connect,"select (SELECT count(*) FROM all_logs WHERE other_column_name='template_id' AND all_logs.other_column_value=e.id GROUP BY other_column_name ) as count, e.id, e.status_id, e.template_name,e.template_type, e.template_data,e.updated_date, GROUP_CONCAT(d.status_name) as status_names from all_email_templates e  LEFT join all_status d on find_in_set(d.id,e.status_id)  WHERE e.template_type LIKE '%sponsor%' group by e.id   ORDER BY e.template_name ASC");
         $fetch_all_email_templates = mysqli_query($this->connect,"SELECT * FROM (select id,template_name,template_subject,template_data,template_type,updated_date,is_edited,(select count(*) from all_logs where other_column_name='template_id' AND other_column_value=all_email_templates.id and all_logs.event_id='".$event_id."') as count,(select count(*) from all_logs where other_column_name='template_id' AND other_column_value=all_email_templates.id and email_read='y' and all_logs.event_id='".$event_id."') as read_count,(select GROUP_CONCAT(d.status_name) as status_names from all_status d where find_in_set(d.id,all_email_templates.status_id)) as status_names from all_email_templates where (event_id='all' OR event_id='".$event_id."') AND all_email_templates.template_type LIKE '%sponsor%' order by updated_date desc) AS t GROUP BY template_name having count(*)>0");
        $inner_array = array();
        
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    function fetch_email_template($id){

        $fetch_all_email_templates = mysqli_query($this->connect,"SELECT * FROM all_email_templates WHERE id=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    function fetch_all_mail_logs($speaker_id,$limit = null){
        
        $limit_sql = "";
        
        // if($limit==5){
        if($limit > 0 && $limit != null){
            $limit_sql = " LIMIT ".$limit;
        }
        
        $fetch_all_email_templates = mysqli_query($this->connect,"SELECT *,all_logs.id as idd FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE all_logs.operation='sent email to speaker' AND all_logs.table_id='".$speaker_id."' AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC ".$limit_sql);
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    function fetch_all_sponsor_mail_logs($sponsor_id,$limit = null){
        
        $limit_sql = "";
        
        if($limit==5){
            $limit_sql = " LIMIT ".$limit;
        }
        
        $fetch_all_email_templates = mysqli_query($this->connect,"SELECT *,all_logs.id as idd FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE all_logs.operation='sent email to sponsor' AND all_logs.table_id='".$sponsor_id."' AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC ".$limit_sql);
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    function fetch_all_master_mail_logs($master_id,$limit = null){
        
        $limit_sql = "";
        
        if($limit==5){
            $limit_sql = " LIMIT ".$limit;
        }
        
        $fetch_all_email_templates = mysqli_query($this->connect,"SELECT *,all_logs.id as idd FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE all_logs.operation='sent email to master' AND all_logs.table_id='".$master_id."' AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC ".$limit_sql);
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    
   function fetch_all_sponsor_types($event_id=NULL){
     $fetch_all_sponsor_types = mysqli_query($this->connect,"
            SELECT *,total_enrolled as count_of_sponsor_usage,
            ifnull((SELECT sum(sponsorship_values) FROM sponsor_sponsorship_type left outer join all_sponsors on sponsor_sponsorship_type.sponsor_id=all_sponsors.id WHERE find_in_set(all_sponsor_types.id,sponsor_sponsorship_type.sponsor_type) and all_sponsors.event_id='".$event_id."'),0) as potential_funding_ask,
            ifnull((SELECT sum(committed_unit) FROM sponsor_sponsorship_type left outer join all_sponsors on sponsor_sponsorship_type.sponsor_id=all_sponsors.id WHERE find_in_set(all_sponsor_types.id,sponsor_sponsorship_type.sponsor_type) and all_sponsors.event_id='".$event_id."'),0) as committed_funding FROM all_sponsor_types WHERE all_sponsor_types.event_id = '".$event_id."'");
         //$event_id= $_SESSION['current_event_id'];
        // $fetch_all_sponsor_types = mysqli_query($this->connect,"SELECT *,(SELECT count(*) FROM all_sponsors WHERE find_in_set(all_sponsor_types.id,all_sponsors.sponsor_type) and all_sponsors.event_id='".$event_id."') as count_of_sponsor_usage,ifnull((SELECT sum(sponsorship_values) FROM sponsor_sponsorship_type left outer join all_sponsors on sponsor_sponsorship_type.sponsor_id=all_sponsors.id WHERE find_in_set(all_sponsor_types.id,sponsor_sponsorship_type.sponsor_type) and all_sponsors.event_id='".$event_id."'),0) as potential_funding_ask,
        //     ifnull((SELECT sum(committed_unit) FROM sponsor_sponsorship_type left outer join all_sponsors on sponsor_sponsorship_type.sponsor_id=all_sponsors.id WHERE find_in_set(all_sponsor_types.id,sponsor_sponsorship_type.sponsor_type) and all_sponsors.event_id='".$event_id."'),0) as committed_funding FROM all_sponsor_types WHERE default_flag = 1 AND all_sponsor_types.event_id = '".$event_id."'
        //     union 
        //     SELECT *,(SELECT count(*) FROM all_sponsors WHERE find_in_set(all_sponsor_types.id,all_sponsors.sponsor_type) and all_sponsors.event_id='".$event_id."') as count_of_sponsor_usage,
        //     ifnull((SELECT sum(sponsorship_values) FROM sponsor_sponsorship_type left outer join all_sponsors on sponsor_sponsorship_type.sponsor_id=all_sponsors.id WHERE find_in_set(all_sponsor_types.id,sponsor_sponsorship_type.sponsor_type) and all_sponsors.event_id='".$event_id."'),0) as potential_funding_ask,
        //     ifnull((SELECT sum(committed_unit) FROM sponsor_sponsorship_type left outer join all_sponsors on sponsor_sponsorship_type.sponsor_id=all_sponsors.id WHERE find_in_set(all_sponsor_types.id,sponsor_sponsorship_type.sponsor_type) and all_sponsors.event_id='".$event_id."'),0) as committed_funding FROM all_sponsor_types WHERE all_sponsor_types.event_id = '".$event_id."'");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsor_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsor_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    function fetch_all_sponsor_types_asc($event_id=null){
       //  $event_id= $_SESSION['current_event_id'];
        $fetch_all_sponsor_types = mysqli_query($this->connect,"SELECT * FROM all_sponsor_types where event_id='".$event_id."'");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsor_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsor_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    function fetch_a_sponsor_type($id){

        $fetch_all_sponsor_types = mysqli_query($this->connect,"SELECT * FROM all_sponsor_types WHERE id=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsor_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsor_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
      function fetch_all_speaker_types($evt_id=null){

        $event_id= $evt_id;
        $fetch_all_speaker_types = mysqli_query($this->connect,"SELECT * FROM all_speaker_types where event_id='".$event_id."' ORDER BY id DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

     function fetch_all_speaker_types_asc($evt_id=null){

        $event_id= $evt_id;
        $fetch_all_speaker_types = mysqli_query($this->connect,"SELECT * FROM all_speaker_types where event_id='".$event_id."' ORDER BY speaker_type_name ASC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
   function fetch_all_master_types($evt_id){

        $event_id= $evt_id;
        $fetch_all_master_types = mysqli_query($this->connect,"SELECT *,total_masters_enrolled as count_of_master_usage FROM all_master_types WHERE event_id = '".$event_id."'");
        // $fetch_all_master_types = mysqli_query($this->connect,"SELECT *,(SELECT count(*) FROM all_masters WHERE find_in_set(all_master_types.id,all_masters.master_type) and
        //     all_masters.event_id='".$event_id."') as count_of_master_usage FROM all_master_types WHERE is_default = 1  union SELECT *,(SELECT count(*) FROM all_masters WHERE find_in_set(all_master_types.id,all_masters.master_type) and
        //     all_masters.event_id='".$event_id."') as count_of_master_usage FROM all_master_types WHERE event_id = '".$event_id."'");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_master_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_master_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        } 

    }
    
    function fetch_all_master_types_asc($evt_id){
         $event_id= $evt_id;

        $fetch_all_master_types = mysqli_query($this->connect,"SELECT * FROM all_master_types where event_id = '".$event_id."' ORDER BY master_type_name ASC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_master_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_master_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

   function fetch_all_master_types_by_eventid($evt_id=null){
          $event_id= $evt_id;

        $fetch_all_master_types = mysqli_query($this->connect,"SELECT * FROM all_master_types WHERE event_id = '".$event_id."'");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_master_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_master_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_all_master_types_for_event_signup($eid){

        //$event_id= $_SESSION['current_event_id'];

       // $fetch_all_master_types = mysqli_query($this->connect,"SELECT *,(SELECT count(*) FROM all_masters WHERE find_in_set(all_master_types.id,all_masters.master_type) and            all_masters.event_id='".$event_id."') as count_of_master_usage FROM all_master_types WHERE is_default = 1  union SELECT *,(SELECT count(*) FROM all_masters WHERE find_in_set(all_master_types.id,all_masters.master_type) and  all_masters.event_id='".$eid."') as count_of_master_usage FROM all_master_types WHERE is_public =1 AND  event_id = '".$eid."'");

        $fetch_all_master_types = mysqli_query($this->connect,"SELECT * FROM all_master_types WHERE event_id = '".$eid."'");
        $inner_array = array(); 
        if(mysqli_num_rows($fetch_all_master_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_master_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_master_sent_email_count_by_master_type($tid){
        $event_id= $_SESSION['current_event_id'];

         $fetch_count = mysqli_query($this->connect,"SELECT count(all_logs.id) as idd FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value 
 LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE all_logs.operation='sent email to master' AND 
 all_logs.table_id in (SELECT id FROM all_masters WHERE FIND_IN_SET('".$tid."', master_type)) AND  all_logs.event_id = '".$event_id."' ;");
        return $count = mysqli_num_rows($fetch_count);
    }


    function fetch_all_action_types($evt_id){
         $event_id= $evt_id;
        $fetch_all_action_types = mysqli_query($this->connect,"SELECT act.* , 
         (SELECT COUNT(*) from action_trackers where act.id = action_trackers.action_category AND action_trackers.status = 'In-Progress' AND action_trackers.event_id = '".$event_id."' ) as action_count_inprogress, 
         (SELECT COUNT(*) from action_trackers where act.id = action_trackers.action_category AND action_trackers.status = 'Delegated' AND action_trackers.event_id = '".$event_id."' ) as action_count_delegated,
         (SELECT COUNT(*) from action_trackers where act.id = action_trackers.action_category AND action_trackers.status = 'Completed' AND action_trackers.event_id = '".$event_id."' ) as action_count_completed,
        (SELECT COUNT(*) from action_trackers where act.id = action_trackers.action_category AND action_trackers.status = 'New' AND action_trackers.event_id = '".$event_id."' ) as action_count_new
        FROM all_action_types act WHERE act.event_id = '".$event_id."' ORDER BY act.id DESC");
        //,(SELECT COUNT(*) from resource_trackers where ) as resource_used
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_action_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_action_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        } 
    }

    function fetch_all_resource_types($event_id=null){

         // $event_id= $_SESSION['current_event_id'];

        $fetch_all_resource_types = mysqli_query($this->connect,"SELECT art.*, (SELECT COUNT(*) from resource_trackers where art.id = resource_trackers.resource_category AND resource_trackers.event_id = '".$event_id."' ) as resource_used FROM all_resource_types art WHERE art.event_id = '".$event_id."' ORDER BY art.id DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }


      function fetch_all_action($evt_id){

        $event_id= $evt_id;

        $fetch_all_action = mysqli_query($this->connect,"SELECT at.*,auf.file_name as action_attachments FROM action_trackers at LEFT JOIN all_uploaded_files auf ON at.id= auf.action_id WHERE at.event_id = '".$event_id."' ORDER BY id DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_action) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_action)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

   function fetch_all_action_with_condition($status,$category,$evt_id){

        $event_id= $evt_id;
        $category_id =base64_decode($category);
        $fetch_all_action = mysqli_query($this->connect,"SELECT at.*,auf.file_name as action_attachments FROM action_trackers at LEFT JOIN all_uploaded_files auf ON at.id= auf.action_id WHERE at.event_id = '".$event_id."' AND at.action_category='".$category_id."' AND at.status='".$status."' ORDER BY id DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_action) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_action)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }


    function fetch_all_resource($evt_id){
        $event_id = $evt_id;       
          $fetch_all_resource = mysqli_query($this->connect," SELECT rt.*,art.resource_type_name,auf.file_name as resource_attachments from resource_trackers rt left join all_resource_types art ON rt.resource_category= art.id left join all_uploaded_files auf ON rt.id = auf.resource_id where rt.event_id = '".$event_id."' ORDER BY rt.id desc ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }


   function fetch_all_resource_with_condition($category,$evt_id){
        $event_id = $evt_id; 
        $category_id =base64_decode($category);

          $fetch_all_resource = mysqli_query($this->connect,"SELECT rt.*,art.resource_type_name,auf.file_name as resource_attachments from resource_trackers rt left join all_resource_types art ON rt.resource_category= art.id left join all_uploaded_files auf ON rt.id = auf.resource_id where rt.event_id = '".$event_id."' AND rt.resource_category = '".$category_id."' ORDER BY rt.id desc ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }




   function fetch_all_resource_with_attachments($evt_id){

        $event_id= $evt_id;
         $fetch_all_resource = mysqli_query($this->connect," SELECT rt.*,art.resource_type_name,auf.file_name as resource_attachments,date_format(rt.created_at,'%d-%b-%Y') as created_at from resource_trackers rt left join all_resource_types art ON rt.resource_category= art.id left join all_uploaded_files auf ON rt.id = auf.resource_id where rt.event_id = '".$event_id."' AND (rt.is_file_available != 0 OR rt.url != '') ORDER BY rt.id desc ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }


    function fetch_a_resource_by_id($id){

        $fetch_all_resource = mysqli_query($this->connect,"SELECT * FROM resource_trackers WHERE `id` = '$id' ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    
    function fetch_a_master_type($id){

        $fetch_all_master_types = mysqli_query($this->connect,"SELECT * FROM all_master_types WHERE id=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_master_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_master_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

   


    function fetch_a_action_type($id){

        $fetch_action_type = mysqli_query($this->connect,"SELECT * FROM all_action_types WHERE id=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_action_type) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_action_type)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_a_action_by_id($id){

        $fetch_all_action = mysqli_query($this->connect,"SELECT * FROM action_trackers WHERE `id` = '$id' ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_action) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_action)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_action_files_by_id($id){

         $fetch_all_action = mysqli_query($this->connect,"SELECT * FROM all_uploaded_files WHERE `action_id` = '$id' ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_action) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_action)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        } 
        else{
            return $inner_array;
        }
    }

    function fetch_resource_files_by_id($id){

         $fetch_all_action = mysqli_query($this->connect,"SELECT * FROM all_uploaded_files WHERE `resource_id` = '$id' ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_action) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_action)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        } 
        else{
            return $inner_array;
        }
    }



    function fetch_a_resource_type($id){

        $fetch_resource_type = mysqli_query($this->connect,"SELECT * FROM all_resource_types WHERE id=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_resource_type) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_resource_type)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    
    function fetch_a_master($id){

        $fetch_all_master_types = mysqli_query($this->connect,"SELECT * FROM all_masters WHERE id=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_master_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_master_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    function fetch_a_speaker_type($id){

        $fetch_all_speaker_types = mysqli_query($this->connect,"SELECT * FROM all_speaker_types WHERE id=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }        
    }
    
 function fetch_all_sponsors($start=1,$limit=null,$event_id=null){

          $fetch_all_sponsors = mysqli_query($this->connect,"SELECT  `status`,all_sponsors.id,sponsor_type,sponsor_company_name,sponsor_contact_person,sponsor_contact_email_address,sponsor_contact_number,'AA' as template_name,mail_sent_count as count_email_sent,now() as created_at FROM all_sponsors WHERE all_sponsors.event_id = '".$event_id."' ORDER BY all_sponsors.id DESC LIMIT $start, $limit");

          // $fetch_all_sponsors = mysqli_query($this->connect,"SELECT *,all_sponsors.id as id,(SELECT GROUP_CONCAT(d.sponsor_type_name)  FROM all_sponsor_types d WHERE find_in_set(d.id,all_sponsors.sponsor_type)) as sponsor_type_name, (select other_column_value from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as created_at, (select count(all_logs.id) from all_logs WHERE table_id=all_sponsors.id AND (operation='sent email to sponsor' or operation='sent email to sponsor scheduled' or operation='request missing information sponsor' or operation='request missing documents sponsor' OR operation='request missing information sponsor scheduled' or operation='request missing documents sponsor scheduled') and all_logs.event_id='".$event_id."') as count_email_sent  FROM all_sponsors WHERE all_sponsors.event_id = '".$event_id."' ORDER BY all_sponsors.id DESC LIMIT $start, $limit");
          
         
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsors) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsors)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    function fetch_a_sponsor($id){

        //$fetch_all_sponsors = mysqli_query($this->connect,"SELECT *,all_status.id as status_id,all_sponsors.id as id FROM all_sponsors LEFT JOIN all_status ON all_sponsors.status = all_status.id");
        $fetch_all_sponsors = mysqli_query($this->connect,"SELECT * FROM  all_sponsors WHERE id=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsors) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsors)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
    /*********** Dashboard Functions **********/
   function get_count_total_speakers($event_id){
        //if(!isset($_SESSION)){ session_start(); }
        // $count_total_speakers = mysqli_num_rows(mysqli_query($this->connect,"select * from all_speakers WHERE event_id= '".$event_id."' "));
        $count_sql = mysqli_query($this->connect,"select total_speakers from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_speakers'];
        return $total_speaker;
    }
    function get_count_total_speakers_new($event_id){
        // $count_total_speakers = mysqli_num_rows(mysqli_query($this->connect,"select * from all_speakers WHERE status='' AND event_id= '".$event_id."' "));
        $count_sql = mysqli_query($this->connect,"select total_new_speakers from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_new_speakers'];
        return $total_speaker;
    }
    
    function get_count_total_speakers_approved($event_id){
        // $count_total_speakers_approved = mysqli_num_rows(mysqli_query($this->connect,"select *,all_status.status_name from all_speakers LEFT JOIN all_status ON all_status.id=all_speakers.status WHERE all_status.status_name='Approved' AND all_speakers.event_id= '".$event_id."' "));
       $count_sql = mysqli_query($this->connect,"select total_approved from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_approved'];
        return $total_speaker;
    }
        
    function get_count_total_speakers_declained($event_id){
        // $count_total_speakers_declained = mysqli_num_rows(mysqli_query($this->connect,"select *,all_status.status_name from all_speakers LEFT JOIN all_status ON all_status.id=all_speakers.status WHERE all_status.status_name='Rejected' AND all_speakers.event_id= '".$event_id."' "));
      $count_sql = mysqli_query($this->connect,"select total_declined from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_declined'];
        return $total_speaker;
    }
    
    function get_count_total_speakers_inpipeline($event_id){
        // $count_total_speakers_inpipeline = mysqli_num_rows(mysqli_query($this->connect,"select *,all_status.status_name from all_speakers LEFT JOIN all_status ON all_status.id=all_speakers.status WHERE all_status.status_name='In Contract' AND all_speakers.event_id= '".$event_id."'  "));
        $count_sql = mysqli_query($this->connect,"select total_incontract from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_incontract'];
        return $total_speaker;
    }

      function get_count_total_events(){
        if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $fetch_sql = mysqli_query($this->connect,"SELECT * from all_users where user_id='".$user_id."' ");   
         $res_sql = mysqli_fetch_array($fetch_sql);
         $session_tanent_id= $res_sql['tanent_id'];
        // $count_total_events = mysqli_num_rows(mysqli_query($this->connect,"select al.* from all_events al,all_users au where FIND_IN_SET(al.id, au.event_id) and au.user_id='".$user_id."'"));

          $count_total_events = mysqli_num_rows(mysqli_query($this->connect,"select * from all_events WHERE tanent_id='".$session_tanent_id."'"));
        if(empty($count_total_events)) $count_total_events = 0; 
        return $count_total_events;
    }

    
    function get_speaking_oppertunity_types($event_id){
        $fetch_sql = mysqli_query($this->connect,"SELECT c.speaker_type_name,c.id,c.count_of_speaker_usage as count,c.total_email_count  FROM all_speaker_types c WHERE event_id='".$event_id."' GROUP BY c.id");
        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
        
    }
    
    function get_top5_email_templates($event_id){

        $fetch_sql = mysqli_query($this->connect,"SELECT c.template_name,c.id,(select count(*) from all_logs where c.id = other_column_value AND  operation = 'sent email to speaker' AND event_id = '$event_id') as count  FROM all_email_templates c WHERE template_type LIKE '%speaker%'    GROUP BY c.id ORDER BY count DESC LIMIT 5");
        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
        
    }
    
    function get_top5_email_templates_sponsor($event_id){
        $fetch_sql = mysqli_query($this->connect,"SELECT c.template_name,c.id,(select count(*) from all_logs where c.id = other_column_value AND  operation='sent email to sponsor' AND event_id = '$event_id') as count  FROM all_email_templates c WHERE template_type LIKE '%sponsor%'  GROUP BY c.id ORDER BY count DESC LIMIT 5");
        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }        
    }

    function get_last5_used_email_templates_sponsor($event_id){

        $fetch_sql = mysqli_query($this->connect,"select template_name,template_id as id,
         total_email_sent as Emailcount,total_email_opened as email_opened_data,created_at FROM recent_communication_sponsor  WHERE event_id='".$event_id."'  order by created_at desc LIMIT 5");

         // $fetch_sql = mysqli_query($this->connect,"SELECT  template_name,id,Emailcount,email_opened_data,created_at from (
         //    SELECT  template_name,id,Emailcount,email_opened_data,created_at from (SELECT distinct aet.template_name,aet.id,(select count(*) from all_logs als where als.operation='sent email to sponsor' and als.event_id='".$event_id."' and als.other_column_value=aet.id and als.other_column_name='template_id') as Emailcount,(select count(*) 
         //    from all_logs als where als.operation='sent email to sponsor' and als.event_id='".$event_id."' and als.other_column_value=aet.id and email_read='y' and als.other_column_name='template_id') as email_opened_data,al.created_at FROM all_email_templates aet, all_logs al WHERE aet.id = al.other_column_value AND aet.template_type LIKE '%sponsor%' AND al.operation='sent email to sponsor' AND al.event_id= '".$event_id."' order by al.created_at desc) t1
         //    union 
         //    SELECT  template_name,id,Emailcount,email_opened_data,created_at from (SELECT  distinct 'Request missing information' as  template_name,'9998' as id,(select count(*) from all_logs als where als.operation='Request missing information sponsor'and als.event_id='".$event_id."') as Emailcount,(select count(*) from all_logs als where als.operation='Request missing information sponsor' and als.event_id='".$event_id."'  and email_read='y') as email_opened_data,al.created_at FROM  all_logs al WHERE al.operation='Request missing information sponsor' AND al.event_id= '".$event_id."' order by al.created_at desc) t2
         //    union
         //    SELECT  template_name,id,Emailcount,email_opened_data,created_at from (SELECT  distinct 'Request missing documents' as  template_name,'9999' as id,(select count(*) from all_logs als where als.operation='Request missing documents sponsor' and als.event_id='".$event_id."') as Emailcount,(select count(*) from all_logs als where als.operation='Request missing documents sponsor' and als.event_id='".$event_id."'  and email_read='y') as email_opened_data,al.created_at
         //    FROM  all_logs al WHERE al.operation='Request missing documents sponsor' AND al.event_id= '".$event_id."' order by al.created_at desc) t3) temp group by temp.template_name  order by temp.created_at desc  LIMIT 5");
        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }        
    }

     function get_last5_used_email_templates_speaker($event_id){

        $fetch_sql = mysqli_query($this->connect,"select template_name,template_id as id,
         total_email_sent as Emailcount,total_email_opened as email_opened_data,created_at FROM recent_communication_speaker  WHERE event_id='".$event_id."'  order by created_at desc LIMIT 5");

        // $fetch_sql = mysqli_query($this->connect,"SELECT  template_name,id,Emailcount,email_opened_data,created_at from (
        //     SELECT  template_name,id,Emailcount,email_opened_data,created_at from (SELECT distinct aet.template_name,aet.id,(select count(*) from all_logs als where (als.operation='sent email to speaker' OR als.operation='sent email to speaker Event Presentation') and als.event_id='".$event_id."' and als.other_column_value=aet.id and als.other_column_name='template_id') as Emailcount,(select count(*) 
        //     from all_logs als where (als.operation='sent email to speaker' OR als.operation='sent email to speaker Event Presentation') and als.event_id='".$event_id."' and als.other_column_value=aet.id and email_read='y' and als.other_column_name='template_id') as email_opened_data,al.created_at FROM all_email_templates aet, all_logs al WHERE aet.id = al.other_column_value 
        //     AND aet.template_type LIKE '%speaker%' AND (al.operation='sent email to speaker' OR al.operation='sent email to speaker Event Presentation') AND al.event_id= '".$event_id."' order by al.created_at desc) t1
        //     union 
        //     SELECT  template_name,id,Emailcount,email_opened_data,created_at from (SELECT  distinct 'Request missing information' as  template_name,'9998' as id,(select count(*) from all_logs als where als.operation='request missing information'
        //     and als.event_id='".$event_id."') as Emailcount,(select count(*) 
        //     from all_logs als where als.operation='request missing information' and als.event_id='".$event_id."'  and email_read='y') as email_opened_data,al.created_at FROM  all_logs al WHERE al.operation='request missing information' AND al.event_id= '".$event_id."' order by al.created_at desc) t2
        //     union
        //     SELECT  template_name,id,Emailcount,email_opened_data,created_at from (SELECT  distinct 'Request missing documents' as  template_name,'9999' as id,(select count(*) from all_logs als where als.operation='request missing documents'
        //     and als.event_id='".$event_id."') as Emailcount,(select count(*) 
        //     from all_logs als where als.operation='request missing documents' and als.event_id='".$event_id."'  and email_read='y') as email_opened_data,al.created_at FROM  all_logs al WHERE al.operation='request missing documents' AND al.event_id= '".$event_id."' order by al.created_at desc) t3
        //     ) temp group by temp.template_name  order by temp.created_at desc  LIMIT 5");

        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }        
    
    }

    //    function get_last5_used_email_templates_speaker($event_id){

    //     $fetch_sql = mysqli_query($this->connect,"SELECT distinct aet.template_name,aet.id,(select count(*) from all_logs als where als.operation='sent email to speaker' and als.event_id='".$event_id."' and als.other_column_value=aet.id and als.other_column_name='template_id') as Emailcount,(select count(*) from all_logs als where als.operation='sent email to speaker' and als.event_id='".$event_id."' and als.other_column_value=aet.id and email_read='y' and als.other_column_name='template_id') as email_opened_data FROM all_email_templates aet, all_logs al WHERE aet.id = al.other_column_value AND aet.template_type LIKE '%speaker%' AND al.operation='sent email to speaker' AND al.event_id= '".$event_id."' ORDER BY al.created_at DESC LIMIT 5");

    //     $inner_array = array();
    //     if(mysqli_num_rows($fetch_sql) > 0)
    //     {            
    //         while($row = mysqli_fetch_array($fetch_sql)){
    //             $inner_array[] = $row;
    //         }
    //         return $inner_array;            
    //     }
    //     else{
    //         return $inner_array;
    //     }        
    
    // }

/*    function get_last5_speaker_communication_email($event_id){

        $fetch_sql = mysqli_query($this->connect,"SELECT al.other_column_value as templ_id, al.id as logid, (select count(*) from all_logs als where als.operation='sent email to speaker' and 
als.event_id='".$event_id."' and als.other_column_value=templ_id) as Emailcount,
(select count(*) from all_logs algs where
 (algs.operation='sent email to speaker' OR algs.operation='request missing information' OR algs.operation='request missing documents')  and
 algs.event_id='".$event_id."' and algs.email_read='y' and algs.id = logid) as email_opened_data, 
 (case when (al.other_column_value = 0) THEN  al.operation ELSE  (select template_name from all_email_templates where id = al.other_column_value )  END) as template_name 
  from all_logs al where al.event_id = '".$event_id."' and 
( al.operation='sent email to speaker' OR al.operation = 'request missing information' OR al.operation = 'request missing documents')  group by al.operation order by al.created_at desc LIMIT 5;");  

        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }        
    
    }
    */
    function get_total_email_sent($speaker_or_sponsor){
        $fetch_sql = mysqli_query($this->connect,"select count(*) from all_logs where operation='sent email to ".$speaker_or_sponsor."' ");
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            
            return mysqli_num_rows($fetch_sql);           
        }
        else{
            return 0;
        }
        
    }
    
    function get_count_speakers_with_no_twitter_handles($event_id){
        // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE linkedin_handle='' AND event_id = '".$event_id."' "));
       $count_sql = mysqli_query($this->connect,"select total_no_twitter from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_no_twitter'];
        return $total_speaker;
    }
    
    function get_count_speakers_with_no_linked_handles($event_id){
        // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE linkedin_url='' AND event_id = '".$event_id."' "));
        $count_sql = mysqli_query($this->connect,"select total_no_linkedin from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_no_linkedin'];
        return $total_speaker;
    }
    
    
    function get_count_speakers_with_no_manager($event_id){
        // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE speaker_manager='' AND event_id = '".$event_id."' "));
        $count_sql = mysqli_query($this->connect,"select total_no_manager from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_no_manager'];
        return $total_speaker;
    }
    
    function get_count_speakers_with_no_address($event_id){
        // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE address1='' AND event_id = '".$event_id."' "));
        $count_sql = mysqli_query($this->connect,"select total_no_address from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_no_address'];
        return $total_speaker;
    }
    
    function get_count_speakers_with_no_bio($event_id){
        // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE short_bio='' AND event_id = '".$event_id."' "));
        $count_sql = mysqli_query($this->connect,"select total_no_bio from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_no_bio'];
        return $total_speaker;
    }
    
    function get_count_speakers_with_no_headshots($event_id){
        // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE (head_shot='' OR head_shot='null' OR head_shot is null) AND event_id = '".$event_id."' "));
        $count_sql = mysqli_query($this->connect,"select total_no_headshot from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_no_headshot'];
        return $total_speaker;
    }
    
    function get_count_speakers_with_no_mobile($event_id){
        // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE phone='' AND event_id = '".$event_id."' "));
         $count_sql = mysqli_query($this->connect,"select total_no_phone from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_no_phone'];
        return $total_speaker;
    }
    
    function get_count_speakers_with_no_speaker_type($event_id){
        // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE speaker_type='' AND event_id = '".$event_id."' "));
         $count_sql = mysqli_query($this->connect,"select total_no_type from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_no_type'];
        return $total_speaker;
    }
    
    /*********** Dashboard Functions For sponsors **********/
    function get_count_total_sponsors($event_id){
        $count_total_sponsors = mysqli_num_rows(mysqli_query($this->connect,"select * from all_sponsors WHERE event_id != 0 AND event_id = '".$event_id."'  "));
        if(empty($count_total_sponsors)) $count_total_sponsors = 0; 
        return $count_total_sponsors;
    }
    
    
    
    function get_sponsor_oppertunity_types($event_id){
        $fetch_sql = mysqli_query($this->connect,"
            SELECT c.sponsor_type_name,c.id,total_enrolled as count,c.total_email_count  FROM all_sponsor_types c WHERE event_id='".$event_id."' GROUP BY c.id ORDER BY count DESC");
        // $fetch_sql = mysqli_query($this->connect,"
        //     SELECT c.sponsor_type_name,c.id,(select count(*) from all_sponsors where FIND_IN_SET(c.id, sponsor_type) AND event_id = '".$event_id."') as count  FROM all_sponsor_types c WHERE event_id='".$event_id."' GROUP BY c.id ORDER BY count DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
        
    }
    
    
    
    function get_total_email_sent_sponsor($sponsor_or_sponsor){
        $fetch_sql = mysqli_query($this->connect,"select count(*) from all_logs where operation='sent email to ".$sponsor_or_sponsor."'");
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            
            return mysqli_num_rows($fetch_sql);           
        }
        else{
            return 0;
        }
        
    }
    
    function get_count_sponsors_with_no_twitter_handles($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE twitter_url='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    function get_count_sponsors_with_no_linked_handles($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE linkedin_url='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    function get_count_sponsors_with_no_fb_handles($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE facebook_url='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    function get_count_sponsors_with_no_instagram_handles($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE instagram_url='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    
    function get_count_sponsors_with_no_manager($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE sponsor_manager='' AND event_id = '".$event_id."' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    function get_count_sponsors_with_no_address($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE address1='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    function get_count_sponsors_with_no_bio($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE sponsor_bio='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    function get_count_sponsors_with_no_headshots($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE head_shot='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    function get_count_sponsors_with_no_mobile($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE sponsor_contact_number='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    function get_count_sponsors_with_no_secondary1_sponsor($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE secondary1_sponsor_contact_person='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    function get_count_sponsors_with_no_secondary2_sponsor($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE secondary2_sponsor_contact_person='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    function get_count_sponsors_with_no_sponsor_type($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE sponsor_type='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }
    
    function get_count_total_sponsors_secured($event_id){

        $count_total_speakers_approved = mysqli_num_rows(mysqli_query($this->connect,"select *,all_status.status_name from all_sponsors LEFT JOIN all_status ON all_status.id=all_sponsors.status WHERE all_status.status_name='Sponsors Secured' AND all_sponsors.event_id = '".$event_id."'  "));
        if(empty($count_total_speakers_approved)) $count_total_speakers_approved = 0; 
        return $count_total_speakers_approved;
    }
    
    function get_count_total_sponsors_not_ready($event_id){
        $count_total_speakers_approved = mysqli_num_rows(mysqli_query($this->connect,"select *,all_status.status_name from all_sponsors LEFT JOIN all_status ON all_status.id=all_sponsors.status WHERE all_status.status_name='Sponsors Not Ready' AND all_sponsors.event_id = '".$event_id."' "));
        if(empty($count_total_speakers_approved)) $count_total_speakers_approved = 0; 
        return $count_total_speakers_approved;
    }
    
    function get_count_total_sponsors_inpipeline($event_id){
        $count_total_speakers_approved = mysqli_num_rows(mysqli_query($this->connect,"select *,all_status.status_name from all_sponsors LEFT JOIN all_status ON all_status.id=all_sponsors.status WHERE all_status.status_name='Sponsors In-pipeline' AND all_sponsors.event_id = '".$event_id."'  "));
        if(empty($count_total_speakers_approved)) $count_total_speakers_approved = 0; 
        return $count_total_speakers_approved;
    }
    
    function fetch_sponsor_status_by_id($statusid){
        $fetch_sql = mysqli_query($this->connect,"SELECT  status_name from all_status where id = '$statusid'");
        $status = '-';
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            $row = mysqli_fetch_array($fetch_sql);
               
            $status = $row['status_name'];
            return $status;            
        }
        else{
            return $status;            
        }
    }

      function get_all_live_events($startrow){
         if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $condition = '';
         if($_SESSION['role'] == 'admin'){
            //$condition = '';
            $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
         }else{
            $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
         }

        $fetch_live_events = mysqli_query($this->connect,"SELECT * FROM all_events WHERE event_end_date >= CURDATE() ".$condition." ORDER BY id desc LIMIT $startrow, 10");
        

        $inner_array = array();
        if(mysqli_num_rows($fetch_live_events) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_live_events)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function get_all_live_events_count(){
        require("include/mysqli_connect.php");
         if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $condition = '';
         if($_SESSION['role'] == 'admin'){
            //$condition = '';
            $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
         }else{
            $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
         }

        $fetch_live_events = mysqli_query($connect,"SELECT count(*) as totalcount FROM all_events WHERE event_end_date >= CURDATE() ".$condition." ORDER BY id desc");
        

        $inner_array = array();
        if(mysqli_num_rows($fetch_live_events) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_live_events)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function get_all_past_events($startrow){
        if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];

         $condition = '';
         if($_SESSION['role'] == 'admin'){
            $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
         }else{
            $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
         }
        
        $fetch_past_events = mysqli_query($this->connect,"SELECT * FROM all_events WHERE event_end_date < CURDATE() ".$condition." ORDER BY id desc LIMIT $startrow, 10");
        $inner_array = array();
        if(mysqli_num_rows($fetch_past_events) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_past_events)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function get_all_past_events_count(){
        require("include/mysqli_connect.php");
        if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];

         $condition = '';
         if($_SESSION['role'] == 'admin'){
            $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
         }else{
            $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
         }
        
        $fetch_past_events = mysqli_query($connect,"SELECT count(*) as totalcount FROM all_events WHERE event_end_date < CURDATE() ".$condition." ORDER BY id desc");
        $inner_array = array();
        if(mysqli_num_rows($fetch_past_events) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_past_events)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

     function get_all_live_events_search($Name,$startrow){
             if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id'];
             $condition = '';
             if($_SESSION['role'] == 'admin'){
                $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
             }else{
                $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
             }
             
            $fetch_live_events = mysqli_query($this->connect,"SELECT * FROM all_events WHERE event_end_date >= CURDATE() ".$condition." and event_name LIKE '%$Name%' ORDER BY id desc  LIMIT $startrow, 10");
            

            $inner_array = array();
            if(mysqli_num_rows($fetch_live_events) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_live_events)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }
        }

         function get_all_live_events_search_count($Name){
             if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id'];
             $condition = '';
             if($_SESSION['role'] == 'admin'){
                $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
             }else{
                $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
             }
             
            $fetch_live_events = mysqli_query($this->connect,"SELECT count(*) as totalcount FROM all_events WHERE event_end_date >= CURDATE() ".$condition." and event_name LIKE '%$Name%' ORDER BY id desc");
            

            $inner_array = array();
            if(mysqli_num_rows($fetch_live_events) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_live_events)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }
        }


        function get_all_past_events_search($Name,$startrow){
             if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id'];
             $condition = '';
             if($_SESSION['role'] == 'admin'){
                $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
             }else{
                $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
             }
             
            $fetch_live_events = mysqli_query($this->connect,"SELECT * FROM all_events WHERE event_end_date < CURDATE() ".$condition." and event_name LIKE '%$Name%' ORDER BY id desc  LIMIT $startrow, 10");
            

            $inner_array = array();
            if(mysqli_num_rows($fetch_live_events) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_live_events)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }
        }

         function get_all_past_events_search_count($Name){
             if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id'];
             $condition = '';
             if($_SESSION['role'] == 'admin'){
                $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
             }else{
                $condition = "AND FIND_IN_SET(id,(SELECT event_id from all_users WHERE user_id = '".$user_id."'))";
             }
             
            $fetch_live_events = mysqli_query($this->connect,"SELECT count(*) as totalcount FROM all_events WHERE event_end_date < CURDATE() ".$condition." and event_name LIKE '%$Name%' ORDER BY id desc");
            

            $inner_array = array();
            if(mysqli_num_rows($fetch_live_events) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_live_events)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }
        }


    function get_count_all_total_speakers(){
          if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id']; 
             $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
             $res_sql = mysqli_fetch_array($fetch_sql);
             $tanent_id= $res_sql['tanent_id'];

            // $count_total_email_sent = mysqli_query($this->connect,"select ifnull(sum(total_speakers),0) as speaker_cnt from speaker_dashboard_count ale,all_users au where FIND_IN_SET(ale.event_id, au.event_id)  AND  au.user_id='".$user_id."' AND ale.tanent_id='$tanent_id'");   

              $count_total_email_sent = mysqli_query($this->connect,"select ifnull(sum(total_speakers),0) as speaker_cnt from speaker_dashboard_count WHERE tanent_id='$tanent_id'");   
            $total_email_sent = 0;  
            $total_speaker_cnt = 0; 
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_speaker_cnt = $res['speaker_cnt'];
            }
            return $total_speaker_cnt;
         // if(!isset($_SESSION)){ session_start(); }
         //     $user_id = $_SESSION['user_id']; 
         //     $fetch_sql = mysqli_query($this->connect,"SELECT id from all_speakers als,all_users au where FIND_IN_SET(als.event_id, au.event_id)  AND  au.user_id='".$user_id."'  and als.event_id != 0 AND als.event_id != '' AND als.email_id!=''");      
         // return mysqli_num_rows($fetch_sql);
    }

    function get_count_all_total_sponsors(){
         if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id']; 
             $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
             $res_sql = mysqli_fetch_array($fetch_sql);
             $tanent_id= $res_sql['tanent_id'];

              $count_total_email_sent = mysqli_query($this->connect,"select ifnull(sum(total_sponsors),0) as sponsor_cnt from sponsor_dashboard_counts WHERE tanent_id='$tanent_id'");
            // $count_total_email_sent = mysqli_query($this->connect,"select ifnull(sum(total_sponsors),0) as sponsor_cnt from sponsor_dashboard_counts ale,all_users au where FIND_IN_SET(ale.event_id, au.event_id)  AND  au.user_id='".$user_id."' AND ale.tanent_id='$tanent_id'");   
            $total_email_sent = 0; 
            $total_sponsor_cnt = 0;   
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_sponsor_cnt = $res['sponsor_cnt'];
            }
            return $total_sponsor_cnt;

  
    }

    function get_count_all_total_masters(){
        $count_total_sponsors = mysqli_num_rows(mysqli_query($this->connect,"select * from all_masters where event_id != 0 "));
        if(empty($count_total_sponsors)) $count_total_sponsors = 0; 
        return $count_total_sponsors;
    }

      function get_count_total_email_sent(){

          if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id']; 
             $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
             $res_sql = mysqli_fetch_array($fetch_sql);
             $tanent_id= $res_sql['tanent_id'];

            // $count_total_email_sent = mysqli_query($this->connect,"select sum(speaker_email_count) as speaker_cnt,sum(sponsor_email_count) as sponsor_cnt,sum(master_email_count) as master_cnt from all_event_email_count ale,all_users au where FIND_IN_SET(ale.event_id, au.event_id)  AND  au.user_id='".$user_id."' AND ale.tanent_id='$tanent_id'");

             $count_total_email_sent = mysqli_query($this->connect,"select sum(speaker_email_count) as speaker_cnt,sum(sponsor_email_count) as sponsor_cnt,sum(master_email_count) as master_cnt from all_event_email_count WHERE tanent_id='$tanent_id'");   
            $total_email_sent = 0;    
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_speaker_cnt = $res['speaker_cnt'];
                $total_sponsor_cnt = $res['sponsor_cnt'];
                $total_master_cnt = $res['master_cnt'];
            }
            $total_email_sent=$total_speaker_cnt+$total_sponsor_cnt+$total_master_cnt;
            return $total_email_sent;

        //  if(!isset($_SESSION)){ session_start(); }
        //      $user_id = $_SESSION['user_id']; 
        //      $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
        //      $res_sql = mysqli_fetch_array($fetch_sql);
        //      $tanent_id= $res_sql['tanent_id'];


        // $count_total_email_sent = mysqli_query($this->connect,"SELECT count(*) as total_email_sent from(
        //     select id from all_logs where (operation = 'request missing information' OR operation = 'request missing documents') and (tanent_id='$tanent_id' OR created_by='$user_id')
        //     union
        //     select id from all_logs where (email_content != '') and (tanent_id='$tanent_id' OR created_by='$user_id')) tbl");   

        //     $total_email_sent = 0;    
        //     if( mysqli_num_rows($count_total_email_sent) > 0){
        //         $res = mysqli_fetch_array($count_total_email_sent);
        //         $total_email_sent = $res['total_email_sent'];
        //     }
        //     return $total_email_sent;
    }

     function get_count_total_time_saving(){
         if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id']; 
             $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
             $res_sql = mysqli_fetch_array($fetch_sql);
             $tanent_id= $res_sql['tanent_id'];

             // $count_total_email_sent = mysqli_query($this->connect,"select round((sum(speaker_email_count)/1000)*25,2) as speaker_cnt,round((sum(sponsor_email_count)/1000)*25,2) as sponsor_cnt,round((sum(master_email_count)/1000)*25,2) as master_cnt from all_event_email_count ale,all_users au where FIND_IN_SET(ale.event_id, au.event_id)  AND  au.user_id='".$user_id."' AND au.tanent_id='$tanent_id'");   

             $count_total_email_sent = mysqli_query($this->connect,"select round((sum(speaker_email_count)/1000)*25,2) as speaker_cnt,round((sum(sponsor_email_count)/1000)*25,2) as sponsor_cnt,round((sum(master_email_count)/1000)*25,2) as master_cnt from all_event_email_count WHERE tanent_id='$tanent_id'");   

            $total_hour_saving = 0;    
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_speaker_cnt = $res['speaker_cnt'];
                $total_sponsor_cnt = $res['sponsor_cnt'];
                $total_master_cnt = $res['master_cnt'];
            }
            $total_hour_saving=$total_speaker_cnt+$total_sponsor_cnt+$total_master_cnt;
            return $total_hour_saving;
        //  if(!isset($_SESSION)){ session_start(); }
        //      $user_id = $_SESSION['user_id']; 
        //      $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
        //      $res_sql = mysqli_fetch_array($fetch_sql);
        //      $tanent_id= $res_sql['tanent_id'];

        // $count_total_time_saving = mysqli_query($this->connect,"SELECT  round((count(*)/1000)*25,1)  as total_hour_save from(
        //     select id from all_logs where (operation = 'request missing information' OR operation = 'request missing documents')  and (tanent_id='$tanent_id' OR created_by='$user_id')
        //     union
        //     select id from all_logs where (email_content != '') and (tanent_id='$tanent_id' OR created_by='$user_id')) tbl;
        //     ");   
        //     $total_hour_saving = 0;    
        //     if( mysqli_num_rows($count_total_time_saving) > 0){
        //         $res = mysqli_fetch_array($count_total_time_saving);
        //         $total_hour_saving = $res['total_hour_save'];
        //     }
        //     return $total_hour_saving;
    }


    // get_event_total_speakers
    function get_event_total_speakers($eventid){
        // $fetch_sql = mysqli_query($this->connect,"SELECT id from all_speakers where event_id = '$eventid'");        
        //  return mysqli_num_rows($fetch_sql);
         $count_sql = mysqli_query($this->connect,"select ifnull(total_speakers,0) as total_speakers from speaker_dashboard_count WHERE event_id= '".$eventid."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_speakers'];
        return $total_speaker;
    }

    function get_event_approved_speakers($eventid){
        // $fetch_sql = mysqli_query($this->connect,"SELECT id from all_speakers where event_id = '$eventid' AND status = '4' ");
        // return mysqli_num_rows($fetch_sql);

        $count_sql = mysqli_query($this->connect,"select ifnull(total_approved,0) as total_approved from speaker_dashboard_count WHERE event_id= '".$eventid."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_approved'];
        return $total_speaker;
    }

      function fetch_all_events_desc($eid){

        $event_id = $eid;

       // return $event_id;

        $fetch_all_master_types = mysqli_query($this->connect,"SELECT * FROM all_events WHERE event_id = '$event_id' ");
        $inner_array = array();
        if( mysqli_num_rows($fetch_all_master_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_master_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }



    
    function fetch_all_users(){

       if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");   
         $res_sql = mysqli_fetch_array($fetch_sql);
         $tanent_id= $res_sql['tanent_id'];

        $fetch_all_masters = mysqli_query($this->connect,"SELECT * FROM all_users where tanent_id='".$tanent_id."' order by user_id desc");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
  function get_count_total_emails_sent($event_id){

    $fetch_all_templates = mysqli_query($this->connect,"select speaker_email_count from all_event_email_count where event_id = '".$event_id."'"); 
   $total_email_sent = 0;    
            if( mysqli_num_rows($fetch_all_templates) > 0){
                $res = mysqli_fetch_array($fetch_all_templates);
                $total_email_sent = $res['speaker_email_count'];

            }

        return $total_email_sent;

 //        $fetch_all_templates = mysqli_query($this->connect,"SELECT * FROM all_logs   WHERE event_id = '".$event_id."' AND (all_logs.operation='sent email to speaker scheduled' OR all_logs.operation='sent email to speaker'  OR
 // all_logs.operation='request missing information' OR all_logs.operation='request missing documents' OR
 // all_logs.operation='request missing information scheduled' OR all_logs.operation='request missing documents scheduled' )  "); 

 //        echo mysqli_num_rows($fetch_all_templates);

    }

    function get_count_total_emails_sent_sponsor($event_id){
         $fetch_all_templates = mysqli_query($this->connect,"select sponsor_email_count from all_event_email_count where event_id = '".$event_id."'"); 
        $total_email_sent = 0;    
            if( mysqli_num_rows($fetch_all_templates) > 0){
                $res = mysqli_fetch_array($fetch_all_templates);
                $total_email_sent = $res['sponsor_email_count'];
                
            }

        return $total_email_sent;
      // $fetch_all_templates = mysqli_query($this->connect,"SELECT * FROM all_logs   WHERE event_id = '".$event_id."' AND (all_logs.operation='sent email to sponsor' or all_logs.operation='sent email to sponsor scheduled' or all_logs.operation='request missing information sponsor' or all_logs.operation='request missing documents sponsor')  ");
      //   echo mysqli_num_rows($fetch_all_templates);

    }
    
    function get_count_total_emails_sent_and_read(){

        $fetch_all_templates = mysqli_query($this->connect,"SELECT * FROM all_logs   WHERE all_logs.operation='sent email to master' AND email_read='y'  ");
        echo mysqli_num_rows($fetch_all_templates);

    }
    function get_count_total_emails_sent_and_read_speaker($event_id){
        // $fetch_all_templates = mysqli_query($this->connect,"SELECT * FROM all_logs   WHERE (all_logs.operation='sent email to speaker scheduled' OR all_logs.operation='sent email to speaker'  OR
        // all_logs.operation='request missing information' OR all_logs.operation='request missing documents' OR
        // all_logs.operation='request missing information scheduled' OR all_logs.operation='request missing documents scheduled' ) AND email_read='y' AND event_id = '".$event_id."' ");
        // echo mysqli_num_rows($fetch_all_templates);

     $count_sql = mysqli_query($this->connect,"select total_email_opened from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_email_opened'];
        return $total_speaker;

    }
    function get_count_total_emails_sent_and_read_sponsor($event_id){

        $fetch_all_templates = mysqli_query($this->connect,"SELECT * FROM all_logs   WHERE (all_logs.operation='sent email to sponsor' or all_logs.operation='sent email to sponsor scheduled' or all_logs.operation='request missing information sponsor' or all_logs.operation='request missing documents sponsor') AND email_read='y' AND event_id = '".$event_id."' ");
        echo mysqli_num_rows($fetch_all_templates);

    }
    function fetch_social_medial_score_calculator($param){

        //$fetch_all_masters = mysqli_query($this->connect,"SELECT *,all_status.id as status_id,all_masters.id as id FROM all_masters LEFT JOIN all_status ON all_masters.status = all_status.id");
          $fetch_sql = mysqli_query($this->connect,"SELECT * FROM social_medial_score_calculator WHERE social_media = '".$param."' ORDER BY point ASC ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
    
     function get_count_social_media($param,$event_id){
        if($param == 'influencer'){
            // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE social_media_total_score > 5 AND social_media_total_score < 8 AND event_id= '".$event_id."'  " ));
            $count_sql = mysqli_query($this->connect,"select total_influencer from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
            if(empty($count_sql)) $total_speaker = 0; 
            $res_sql=mysqli_fetch_array($count_sql);
            $total_speaker=$res_sql['total_influencer'];
        
        }else if($param == 'thought_leader'){
            // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE social_media_total_score >= 8 AND event_id= '".$event_id."' "));
             $count_sql = mysqli_query($this->connect,"select total_thought_leader from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
            if(empty($count_sql)) $total_speaker = 0; 
            $res_sql=mysqli_fetch_array($count_sql);
            $total_speaker=$res_sql['total_thought_leader'];
        
        }else if($param == 'connector'){
            // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE social_media_total_score > 2 AND social_media_total_score <= 5 AND event_id= '".$event_id."' "));
             $count_sql = mysqli_query($this->connect,"select total_connector from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
            if(empty($count_sql)) $total_speaker = 0; 
            $res_sql=mysqli_fetch_array($count_sql);
            $total_speaker=$res_sql['total_connector'];
        
        }else if($param == 'novice_speaker'){
            // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE social_media_total_score <= 2 AND event_id= '".$event_id."' "));
            $count_sql = mysqli_query($this->connect,"select total_novice_speaker from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
            if(empty($count_sql)) $total_speaker = 0; 
            $res_sql=mysqli_fetch_array($count_sql);
            $total_speaker=$res_sql['total_novice_speaker'];
        }
        if(empty($total_speaker)) return 0;
        else return $total_speaker;
    }

    function fetch_all_tanents(){

        
        $fetch_all_tanents = mysqli_query($this->connect,"SELECT * FROM all_tanents ORDER BY all_tanents.id DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_tanents) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_tanents)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_all_privileges(){

        
        $fetch_all_privileges = mysqli_query($this->connect,"SELECT * FROM privileges");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_privileges) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_privileges)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_tenant_by_id($tnid){

        $fetch_tenant_details = mysqli_query($this->connect,"SELECT * FROM all_tanents where id = '$tnid'");
        $inner_array = array();
        if(mysqli_num_rows($fetch_tenant_details) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_tenant_details)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function get_user_details_by_id($uid){

        $fetch_user_details = mysqli_query($this->connect,"SELECT * FROM all_users where user_id = '$uid'");
        $inner_array = array();
        if(mysqli_num_rows($fetch_user_details) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_user_details)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_roles(){

        $fetch_all_roles = mysqli_query($this->connect,"SELECT * FROM all_role ORDER BY roleid ASC");
        $rinner_array = array();
        if(mysqli_num_rows($fetch_all_roles) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_roles)){
                $rinner_array[] = $row;
            }
            return $rinner_array;            
        }
        else{
            return $rinner_array;
        }
    }


    function fetch_menus(){

        $fetch_all_menus = mysqli_query($this->connect,"SELECT * FROM mainmenus ORDER BY menu_id ASC");
        $minner_array = array();
        if(mysqli_num_rows($fetch_all_menus) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_menus)){
                $minner_array[] = $row;
            }
            return $minner_array;            
        }
        else{
            return $minner_array;
        }
    }

    function fetch_all_role_types(){

    
        // $fetch_all_resource_types = mysqli_query($this->connect,"select a.roleid,a.rolename,ifnull(group_concat((select menu from mainmenus mm where ra.MainMenuid=mm.menu_id) SEPARATOR ' | '),'Not Assigned') as menu_assigned from all_role a left outer join role_assigned ra
        //     on a.roleid=ra.roleid group by roleid");
        $fetch_all_resource_types = mysqli_query($this->connect,"select a.defaultrole_flag,a.roleid,a.rolename,ifnull(group_concat((select menu from mainmenus mm where ra.MainMenuid=mm.menu_id) SEPARATOR ' | '),'Not Assigned') as menu_assigned from all_role a left outer join role_assigned ra
            on a.roleid=ra.roleid group by roleid");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_a_role_type($id){

        $fetch_resource_type = mysqli_query($this->connect,"SELECT * FROM all_role WHERE roleid=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_resource_type) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_resource_type)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_a_role_typeassigned($id){

        $fetch_resource_type = mysqli_query($this->connect,"SELECT group_concat(MainMenuid) as MainMenuid FROM role_assigned WHERE Roleid=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_resource_type) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_resource_type)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

     function fetch_a_speaker_status($id){

        $fetch_all_speaker_types = mysqli_query($this->connect,"SELECT * FROM all_status WHERE id=".$id);
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

        
    }

  function fetch_a_scheduled_email_list($evt_id=null){
        $event_id= $evt_id;

         $fetch_all_email = mysqli_query($this->connect,"SELECT id,speaker_emailid,user_scheduledtime as scheduleddatetime,template_sub,type,emailtype FROM tbl_sendlatermaildetails WHERE 
            date(scheduleddatetime)>=date(now()) and emailtype=1 and issent=0  and event_id='".$event_id."'
            union
            SELECT id,'Bulkmail' as speaker_emailid,user_scheduledtime as scheduleddatetime,template_sub,type,emailtype FROM tbl_sendlatermaildetails WHERE
            date(scheduleddatetime)>=date(now()) and issent=0  and event_id='".$event_id."' and emailtype=2 group by template_sub,scheduleddatetime ");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_email) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email)){
                $inner_array[] = $row;
            }
                    
        }
        else{
            $inner_array='';
        }
        return $inner_array;  
        
    }

     function get_count_all_unique_contacts(){
         if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id']; 
             $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
             $res_sql = mysqli_fetch_array($fetch_sql);
             $tanent_id= $res_sql['tanent_id'];
             $total_email_sent = 0; 

             $count_total_email_sent_speaker = mysqli_query($this->connect,"select sum(total_speakers) as speaker_cnt from speaker_dashboard_count ale where tanent_id='$tanent_id'");   

            if( mysqli_num_rows($count_total_email_sent_speaker) > 0){
                $res = mysqli_fetch_array($count_total_email_sent_speaker);
                $total_speaker_cnt = $res['speaker_cnt'];
            }

             $count_total_email_sent_sponsor = mysqli_query($this->connect,"select sum(total_sponsors) as sponsor_cnt from sponsor_dashboard_counts  where tanent_id='$tanent_id'");   

            if( mysqli_num_rows($count_total_email_sent_sponsor) > 0){
                $res1 = mysqli_fetch_array($count_total_email_sent_sponsor);
                $total_sponsor_cnt = $res1['sponsor_cnt'];
            }

             $count_total_email_sent_master = mysqli_query($this->connect,"select sum(total_contact) as master_cnt from master_dashboard_counts  where tanent_id='$tanent_id'");   

            if( mysqli_num_rows($count_total_email_sent_master) > 0){
                $res2 = mysqli_fetch_array($count_total_email_sent_master);
                $total_master_cnt = $res2['master_cnt'];
            }

            $total_email_sent=$total_speaker_cnt+$total_sponsor_cnt+$total_master_cnt;
            return $total_email_sent;
        // if(!isset($_SESSION)){ session_start(); }
        // $user_id = $_SESSION['user_id'];

        // $count_total_contacts = mysqli_num_rows(mysqli_query($this->connect,"SELECT  email_id from (
        //     select  email_id from all_speakers als,all_users au where FIND_IN_SET(als.event_id, au.event_id)  AND  au.user_id='".$user_id."' AND email_id!=''
        //     union all select  sponsor_contact_email_address as email_id from all_sponsors asp,all_users au where FIND_IN_SET(asp.event_id, au.event_id)  AND  au.user_id='".$user_id."' AND sponsor_contact_email_address!=''
        //     union all select  email_id from all_masters am,all_users au where FIND_IN_SET(am.event_id, au.event_id)  AND  au.user_id='".$user_id."' AND email_id!='') t"));
        // if(empty($count_total_contacts)) $count_total_contacts = 0; 
        // return $count_total_contacts;
    }

    function get_total_contacts_count_by_tenantid($tenant_id=null){
            
            $total_count = 0;
            $count_total_contacts = mysqli_query($this->connect,"SELECT  count(email_id) as total_count from (
            select  email_id from all_speakers where tanent_id = '".$tenant_id."'
            union all 
            select  sponsor_contact_email_address as email_id from all_sponsors where tanent_id = '".$tenant_id."'
            union all
             select  email_id from all_masters where tanent_id = '".$tenant_id."') t");
            $res_count = mysqli_fetch_array($count_total_contacts);
            $total_count = $res_count['total_count'];
             return $total_count;

    }

   function fetch_total_all_speakers(){
        if(!isset($_SESSION)){ session_start(); }
        $user_id = $_SESSION['user_id'];

         $fetch_all_speakers = mysqli_query($this->connect,"SELECT als.id,als.speaker_name,als.email_id,als.company,als.phone,als.social_media_total_score,(select count(al.id) from all_logs al where al.table_id=als.id AND (al.operation='sent email to speaker' OR al.operation='sent email to speaker scheduled' OR al.operation='request missing information' OR al.operation='request missing documents' OR al.operation='request missing information scheduled' OR al.operation='request missing documents scheduled')) as count_email_sent,(SELECT event_name from all_events where all_events.id=als.event_id) as participated from all_speakers als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."'  and als.event_id != 0 AND als.event_id != '' AND als.email_id!=''");

        // $fetch_all_speakers = mysqli_query($this->connect,"SELECT als.id,als.speaker_name,als.email_id,als.company,als.phone,als.social_media_total_score,(select count(al.id) from all_logs al where al.table_id=als.id AND (al.operation='sent email to speaker' OR al.operation='sent email to speaker scheduled' OR al.operation='request missing information' OR al.operation='request missing documents' OR al.operation='request missing information scheduled' OR al.operation='request missing documents scheduled')) as count_email_sent,(select count(distinct event_id) from all_speakers where all_speakers.email_id=als.email_id and FIND_IN_SET(all_speakers.event_id, au.event_id) AND  au.user_id='".$user_id."'  and all_speakers.event_id != 0 AND all_speakers.event_id != '') as participated from all_speakers als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."'  and als.event_id != 0 AND als.event_id != '' AND als.email_id!='' group by als.email_id having(count(*))>0");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

     function fetch_total_all_sponsors(){
         if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];

         $fetch_all_sponsors = mysqli_query($this->connect," SELECT als.id,als.sponsor_company_name,als.sponsor_contact_person,als.sponsor_contact_email_address,als.sponsor_contact_number,(select count(al.id) from all_logs al where  al.table_id=als.id AND (al.operation='sent email to sponsor' or al.operation='sent email to sponsor scheduled' or al.operation='request missing information sponsor' or al.operation='request missing documents sponsor' OR al.operation='request missing information sponsor scheduled' or al.operation='request missing documents sponsor scheduled')) as count_email_sent,(SELECT event_name from all_events where all_events.id=als.event_id) as participated from all_sponsors als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."'  and als.sponsor_contact_email_address !='' AND als.event_id != ''");

          // $fetch_all_sponsors = mysqli_query($this->connect," SELECT als.id,als.sponsor_company_name,als.sponsor_contact_person,als.sponsor_contact_email_address,als.sponsor_contact_number,(select count(al.id) from all_logs al where  al.table_id=als.id AND (al.operation='sent email to sponsor' or al.operation='sent email to sponsor scheduled' or al.operation='request missing information sponsor' or al.operation='request missing documents sponsor' OR al.operation='request missing information sponsor scheduled' or al.operation='request missing documents sponsor scheduled')) as count_email_sent,(select count(distinct event_id) from all_sponsors where all_sponsors.sponsor_contact_email_address=als.sponsor_contact_email_address and FIND_IN_SET(all_sponsors.event_id, au.event_id) AND  au.user_id='".$user_id."'  and all_sponsors.event_id != 0 AND all_sponsors.event_id != '') as participated from all_sponsors als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."'  and als.event_id != 0 AND als.event_id != '' group by als.sponsor_contact_email_address having(count(*))>0");
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsors) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsors)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

     function fetch_total_all_speakers_count(){
         if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];

          $fetch_all_speakers = mysqli_query($this->connect,"SELECT count(*) as totalcount from all_speakers als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."'  and als.event_id != 0 AND als.event_id != ''");
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_total_all_sponsors_count(){
          if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];

          $fetch_all_sponsors = mysqli_query($this->connect," SELECT count(*) as totalcount from all_sponsors als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."'  and als.event_id != 0 AND als.event_id != ''");
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsors) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsors)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

           function fetch_all_ppt_for_speaker($sp_id){
        //return $sp_id;

        $fetch_all_speaker_ppt= mysqli_query($this->connect,"SELECT * FROM speaker_documents WHERE  doc_type = 'ppt' AND speaker_id ='".$sp_id."' AND is_deleted = '0' ORDER BY id DESC ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_ppt) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_ppt)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_all_video_for_speaker($sp_id){
       //  return $sp_id;

        $fetch_all_speaker_vdo = mysqli_query($this->connect,"SELECT * FROM speaker_documents WHERE doc_type = 'video' AND speaker_id ='".$sp_id."' AND is_deleted = '0' ORDER BY id DESC ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_vdo) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_vdo)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    } 



    function fetch_all_offers_for_speaker($sp_id){
       //  return $sp_id;

        $fetch_all_speaker_offer = mysqli_query($this->connect,"SELECT * FROM speaker_documents WHERE doc_type = 'offer' AND speaker_id ='".$sp_id."' AND is_deleted = '0' ORDER BY id DESC ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_offer) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_offer)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    } 

    function get_event_total_speakers_live_events($eventid){
        include("include/mysqli_connect.php");
        $fetch_sql = mysqli_query($connect,"SELECT id from all_speakers where event_id = '$eventid'");        
         return mysqli_num_rows($fetch_sql);
    }

    function get_event_approved_speakers_live_events($eventid){
        include("include/mysqli_connect.php");
        $fetch_sql = mysqli_query($connect,"SELECT id from all_speakers where event_id = '$eventid' AND status = '4' ");
        return mysqli_num_rows($fetch_sql);
    }

        function get_scheduled_last5_used_email_templates_speaker($event_id){

         $fetch_sql = mysqli_query($this->connect,"SELECT  template_name,id,count,email_opened_data,user_scheduledtime from (
                SELECT  template_name,id,count,email_opened_data,user_scheduledtime from (SELECT distinct aet.template_name,aet.id,
                (select count(*) from tbl_sendlatermaildetails where aet.id = template_id AND `type` 
                LIKE '%Speaker%' AND event_id ='".$event_id."') as count,(select count(*) from all_logs als 
                where als.operation='sent email to speaker scheduled' and als.event_id='".$event_id."' and als.other_column_value=aet.id and email_read='y' and als.other_column_name='template_id') as email_opened_data,user_scheduledtime FROM all_email_templates aet, tbl_sendlatermaildetails al WHERE aet.id = al.template_id AND aet.template_type LIKE '%speaker%' AND al.`type` LIKE '%Speaker%' AND al.event_id= '".$event_id."' ORDER BY al.user_scheduledtime DESC) t1
                union 
                SELECT  template_name,id,count,email_opened_data,user_scheduledtime from (SELECT distinct 'Request missing information' as  template_name,'9998' as id,(select count(*) from tbl_sendlatermaildetails where `type`='missing-info-collect' AND event_id ='".$event_id."') as count,(select count(*) from all_logs als 
                where als.operation='request missing information scheduled' and als.event_id='".$event_id."' and email_read='y') as email_opened_data,user_scheduledtime FROM tbl_sendlatermaildetails al 
                WHERE al.`type`='missing-info-collect' AND al.event_id= '".$event_id."' ORDER BY al.user_scheduledtime DESC) t2
                union
                SELECT  template_name,id,count,email_opened_data,user_scheduledtime from (SELECT distinct 'Request missing documents' as  template_name,'9999' as id,(select count(*) from tbl_sendlatermaildetails where `type`='missing-document-collect' AND event_id ='".$event_id."') as count,(select count(*) from all_logs als 
                where als.operation='request missing documents scheduled' and als.event_id='".$event_id."' and email_read='y') as email_opened_data,user_scheduledtime FROM tbl_sendlatermaildetails al WHERE al.`type`='missing-document-collect' AND al.event_id= '".$event_id."' ORDER BY al.user_scheduledtime DESC) t3
                ) temp group by temp.template_name  order by temp.user_scheduledtime desc  LIMIT 5");
         
        // $fetch_sql = mysqli_query($this->connect,"SELECT distinct aet.template_name,aet.id,(select count(*) from tbl_sendlatermaildetails where aet.id = template_id AND `type` LIKE '%Speaker%' AND event_id = '".$event_id."') as count,(select count(*) from all_logs als where als.operation='sent email to speaker scheduled' and als.event_id='".$event_id."' and als.other_column_value=aet.id and email_read='y' and als.other_column_name='template_id') as email_opened_data FROM all_email_templates aet, tbl_sendlatermaildetails al WHERE aet.id = al.template_id AND aet.template_type LIKE '%speaker%' AND al.`type` LIKE '%Speaker%' AND al.event_id= '".$event_id."' ORDER BY al.user_scheduledtime DESC LIMIT 5");

        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }        
    }

    function get_count_speakers_with_no_presentations($event_id){
        // $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_speakers WHERE (presentation_title1='' AND presentation_title2='' AND presentation_title3='') AND event_id = '".$event_id."' "));
        $count_sql = mysqli_query($this->connect,"select total_no_presentation from speaker_dashboard_count WHERE event_id= '".$event_id."' ");
        if(empty($count_sql)) $total_speaker = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_speaker=$res_sql['total_no_presentation'];
        return $total_speaker;
    }
    
     function get_speaker_info_missing_value($id=null)
    {
         $a= $this->get_personal_info_cal($id);
        $b= $this->get_headshot_info_cal($id);
        $c= $this->get_socialmedia_info_cal($id);
        $total_missing=$a+$b+$c;
        $final_shorten=100-$total_missing;
        return round($final_shorten);
    }

   function get_personal_info_cal($id)
    {
        $v1=0;
        $v2=0;
        $v3=0;
        $v4=0;
        $v5=0;

        $sql1 = "select speaker_name from all_speakers where id='".$id."'";
        $res1=mysqli_query($this->connect, $sql1);
        while($row1 = $res1->fetch_assoc()) {
             $rescnt1=$row1["speaker_name"];
         }

         if($rescnt1=='' or $rescnt1 == null or $rescnt1 == 'null')
         {
            $v1=8;
         }

         $sql2 = "select email_id from all_speakers where id='".$id."'";
        $res2=mysqli_query($this->connect, $sql2);
        while($row2 = $res2->fetch_assoc()) {
             $rescnt2=$row2["email_id"];
         }

         if($rescnt2=='' or $rescnt2 == null or $rescnt2 == 'null')
         {
            $v2=8;
         }

         $sql3 = "select phone from all_speakers where id='".$id."'";
        $res3=mysqli_query($this->connect, $sql3);
        while($row3 = $res3->fetch_assoc()) {
             $rescnt3=$row3["phone"];
         }

         if($rescnt3=='' or $rescnt3 == null or $rescnt3 == 'null')
         {
            $v3=8;
         }

         $sql4 = "select company from all_speakers where id='".$id."' ";
        $res4=mysqli_query($this->connect, $sql4);
        while($row4 = $res4->fetch_assoc()) {
             $rescnt4=$row4["company"];
         }

         if($rescnt4=='' or $rescnt4 == null or $rescnt4 == 'null')
         {
            $v4=8;
         }

         $sql5 = "select title from all_speakers where id='".$id."'";
        $res5=mysqli_query($this->connect, $sql5);
        while($row5 = $res5->fetch_assoc()) {
             $rescnt5=$row5["title"];
         }

         if($rescnt5=='' or $rescnt5 == null or $rescnt5 == 'null')
         {
            $v5=8;
         }

         $total_missing_personal_info=$v1+$v2+$v3+$v4+$v5;
         return $total_missing_personal_info;

    }

    function get_headshot_info_cal($id)
    {
        $v1=0;
        $v2=0;
        $v3=0;

        $sql1 = "select head_shot from all_speakers where id='".$id."'";
        $res1=mysqli_query($this->connect, $sql1);
        while($row1 = $res1->fetch_assoc()) {
             $rescnt1=$row1["head_shot"];
         }

         if($rescnt1=='' or $rescnt1 == null or $rescnt1 == 'null')
         {
            $v1=13.33;
         }

         $sql2 = "select your_quote from all_speakers where id='".$id."'";
        $res2=mysqli_query($this->connect, $sql2);
        while($row2 = $res2->fetch_assoc()) {
             $rescnt2=$row2["your_quote"];
         }

         if($rescnt2=='' or $rescnt2 == null or $rescnt2 == 'null')
         {
            $v2=13.33;
         }

         $sql3 = "select short_bio from all_speakers where id='".$id."'";
        $res3=mysqli_query($this->connect, $sql3);
        while($row3 = $res3->fetch_assoc()) {
             $rescnt3=$row3["short_bio"];
         }

         if($rescnt3=='' or $rescnt3 == null or $rescnt3 == 'null')
         {
            $v3=13.33;
         }


         $headshot_info=$v1+$v2+$v3;
         return $headshot_info;  
    }

    function get_socialmedia_info_cal($id)
    { 
        $v1=0;
        $v2=0;

        $sql1 = "select linkedin_handle from all_speakers where id='".$id."'";
        $res1=mysqli_query($this->connect, $sql1);
        while($row1 = $res1->fetch_assoc()) {
             $rescnt1=$row1["linkedin_handle"];
         }

         if($rescnt1=='' or $rescnt1 == null or $rescnt1 == 'null')
         {
            $v1=10;
         }

         $sql2 = "select linkedin_url from all_speakers where id='".$id."'";
        $res2=mysqli_query($this->connect, $sql2);
        while($row2 = $res2->fetch_assoc()) {
             $rescnt2=$row2["linkedin_url"];
         }

         if($rescnt2=='' or $rescnt2 == null or $rescnt2 == 'null')
         {
            $v2=10;
         } 

        $socialmedia_info=$v1+$v2;
      return $socialmedia_info;
    }
        
        function fetch_all_speakers_by_opportunity_type($id,$start=1,$limit,$evt_id){

             $event_id= $evt_id;

             $fetch_all_speakers = mysqli_query($this->connect,"SELECT all_status.status_name,company,phone,speaker_type,profile_completeness,speaker_name,email_id,social_media_total_score,all_status.id as status_id,all_speakers.id as id,0 as log_id,now() as created_at,'AA' as template_name,0 as template_id,mail_sent_count as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE FIND_IN_SET('".$id."', speaker_type)  and all_speakers.event_id = '".$event_id."'  ORDER BY all_speakers.id DESC LIMIT $start,$limit");
        
            // $fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_status.id as status_id,all_speakers.id as id, (select other_column_value from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as created_at, (select count(all_logs.id) from all_logs RIGHT JOIN all_email_templates ON all_email_templates.id = all_logs.other_column_value WHERE table_id=all_speakers.id AND operation='sent email to speaker') as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE FIND_IN_SET('".$id."', speaker_type)  and all_speakers.event_id = '".$event_id."'  ORDER BY all_speakers.id DESC LIMIT $start,$limit");

        // $event_id= $evt_id;
        
        // $fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_status.id as status_id,all_speakers.id as id, (select other_column_value from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as created_at, (select count(all_logs.id) from all_logs RIGHT JOIN all_email_templates ON all_email_templates.id = all_logs.other_column_value WHERE table_id=all_speakers.id AND operation='sent email to speaker') as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE FIND_IN_SET('".$id."', speaker_type)  and all_speakers.event_id = '".$event_id."'  ORDER BY all_speakers.id DESC");
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function get_count_opportunity_type_email_count($event_id,$id){
        include("include/mysqli_connect.php");
        $count = mysqli_num_rows(mysqli_query(  $connect,"SELECT all_email_templates.template_name,all_speakers.email_id as sent_to,all_users.email as sent_by,all_logs.created_at as sent_on,all_logs.email_read FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value 
        LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_speakers ON all_speakers.id=all_logs.table_id  WHERE all_logs.operation='sent email to speaker' 
        AND all_logs.table_id in (select id from all_speakers where FIND_IN_SET('".$id."', speaker_type) AND event_id='".$event_id."') AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC"));
        if(empty($count))return 0;
        else return $count;
    }

 function fetch_all_speaker_requests_asc(){

        $fetch_all_speaker_types = mysqli_query($this->connect,"SELECT * FROM speaker_requests ORDER BY request_name ASC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

       function get_count_masters_unique_contacts($event_id){
        $count_total_contacts = mysqli_num_rows(mysqli_query($this->connect,"select email_id from all_masters where event_id='".$event_id."'"));
        if(empty($count_total_contacts)) $count_total_contacts = 0; 
        return $count_total_contacts;
    }

     function get_master_dashboard_all_counts($event_id){
         $inner_array = array();
        $total_contacts_sql = mysqli_query($this->connect,"SELECT total_contact,total_email_opened,missing_company_name,missing_linkedin_url,missing_pone_number from master_dashboard_counts where event_id='".$event_id."'");        
        $row = mysqli_fetch_array($total_contacts_sql);
        $inner_array[] = $row;
        return $inner_array;
    }


    function get_count_masters_total_emails_sent($event_id){

         $fetch_all_templates = mysqli_query($this->connect,"select master_email_count from all_event_email_count where event_id = '".$event_id."'"); 
        $total_email_sent = 0;    
            if( mysqli_num_rows($fetch_all_templates) > 0){
                $res = mysqli_fetch_array($fetch_all_templates);
                $total_email_sent = $res['master_email_count'];
                
            }

        return $total_email_sent;

        // $fetch_all_templates = mysqli_query($this->connect,"SELECT * FROM all_logs   WHERE event_id = '".$event_id."' AND (all_logs.operation='sent email to master scheduled' OR all_logs.operation='sent email to master' )  ");
        // echo mysqli_num_rows($fetch_all_templates);

    }

    function get_count_masters_total_emails_read($event_id){

        $fetch_all_templates = mysqli_query($this->connect,"SELECT * FROM all_logs   WHERE (all_logs.operation='sent email to master' OR all_logs.operation='sent email to master scheduled') AND email_read='y' AND event_id = '".$event_id."' ");
        echo mysqli_num_rows($fetch_all_templates);

    }

    function get_master_oppertunity_types($event_id){
        $fetch_sql = mysqli_query($this->connect,"SELECT c.master_type_name,c.id,c.total_masters_enrolled as count,c.total_email_count FROM all_master_types c WHERE event_id = '".$event_id."'  GROUP BY c.id ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
        
    }

  function get_count_master_type_email_count($event_id,$id){
        include("include/mysqli_connect.php");
        $count = mysqli_num_rows(mysqli_query($connect,"SELECT all_email_templates.template_name,all_masters.email_id as sent_to,all_users.email as sent_by,all_logs.created_at as sent_on,all_logs.email_read FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value 
        LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_masters ON all_masters.id=all_logs.table_id  WHERE all_logs.operation='sent email to master' AND all_logs.table_id in (select id from all_masters where FIND_IN_SET('".$id."', master_type) AND event_id='".$event_id."') AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC"));
        if(empty($count))return 0;
        else return $count;
    }

    function fetch_all_masters_by_opportunity_type($id,$start=1, $limit=null,$evt_id){

        $event_id= $evt_id;

        // $fetch_all_masters = mysqli_query($this->connect,"SELECT *,all_masters.id as id, (select other_column_value from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as created_at   FROM all_masters WHERE event_id = '".$event_id."' AND FIND_IN_SET('".$id."', master_type) ORDER BY all_masters.id DESC LIMIT $start, $limit");
        
        $fetch_all_masters = mysqli_query($this->connect,"SELECT am.id,am.company,am.master_type,am.master_name,am.email_id,am.phone,am.job_title,'0' as template_id,mail_sent_count as total_email_sent, 'AA' as template_name FROM all_masters am WHERE am.event_id = '".$event_id."' AND FIND_IN_SET('".$id."', am.master_type) ORDER BY am.id DESC LIMIT $start, $limit");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

       function get_count_masters_with_no_company($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_masters WHERE company='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

    function get_count_masters_with_no_linked_handles($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_masters WHERE linkedin_url='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

    function get_count_masters_with_no_mobile($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_masters WHERE phone='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

function fetch_all_masters_with_conditions($var,$id,$section,$start=1,$limit=null,$evt_id){
    
        $event_id= $evt_id;
        
        if($section == "masters_with_no_company"){
            
            $condition = " all_masters.company='' ";
            
        }else if($section == "masters_with_no_linked_handles"){
            
            $condition = " all_masters.linkedin_url='' ";
            
        }else if($section == "masters_with_no_mobile"){
            
            $condition = " all_masters.phone='' ";
            
        }

        $fetch_all_masters = mysqli_query($this->connect,"SELECT id,company,master_type,master_name,email_id,phone,job_title,'0' as template_id,mail_sent_count as total_email_sent, 'AA' as template_name FROM all_masters  WHERE ".$condition." AND event_id = '".$event_id."' ORDER BY all_masters.id DESC LIMIT $start, $limit");

        // $fetch_all_masters = mysqli_query($this->connect,"SELECT *,all_masters.id as id, (select other_column_value from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_masters.id AND operation='sent email to master' ORDER BY id DESC LIMIT 1) as created_at   FROM all_masters WHERE ".$condition." AND event_id = '".$event_id."' ORDER BY all_masters.id DESC LIMIT $start, $limit");
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function get_last5_used_email_templates_master($event_id){
        
        $fetch_sql = mysqli_query($this->connect,"select template_name,template_id as id,
         total_email_sent as Emailcount,total_email_opened as email_opened_data,created_at FROM recent_communication_master  WHERE event_id='".$event_id."'  order by created_at desc LIMIT 5");

        // $fetch_sql = mysqli_query($this->connect,"SELECT distinct aet.template_name,aet.id,(select count(*) from all_logs als where als.operation='sent email to master' and als.event_id='".$event_id."' and als.other_column_value=aet.id and als.other_column_name='template_id') as Emailcount,(select count(*) from all_logs als where als.operation='sent email to master' and als.event_id='".$event_id."' and als.other_column_value=aet.id and email_read='y' and als.other_column_name='template_id') as email_opened_data FROM all_email_templates aet, all_logs al WHERE aet.id = al.other_column_value AND aet.template_type LIKE '%master%' AND al.operation='sent email to master' AND al.event_id= '".$event_id."' ORDER BY al.created_at DESC LIMIT 5");

        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }        
    
    }

  function get_scheduled_last5_used_email_templates_master($event_id){

        $fetch_sql = mysqli_query($this->connect,"SELECT distinct aet.template_name,aet.id,(select count(*) from tbl_sendlatermaildetails where aet.id = template_id AND `type` LIKE '%master%' AND event_id = '".$event_id."') as count,(select count(*) from all_logs als where als.operation='sent email to master scheduled' and als.event_id='".$event_id."' and als.other_column_value=aet.id and email_read='y' and als.other_column_name='template_id') as email_opened_data FROM all_email_templates aet, tbl_sendlatermaildetails al WHERE aet.id = al.template_id AND aet.template_type LIKE '%master%' AND al.`type` LIKE '%master%' AND al.event_id= '".$event_id."' ORDER BY al.user_scheduledtime DESC LIMIT 5");

        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }        
    }

    function fetch_all_event_presentation($evt_id=null){

        $event_id= $evt_id;

          $fetch_all_masters = mysqli_query($this->connect,"SELECT ep.*,(select group_concat(speaker_id) from event_agenda_speakers where event_agenda_speakers.ep_id=ep.ep_id) as speaker_id,total_email_sent as count_email_sent,total_team_scheduled_email as count_team_email_sent from event_presentation ep where event_id = '".$event_id."' order by event_date ASC,str_to_date(start_time, '%l:%i %p') ASC");
         // $fetch_all_masters = mysqli_query($this->connect,"SELECT ep.*,(select group_concat(speaker_id) from event_agenda_speakers where event_agenda_speakers.ep_id=ep.ep_id) as speaker_id,(select count(*) from all_logs al where al.event_id='".$event_id."' and (al.operation='sent email to speaker Event Presentation' or al.operation='Request for Update Agenda') and al.event_presentation_id=ep.ep_id) as count_email_sent from event_presentation ep where event_id = '".$event_id."' order by event_date ASC,str_to_date(start_time, '%l:%i %p') ASC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

     function fetch_all_speaker_for_event_presentation($evt_id=null){

        $event_id= $evt_id;

         $fetch_all_resource = mysqli_query($this->connect,"select id,speaker_name,email_id,company from all_speakers where event_id='".$event_id."' ORDER BY id DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_event_presentation_by_ep_id($ep_id){

        //$event_id= $_SESSION['current_event_id'];

        $fetch_all_masters = mysqli_query($this->connect,"SELECT ep.*,(select group_concat(speaker_id) from event_agenda_speakers where ep_id='".$ep_id."') as speaker_id from event_presentation ep where  ep_id='".$ep_id."'");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_speaker_for_event_presentation_by_id($id,$ep_id){

        //$event_id= $_SESSION['current_event_id'];
         $fetch_all_resource = mysqli_query($this->connect,"select id,speaker_name,email_id,company,phone,(select status_name from all_status where id=event_agenda_speakers.`status`) as status_name,influencer_total_score as influencer from event_agenda_speakers WHERE ep_id='".$ep_id."' AND speaker_id='".$id."' ORDER BY id DESC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }



           function fetch_all_ep_documents($ep_id){
            //$event_id= $_SESSION['current_event_id'];
            $fetch_all_speaker_ppt= mysqli_query($this->connect,"SELECT * FROM event_documents WHERE ep_id ='".$ep_id."' AND is_deleted = '0' ORDER BY id DESC ");
            $inner_array = array();
            if(mysqli_num_rows($fetch_all_speaker_ppt) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_all_speaker_ppt)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }

    }

     function fetch_event_presentation_note_by_id($ep_id){
           // $event_id= $_SESSION['current_event_id'];
            $fetch_all_speaker_ppt= mysqli_query($this->connect,"SELECT epn.id,epn.notes,epn.event_id,epn.ep_id,date_format(epn.created_at, '%d-%M-%Y') as created_at,ifnull((select speaker_name from all_speakers where id=epn.created_by), (select first_name from all_users where user_id=epn.created_by)) as addedby FROM event_presentation_notes epn WHERE ep_id ='".$ep_id."' ORDER BY id DESC ");
            $inner_array = array();
            if(mysqli_num_rows($fetch_all_speaker_ppt) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_all_speaker_ppt)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }

    }

     function fetch_all_speaker_for_popup($evt_id){
         if(!isset($_SESSION)){ session_start(); }
        $user_id = $_SESSION['user_id'];
        $event_id= $evt_id;

         $fetch_all_resource = mysqli_query($this->connect,"select als.event_id,als.id,als.speaker_name,als.email_id,als.company,als.phone,(select status_name from all_status where id=als.`status`) as status_name,als.social_media_total_score 
                from all_speakers als,all_users au where FIND_IN_SET(als.event_id, au.event_id)  AND  au.user_id='".$user_id."' and  als.event_id not in ('".$event_id."') and als.email_id not in (select email_id from  all_speakers where event_id='".$event_id."') group by als.email_id having count(*)>0");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_all_master_for_popup($evt_id){
        if(!isset($_SESSION)){ session_start(); }
        $user_id = $_SESSION['user_id'];
        $event_id= $evt_id;
         $fetch_all_resource = mysqli_query($this->connect,"select am.id,am.master_name,am.email_id,am.company,am.job_title from all_masters am,all_users au where FIND_IN_SET(am.event_id, au.event_id)  AND  au.user_id='".$user_id."' and am.event_id not in ('".$event_id."') and am.email_id not in (select email_id from  all_masters where event_id='".$event_id."') group by am.email_id having count(*)>0");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }
        function get_count_all_unique_contacts_speaker(){
        if(!isset($_SESSION)){ session_start(); }
        $user_id = $_SESSION['user_id'];

        $count_total_contacts = mysqli_num_rows(mysqli_query($this->connect,"select  email_id from all_speakers als,all_users au where FIND_IN_SET(als.event_id, au.event_id)  AND  au.user_id='".$user_id."' AND email_id!=''"));
        if(empty($count_total_contacts)) $count_total_contacts = 0; 
        return $count_total_contacts;
    }

    function get_count_all_unique_contacts_sponsor(){
        if(!isset($_SESSION)){ session_start(); }
        $user_id = $_SESSION['user_id'];

        $count_total_contacts = mysqli_num_rows(mysqli_query($this->connect,"select  sponsor_contact_email_address as email_id from all_sponsors asp,all_users au where FIND_IN_SET(asp.event_id, au.event_id)  AND  au.user_id='".$user_id."' AND sponsor_contact_email_address!=''"));
        if(empty($count_total_contacts)) $count_total_contacts = 0; 
        return $count_total_contacts;
    }

    function get_count_all_unique_contacts_master(){
        if(!isset($_SESSION)){ session_start(); }
        $user_id = $_SESSION['user_id'];
        $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
        $res_sql = mysqli_fetch_array($fetch_sql);
        $tanent_id= $res_sql['tanent_id']; 

        // $count_total_contacts = mysqli_query($this->connect,"select sum(total_contact) as master_cnt from master_dashboard_counts where tanent_id='$tanent_id'");  
        // $count_total_contacts = mysqli_num_rows(mysqli_query($this->connect,"select  email_id from all_masters am,all_users au where FIND_IN_SET(am.event_id, au.event_id)  AND  au.user_id='".$user_id."' AND email_id!=''"));
        // if(empty($count_total_contacts)) $count_total_contacts = 0; 

         $count_total_email_sent = mysqli_query($this->connect,"select sum(total_contact) as master_cnt from master_dashboard_counts where tanent_id='$tanent_id'");
            $total_email_sent = 0; 
            $total_master_cnt = 0;   
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_master_cnt = $res['master_cnt'];
            }
        return $total_master_cnt;
    }

    function fetch_all_unique_contacts_speaker(){
        if(!isset($_SESSION)){ session_start(); }
        $user_id = $_SESSION['user_id'];
        $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
        $res_sql = mysqli_fetch_array($fetch_sql);
        $tanent_id= $res_sql['tanent_id'];

        $fetch_all_speakers = mysqli_query($this->connect,"SELECT als.email_id,als.id,als.speaker_name,als.company,als.phone,mail_sent_count as count_email_sent,
            (SELECT event_name from all_events where all_events.id=als.event_id) as event_name
            from all_speakers als WHERE als.tanent_id='$tanent_id'");
         // $fetch_all_speakers = mysqli_query($this->connect,"SELECT als.email_id,als.id,als.speaker_name,als.company,als.phone,mail_sent_count as count_email_sent,
         //    (SELECT event_name from all_events where all_events.id=als.event_id) as event_name
         //    from all_speakers als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='$user_id' AND email_id!=''");

        // $fetch_all_speakers = mysqli_query($this->connect,"SELECT als.email_id,als.id,als.speaker_name,als.company,als.phone,(select count(al.id) from all_logs al where al.table_id=als.id AND (al.operation='sent email to speaker' OR al.operation='sent email to speaker scheduled')) as count_email_sent
        //     from all_speakers als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='$user_id' AND email_id!='' group by email_id having count(email_id)>0");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_all_unique_contacts_sponsors(){
         if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
         $res_sql = mysqli_fetch_array($fetch_sql);
         $tanent_id= $res_sql['tanent_id'];

          $fetch_all_sponsors = mysqli_query($this->connect,"SELECT als.id,als.sponsor_company_name,als.sponsor_contact_person,als.sponsor_contact_email_address,als.sponsor_contact_number,
            (SELECT event_name from all_events where all_events.id=als.event_id) as event_name,
            mail_sent_count as count_email_sent from all_sponsors als WHERE als.tanent_id='$tanent_id'");

         // $fetch_all_sponsors = mysqli_query($this->connect,"SELECT als.id,als.sponsor_company_name,als.sponsor_contact_person,als.sponsor_contact_email_address,als.sponsor_contact_number,
         //    (SELECT event_name from all_events where all_events.id=als.event_id) as event_name,
         //    mail_sent_count as count_email_sent from all_sponsors als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."'  and als.sponsor_contact_email_address != ''");
          // $fetch_all_sponsors = mysqli_query($this->connect,"SELECT als.id,als.sponsor_company_name,als.sponsor_contact_person,als.sponsor_contact_email_address,als.sponsor_contact_number,
          //   (select count(al.id) from all_logs al where  al.table_id=als.id AND (al.operation='sent email to sponsor' OR al.operation='sent email to sponsor scheduled')) as count_email_sent from all_sponsors als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."'  and als.sponsor_contact_email_address != '' group by sponsor_contact_email_address having count(sponsor_contact_email_address)>0");
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsors) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsors)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_all_unique_contacts_master(){
         if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
         $res_sql = mysqli_fetch_array($fetch_sql);
         $tanent_id= $res_sql['tanent_id'];

          $fetch_all_sponsors = mysqli_query($this->connect,"SELECT als.id,als.company,als.master_name,als.email_id,als.phone,mail_sent_count as count_email_sent,(SELECT event_name from all_events where all_events.id=als.event_id) as event_name from all_masters als WHERE als.tanent_id='$tanent_id'");

         // $fetch_all_sponsors = mysqli_query($this->connect,"SELECT als.id,als.company,als.master_name,als.email_id,als.phone,mail_sent_count as count_email_sent,(SELECT event_name from all_events where all_events.id=als.event_id) as event_name from all_masters als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."' and als.email_id != ''");
          // $fetch_all_sponsors = mysqli_query($this->connect,"SELECT als.id,als.company,als.master_name,als.email_id,als.phone,(select count(al.id) from all_logs al where  al.table_id=als.id AND (al.operation='sent email to master' OR al.operation='sent email to master scheduled')) as count_email_sent from all_masters als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."' and als.email_id != '' group by email_id having count(email_id)>0");
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsors) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsors)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

      function fetch_all_status_sponsor($val,$event_id=NULL){
        //$event_id= $_SESSION['current_event_id'];

          $fetch_all_status = mysqli_query($this->connect,"
            SELECT *,count_of_speaker_usage as count_of_sponsor_usage,
            ifnull((SELECT sum(potential_funding_ask) FROM all_sponsors WHERE all_sponsors.status=all_status.id and all_sponsors.event_id='".$event_id."'),0) as potential_funding_ask,
             ifnull((SELECT sum(committed_funding) FROM all_sponsors WHERE all_sponsors.status=all_status.id and all_sponsors.event_id='".$event_id."'),0) as committed_funding FROM all_status WHERE all_status.event_id = '".$event_id."' and all_status.status_for='".$val."'");

        // $fetch_all_status = mysqli_query($this->connect,"SELECT *,(SELECT count(*) FROM all_sponsors WHERE all_sponsors.status=all_status.id and all_sponsors.event_id='".$event_id."') as count_of_sponsor_usage, ifnull((SELECT sum(potential_funding_ask) FROM all_sponsors WHERE all_sponsors.status=all_status.id and all_sponsors.event_id='".$event_id."'),0) as potential_funding_ask,
        //      ifnull((SELECT sum(committed_funding) FROM all_sponsors WHERE all_sponsors.status=all_status.id and all_sponsors.event_id='".$event_id."'),0) as committed_funding FROM all_status WHERE default_flag = 1 and all_status.status_for='".$val."'
        //     union 
        //     SELECT *,(SELECT count(*) FROM all_sponsors WHERE all_sponsors.status=all_status.id and all_sponsors.event_id='".$event_id."') as count_of_sponsor_usage,
        //     ifnull((SELECT sum(potential_funding_ask) FROM all_sponsors WHERE all_sponsors.status=all_status.id and all_sponsors.event_id='".$event_id."'),0) as potential_funding_ask,
        //      ifnull((SELECT sum(committed_funding) FROM all_sponsors WHERE all_sponsors.status=all_status.id and all_sponsors.event_id='".$event_id."'),0) as committed_funding FROM all_status WHERE all_status.event_id = '".$event_id."' and all_status.status_for='".$val."'");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_status) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_status)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

     function get_count_sponsor_opportunity_type_email_count($event_id,$id)
     {
        include("include/mysqli_connect.php");
        $count = mysqli_num_rows(mysqli_query($connect,"SELECT all_email_templates.template_name,all_sponsors.sponsor_contact_email_address as sent_to,all_users.email as sent_by,all_logs.created_at as sent_on,all_logs.email_read FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value 
        LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_sponsors ON all_sponsors.id=all_logs.table_id  WHERE all_logs.operation='sent email to sponsor' 
        AND all_logs.table_id in (select id from all_sponsors where FIND_IN_SET('".$id."', sponsor_type) AND event_id='".$event_id."') AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC"));
        if(empty($count))return 0;
        else return $count;
    }

     function fetch_all_sponsor_by_opportunity_type($id,$start=1,$limit,$evt_id){

        $event_id= $evt_id;
        
        $fetch_all_speakers = mysqli_query($this->connect,"SELECT  `status`,all_sponsors.id,sponsor_type,sponsor_company_name,sponsor_contact_person,sponsor_contact_email_address,sponsor_contact_number,'AA' as template_name,mail_sent_count as count_email_sent,now() as created_at FROM all_sponsors LEFT JOIN all_status ON all_sponsors.status = all_status.id WHERE FIND_IN_SET('".$id."', sponsor_type) and all_sponsors.event_id = '".$event_id."' ORDER BY all_sponsors.id DESC LIMIT $start,$limit");

        // $fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_sponsors.id as id,(SELECT GROUP_CONCAT(d.sponsor_type_name)  FROM all_sponsor_types d WHERE find_in_set(d.id,all_sponsors.sponsor_type)) as sponsor_type_name, (select other_column_value from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, 
        //     (select created_at from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as created_at, (select count(all_logs.id) from all_logs RIGHT JOIN all_email_templates ON all_email_templates.id = all_logs.other_column_value WHERE table_id=all_sponsors.id AND operation='sent email to sponsor') as count_email_sent FROM all_sponsors LEFT JOIN all_status ON all_sponsors.status = all_status.id WHERE FIND_IN_SET('".$id."', sponsor_type) and all_sponsors.event_id = '".$event_id."' ORDER BY all_sponsors.id DESC LIMIT $start,$limit");
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function get_scheduled_last5_used_email_templates_sponsor($event_id){

        $fetch_sql = mysqli_query($this->connect,"SELECT  template_name,id,count,email_opened_data,user_scheduledtime from (
            SELECT  template_name,id,count,email_opened_data,user_scheduledtime from (SELECT distinct aet.template_name,aet.id,(select count(*) from tbl_sendlatermaildetails where aet.id = template_id AND `type` LIKE '%Sponser%' AND event_id = '".$event_id."') as count,(select count(*) from all_logs als where als.operation='sent email to sponsor scheduled' and als.event_id='".$event_id."' and als.other_column_value=aet.id and email_read='y' and als.other_column_name='template_id') as email_opened_data,user_scheduledtime FROM all_email_templates aet, tbl_sendlatermaildetails al WHERE aet.id = al.template_id AND aet.template_type LIKE '%sponsor%' AND al.`type` LIKE '%Sponser%' AND al.event_id= '".$event_id."' ORDER BY al.user_scheduledtime DESC) t1
            union 
            SELECT  template_name,id,count,email_opened_data,user_scheduledtime from (SELECT distinct 'Request missing information' as  template_name,'9998' as id,(select count(*) from tbl_sendlatermaildetails where `type`='missing-info-collect-sponsor' AND event_id ='".$event_id."') as count,(select count(*) from all_logs als 
            where als.operation='request missing information sponsor scheduled' and als.event_id='".$event_id."' and email_read='y') as email_opened_data,user_scheduledtime FROM tbl_sendlatermaildetails al WHERE al.`type`='missing-info-collect-sponsor' AND al.event_id= '".$event_id."' ORDER BY al.user_scheduledtime DESC) t2
            union
            SELECT  template_name,id,count,email_opened_data,user_scheduledtime from (SELECT distinct 'Request missing documents' as  template_name,'9999' as id,(select count(*) from tbl_sendlatermaildetails where `type`='missing-document-collect-sponsor' AND event_id ='".$event_id."') as count,(select count(*) from all_logs als where als.operation='request missing documents sponsor scheduled' and als.event_id='".$event_id."' and email_read='y') as email_opened_data,user_scheduledtime FROM tbl_sendlatermaildetails al WHERE al.`type`='missing-document-collect-sponsor' AND al.event_id= '".$event_id."' ORDER BY al.user_scheduledtime DESC) t3
            ) temp group by temp.template_name  order by temp.user_scheduledtime desc  LIMIT 5");
        // $fetch_sql = mysqli_query($this->connect,"SELECT distinct aet.template_name,aet.id,(select count(*) from tbl_sendlatermaildetails where aet.id = template_id AND `type` LIKE '%Sponser%' AND event_id = '".$event_id."') as count,(select count(*) from all_logs als where als.operation='sent email to sponsor scheduled' and als.event_id='".$event_id."' and als.other_column_value=aet.id and email_read='y' and als.other_column_name='template_id') as email_opened_data FROM all_email_templates aet, tbl_sendlatermaildetails al WHERE aet.id = al.template_id AND aet.template_type LIKE '%sponsor%' AND al.`type` LIKE '%Sponser%' AND al.event_id= '".$event_id."' ORDER BY al.user_scheduledtime DESC LIMIT 5");

        $inner_array = array();
        if(mysqli_num_rows($fetch_sql) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_sql)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }        
    }

      function get_count_sponsors_with_no_company_profile($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE (sponsor_company_name='' OR sponsor_company_name is NULL) AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

     function get_count_sponsors_with_no_logo($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"select * FROM all_sponsors WHERE (sponsor_logo='' OR sponsor_logo is NULL) AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

     function get_count_total_sponsors_potential_fund($event_id){
         $sql3 = "SELECT ifnull(sum(potential_funding_ask),0) as potential_funding_ask FROM all_sponsors WHERE all_sponsors.event_id='".$event_id."'";
        $res3=mysqli_query($this->connect, $sql3);
        while($row3 = $res3->fetch_assoc()) {
             $rescnt3=$row3["potential_funding_ask"];
         }
        return $rescnt3;
    }

     function get_count_total_sponsors_committed_fund($event_id){
        $sql4 = "SELECT ifnull(sum(committed_funding),0) as committed_funding FROM all_sponsors WHERE all_sponsors.event_id='".$event_id."'";
        $res4=mysqli_query($this->connect, $sql4);
        while($row4 = $res4->fetch_assoc()) {
             $rescnt4=$row4["committed_funding"];
         }
        return $rescnt4;
    }

      function fetch_all_sponsor_for_popup($event_id=null){
          if(!isset($_SESSION)){ session_start(); }
            $user_id = $_SESSION['user_id'];
        // $event_id= $_SESSION['current_event_id'];
         $fetch_all_resource = mysqli_query($this->connect,"select id,sponsor_company_name,sponsor_contact_person,sponsor_contact_email_address,sponsor_contact_number,(select status_name from all_status where id=all_sponsors.`status`) as status_name,(select GROUP_CONCAT(d.sponsor_type_name) as sponsor_types from all_sponsor_types d where find_in_set(d.id,all_sponsors.sponsor_type)) as sponsor_types from all_sponsors,all_users where FIND_IN_SET(all_sponsors.event_id, all_users.event_id)  AND  all_users.user_id='".$user_id."' and all_sponsors.event_id not in ('".$event_id."') and all_sponsors.sponsor_contact_email_address not in (select sponsor_contact_email_address from  all_sponsors where event_id='".$event_id."') group by all_sponsors.sponsor_contact_email_address having count(*)>0");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

        function fetch_all_ppt_for_sponsor($sp_id){
        //return $sp_id;

        $fetch_all_speaker_ppt= mysqli_query($this->connect,"SELECT * FROM sponsor_documents WHERE  doc_type = 'ppt' AND sponsor_id ='".$sp_id."' AND is_deleted = '0' ORDER BY id DESC ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_ppt) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_ppt)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_all_video_for_sponsor($sp_id){
       //  return $sp_id;

        $fetch_all_speaker_vdo = mysqli_query($this->connect,"SELECT * FROM sponsor_documents WHERE doc_type = 'video' AND sponsor_id ='".$sp_id."' AND is_deleted = '0' ORDER BY id DESC ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_vdo) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_vdo)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    } 



    function fetch_all_offers_for_sponsor($sp_id){
       //  return $sp_id;

        $fetch_all_speaker_offer = mysqli_query($this->connect,"SELECT * FROM sponsor_documents WHERE doc_type = 'offer' AND sponsor_id ='".$sp_id."' AND is_deleted = '0' ORDER BY id DESC ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_offer) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_offer)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_all_mail_logs_sponsor($sponsor_id,$limit = null){
        
                $limit_sql = "";
                
                // if($limit==5){
                if($limit > 0 && $limit != null){
                    $limit_sql = " LIMIT ".$limit;
                }
                
                $fetch_all_email_templates = mysqli_query($this->connect,"SELECT *,all_logs.id as idd FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE all_logs.operation='sent email to sponsor' AND all_logs.table_id='".$sponsor_id."' AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC ".$limit_sql);
                
                $inner_array = array();
                if(mysqli_num_rows($fetch_all_email_templates) > 0)
                {            
                    while($row = mysqli_fetch_array($fetch_all_email_templates)){
                        $inner_array[] = $row;
                    }
                    return $inner_array;            
                }
                else{
                    return $inner_array;
                }

    }

    function fetch_EP_name($id){

        $fetch_all_speakers = mysqli_query($this->connect,"select ep.*,(select group_concat(speaker_id) from event_agenda_speakers where event_agenda_speakers.ep_id='".$id."') as speaker_id  from event_presentation ep where ep.ep_id='".$id."' order by event_date desc");
                $inner_array = array();
                if(mysqli_num_rows($fetch_all_speakers) > 0)
                {            
                    while($row = mysqli_fetch_array($fetch_all_speakers)){
                        $inner_array[] = $row;
                    }
                    return $inner_array;            
                }
                else{
            return $inner_array;
        }
    }

    function fetch_all_mail_logs_EP($ep_id,$limit = null){
        
        $limit_sql = "";
        
        // if($limit==5){
        if($limit > 0 && $limit != null){
            $limit_sql = " LIMIT ".$limit;
        }
        
        $fetch_all_email_templates = mysqli_query($this->connect,"SELECT *,all_logs.id as idd FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE all_logs.operation='sent email to speaker Event Presentation' AND all_logs.event_presentation_id='".$ep_id."' AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC ".$limit_sql);
        
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_all_countries(){

        $fetch_all_countries = mysqli_query($this->connect,"SELECT * FROM countries");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_countries) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_countries)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_all_states($country_id){

        $fetch_all_states = mysqli_query($this->connect,"SELECT * FROM states WHERE country_id = '".$country_id."' ");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_states) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_states)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

     function fetch_speaker_name_for_EP($id){

         $fetch_all_resource = mysqli_query($this->connect,"select id,speaker_name,head_shot from all_speakers WHERE id='".$id."'");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function get_count_all_unique_EP($evt_id=null){
         $event_id= $evt_id;

         $fetch_all_resource = mysqli_query($this->connect,"SELECT count(*) as total_count from event_presentation  where event_id = '".$event_id."'");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

       function get_total_sponsors_potential_fund($evt_id){
         $event_id= $evt_id;
         $fetch_all_resource = mysqli_query($this->connect,"SELECT potential_funding_ask ,sponsor_company_name FROM all_sponsors WHERE all_sponsors.event_id='".$event_id."' and potential_funding_ask!=0");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

     function get_total_sponsors_committed_fund($evt_id){
         $event_id= $evt_id;
         $fetch_all_resource = mysqli_query($this->connect,"SELECT committed_funding ,sponsor_company_name FROM all_sponsors WHERE all_sponsors.event_id='".$event_id."' and committed_funding!=0");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_resource) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_resource)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    //************* 13/02/2020 ******************//

        function get_daily_email_campaign_daily_notification($event_id){

            $fetch_sql = mysqli_query($this->connect,"SELECT other_column_value,audience,template_name,template_used,email_read FROM ((SELECT other_column_value,audience,template_name,template_used,email_read FROM
            (SELECT distinct al.other_column_value,'Speaker' as audience,
            (select template_name from all_email_templates ae where ae.id=al.other_column_value AND al.other_column_name='template_id') as template_name,
            (select count(id) from all_logs ae where ae.other_column_value=al.other_column_value AND ae.other_column_name='template_id' AND ae.event_id='".$event_id."' AND date(ae.created_at)=date(now())
            AND (ae.operation='sent email to speaker' OR ae.operation='sent email to speaker scheduled' OR
            ae.operation='sent email to speaker Event Presentation' OR ae.operation='sent email to speaker Event Presentation scheduled')) as template_used,
            (select count(id) from all_logs ael where ael.other_column_value=al.other_column_value AND ael.other_column_name='template_id' AND ael.event_id='".$event_id."'  AND date(ael.created_at)=date(now())
            AND (ael.operation='sent email to speaker' OR ael.operation='sent email to speaker scheduled' OR
            ael.operation='sent email to speaker Event Presentation' OR ael.operation='sent email to speaker Event Presentation scheduled') AND ael.email_read='y') as email_read
            FROM all_logs al INNER JOIN all_email_templates aet
            ON aet.id=al.other_column_value
            WHERE al.event_id='".$event_id."' AND (al.operation='sent email to speaker' OR al.operation='sent email to speaker scheduled' OR
            al.operation='sent email to speaker Event Presentation' OR al.operation='sent email to speaker Event Presentation scheduled')  AND al.other_column_name='template_id'
            AND date(al.created_at)=date(now())  group by aet.id
            Union
            SELECT  '999999' as other_column_value,'Speaker' as audience,
            'Request Missing Information' as template_name,
            (select count(id) from all_logs ae where  ae.event_id='".$event_id."' AND date(ae.created_at)=date(now())
            AND (ae.operation='request missing information' OR ae.operation='request missing information scheduled')) as template_used,
            (select count(id) from all_logs ael where  ael.event_id='".$event_id."' AND date(ael.created_at)=date(now())
            AND (ael.operation='request missing information' OR ael.operation='request missing information scheduled') AND ael.email_read='y') as email_read
            FROM all_logs al
            WHERE al.event_id='".$event_id."' AND (al.operation='request missing information' OR al.operation='request missing information scheduled') AND date(al.created_at)=date(now())
            Union
            SELECT  '9888888' as other_column_value,'Speaker' as audience,
            'Request Missing Documents' as template_name,
            (select count(id) from all_logs ae where  ae.event_id='".$event_id."' AND date(ae.created_at)=date(now())
            AND (ae.operation='request missing documents' OR ae.operation='request missing documents scheduled')) as template_used,
            (select count(id) from all_logs ael where  ael.event_id='".$event_id."' AND date(ael.created_at)=date(now())
            AND (ael.operation='request missing documents' OR ael.operation='request missing documents scheduled') AND ael.email_read='y') as email_read
            FROM all_logs al
            WHERE al.event_id='".$event_id."' AND (al.operation='request missing documents' OR al.operation='request missing documents scheduled') AND date(al.created_at)=date(now())) temp1)
            UNION
            (SELECT other_column_value,audience,template_name,template_used,email_read FROM
            (SELECT distinct al.other_column_value,'Sponsor' as audience,
            (select template_name from all_email_templates ae where ae.id=al.other_column_value AND al.other_column_name='template_id') as template_name,
            (select count(id) from all_logs ae where ae.other_column_value=al.other_column_value AND ae.other_column_name='template_id' AND ae.event_id='".$event_id."' AND date(ae.created_at)=date(now())
            AND (ae.operation='sent email to sponsor' OR ae.operation='sent email to sponsor scheduled')) as template_used,
            (select count(id) from all_logs ael where ael.other_column_value=al.other_column_value AND ael.other_column_name='template_id' AND ael.event_id='".$event_id."'  AND date(ael.created_at)=date(now())
            AND (ael.operation='sent email to sponsor' OR ael.operation='sent email to sponsor scheduled') AND ael.email_read='y') as email_read
            FROM all_logs al INNER JOIN all_email_templates aet
            ON aet.id=al.other_column_value
            WHERE al.event_id='".$event_id."' AND (al.operation='sent email to sponsor' OR al.operation='sent email to sponsor scheduled')  AND al.other_column_name='template_id'
            AND date(al.created_at)=date(now())  group by aet.id
            Union
            SELECT  '99999999' as other_column_value,'Sponsor' as audience,
            'Request Missing Information' as template_name,
            (select count(id) from all_logs ae where  ae.event_id='".$event_id."' AND date(ae.created_at)=date(now())
            AND (ae.operation='request missing information sponsor' OR ae.operation='request missing information sponsor scheduled')) as template_used,
            (select count(id) from all_logs ael where  ael.event_id='".$event_id."' AND date(ael.created_at)=date(now())
            AND (ael.operation='request missing information sponsor' OR ael.operation='request missing information sponsor scheduled') AND ael.email_read='y') as email_read
            FROM all_logs al
            WHERE al.event_id='".$event_id."' AND (al.operation='request missing information sponsor' OR al.operation='request missing information sponsor scheduled') AND date(al.created_at)=date(now())
            Union
            SELECT  '988888899' as other_column_value,'Sponsor' as audience,
            'Request Missing Documents' as template_name,
            (select count(id) from all_logs ae where  ae.event_id='".$event_id."' AND date(ae.created_at)=date(now())
            AND (ae.operation='request missing documents sponsor' OR ae.operation='request missing documents sponsor scheduled')) as template_used,
            (select count(id) from all_logs ael where  ael.event_id='".$event_id."' AND date(ael.created_at)=date(now())
            AND (ael.operation='request missing documents sponsor' OR ael.operation='request missing documents sponsor scheduled') AND ael.email_read='y') as email_read
            FROM all_logs al
            WHERE al.event_id='".$event_id."' AND (al.operation='request missing documents sponsor' OR al.operation='request missing documents sponsor scheduled') AND date(al.created_at)=date(now())) temp3)
            UNION
            (SELECT other_column_value,audience,template_name,template_used,email_read FROM (SELECT distinct al.other_column_value,'Master' as audience,
            (select template_name from all_email_templates ae where ae.id=al.other_column_value AND al.other_column_name='template_id') as template_name,
            (select count(id) from all_logs ae where ae.other_column_value=al.other_column_value AND ae.other_column_name='template_id' AND ae.event_id='".$event_id."' AND date(ae.created_at)=date(now())
            AND (ae.operation='sent email to master' OR ae.operation='sent email to master scheduled')) as template_used,
            (select count(id) from all_logs ael where ael.other_column_value=al.other_column_value AND ael.other_column_name='template_id' AND ael.event_id='".$event_id."' AND date(ael.created_at)=date(now())
            AND (ael.operation='sent email to master' OR ael.operation='sent email to master scheduled') AND ael.email_read='y') as email_read
            FROM all_logs al INNER JOIN all_email_templates aet
            ON aet.id=al.other_column_value
            WHERE al.event_id='".$event_id."' AND (al.operation='sent email to master' OR al.operation='sent email to master scheduled')  AND al.other_column_name='template_id'
            AND date(al.created_at)=date(now())  group by aet.id) temp2)) temp4 ");    

                $inner_array = array();
                if(mysqli_num_rows($fetch_sql) > 0)
                {            
                    while($row = mysqli_fetch_array($fetch_sql)){
                        $inner_array[] = $row;
                    }
                    return $inner_array;            
                }
                else{
                    return $inner_array;
                }

        }






    // ***************************************************************

   function get_count_all_total_speakers_daily_notification($event_id){
        $fetch_sql = mysqli_query($this->connect,"SELECT id from all_speakers WHERE email_id != '' AND event_id = '".$event_id."' ");           
         return mysqli_num_rows($fetch_sql);
    }

    function get_newly_added_speakers_daily_notification($event_id){         
         $fetch_all_added_spk_today =  mysqli_num_rows( mysqli_query($this->connect,"SELECT id from all_crud_logs WHERE (operation = 'create speaker' OR operation='create speaker from popup' OR operation='create speaker from external form') AND  event_id = '".$event_id."' AND date(created_at) = date(now()) ") ); 
         return $fetch_all_added_spk_today;        
    }

    function get_newly_deleted_speakers_daily_notification($event_id){ 
         
         $fetch_all_deleted_spk_today =  mysqli_num_rows( mysqli_query($this->connect,"SELECT id from all_crud_logs WHERE operation = 'delete speaker' AND  event_id = '".$event_id."' AND date(created_at) = date(now()) ") ); 
         return $fetch_all_deleted_spk_today;
    }

   function get_count_all_total_sponsors_daily_notification($event_id){
        $fetch_sql = mysqli_query($this->connect,"SELECT id from all_sponsors WHERE sponsor_contact_email_address != '' AND event_id = '".$event_id."' ");           
         return mysqli_num_rows($fetch_sql);
    }  




     function get_newly_added_sponsors_daily_notification($event_id){
            $fetch_all_added_spk_today =  mysqli_num_rows( mysqli_query($this->connect,"SELECT id from all_crud_logs WHERE (operation = 'create sponsor' OR operation='create sponsor from popup') AND  event_id = '".$event_id."' AND date(created_at) = date(now()) ") ); 
            return $fetch_all_added_spk_today; 
        }


        function get_newly_deleted_sponsors_daily_notification($event_id){
            $fetch_all_deleted_spk_today =  mysqli_num_rows( mysqli_query($this->connect,"SELECT id from all_crud_logs WHERE operation = 'delete sponsor' AND  event_id = '".$event_id."' AND date(created_at) = date(now()) ") ); 
         return $fetch_all_deleted_spk_today;            
        }
        


  function get_count_all_total_masters_daily_notification($event_id){
        $fetch_sql = mysqli_query($this->connect,"SELECT id from all_masters WHERE email_id != '' AND event_id ='".$event_id."' ");           
         return mysqli_num_rows($fetch_sql);

    }    
    function get_newly_added_masters_daily_notification($event_id){
        $fetch_sql =  mysqli_num_rows( mysqli_query($this->connect,"SELECT id from all_crud_logs WHERE (operation = 'create master' OR operation='create master from popup' OR operation='create master from signup') AND  event_id = '".$event_id."' AND date(created_at) = date(now()) ") ); 
         return $fetch_sql;  
        
    }

    function get_newly_deleted_masters_daily_notification($event_id){
            $fetch_sql =  mysqli_num_rows( mysqli_query($this->connect,"SELECT id from all_crud_logs WHERE operation = 'delete master' AND  event_id = '".$event_id."' AND date(created_at) = date(now()) ") ); 
         return $fetch_sql;          
    }

    function get_count_all_total_mail_sent($event_id){
        $fetch_sql = mysqli_query($this->connect,"SELECT id from all_logs WHERE operation IN('sent email to speaker','sent email to speaker scheduled','sent email to master','sent email to master scheduled','sent email to sponsor','sent email to sponsor scheduled','request missing information','request missing documents','request missing information sponsor','request missing documents sponsor','request missing information scheduled','request missing documents scheduled','request missing information sponsor scheduled','request missing documents sponsor scheduled')  AND event_id ='".$event_id."' ");        
         return mysqli_num_rows($fetch_sql);
    } 

    function get_count_today_mail_sent($event_id){
        $fetch_sql = mysqli_query($this->connect,"SELECT id from all_logs WHERE operation IN('sent email to speaker','sent email to speaker scheduled','sent email to master','sent email to master scheduled','sent email to sponsor','sent email to sponsor scheduled','request missing information','request missing documents','request missing information sponsor','request missing documents sponsor','request missing information scheduled','request missing documents scheduled','request missing information sponsor scheduled','request missing documents sponsor scheduled')  AND event_id ='".$event_id."' AND date(created_at) = DATE(now()) ");        
         return mysqli_num_rows($fetch_sql);
    }




    function get_action_of_the_day($event_id){

        $fetch_sql = mysqli_query($this->connect,"SELECT *,(select action_type_name from all_action_types where id = action_trackers.action_category ) as action_category_name
             from action_trackers where date(deadline) = date(now() ) and event_id = '".$event_id."' ");    

                $inner_array = array();
                if(mysqli_num_rows($fetch_sql) > 0)
                {            
                    while($row = mysqli_fetch_array($fetch_sql)){
                        $inner_array[] = $row;
                    }
                    return $inner_array;            
                }
                else{
                    return $inner_array;
                }
    }
    
    function get_all_resource_added_today_daily_notification($event_id){
        $fetch_sql = mysqli_query($this->connect,"SELECT rt.*, (select art.resource_type_name from all_resource_types art where art.id= rt.resource_category) as category_name,
            (select au.first_name from all_users au where au.user_id = rt.created_by ) as created_by_name from resource_trackers rt where rt.event_id = '".$event_id."' AND 
                date(rt.created_at) >= date(now()) ");    

                $inner_array = array();
                if(mysqli_num_rows($fetch_sql) > 0)
                {            
                    while($row = mysqli_fetch_array($fetch_sql)){
                        $inner_array[] = $row;
                    }
                    return $inner_array;            
                }
                else{
                    return $inner_array;
                }

        }


   function get_total_count_speakers_with_no_mobile($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_speakers WHERE phone='' AND event_id != '' AND  event_id is not null AND  event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

    function get_total_percentage_speakers_with_no_mobile($event_id){
        $count_without_mobile = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_speakers WHERE phone='' AND event_id = '".$event_id."' "));
        
         $total_speaker = $this->get_count_all_total_speakers_daily_notification($event_id);         
         return round($count_without_mobile / ($total_speaker/100 ),2);      
    }

    function get_total_count_speakers_with_no_linked_handles($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_speakers WHERE linkedin_url='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

    function get_total_percentage_speakers_with_no_linked_handles($event_id){
        $count_without_linkedin_url = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_speakers WHERE linkedin_url='' AND event_id = '".$event_id."' "));
         $total_speaker = $this->get_count_all_total_speakers_daily_notification($event_id);   
        return round($count_without_linkedin_url / ($total_speaker/100 ),2);
    }

    function get_total_count_speakers_with_no_bio($event_id){
         $count = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_speakers WHERE (short_bio='' OR short_bio = NULL )  AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;

    }
    function get_total_percentage_speakers_with_no_bio($event_id){
        $count_without_bio = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_speakers WHERE (short_bio='' OR short_bio = NULL )  AND event_id = '".$event_id."' "));
         $total_speaker = $this->get_count_all_total_speakers_daily_notification($event_id);   
        return round($count_without_bio / ($total_speaker/100 ),2);

    }

    function get_total_count_speakers_with_no_headshot($event_id){
         $count = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_speakers WHERE (head_shot='' OR head_shot = NULL )  AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;

    }
    function get_total_percentage_speakers_with_no_headshot($event_id){
        $count_without_bio = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_speakers WHERE (head_shot='' OR head_shot = NULL )  AND event_id = '".$event_id."' "));
         $total_speaker = $this->get_count_all_total_speakers_daily_notification($event_id);   
        return round($count_without_bio / ($total_speaker/100 ),2);

    }

    


     function get_total_count_sponsors_with_no_logo($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_sponsors WHERE sponsor_logo=''  AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

    function get_total_percentage_sponsors_with_no_logo_handles($event_id){
        $count_without_logo = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_sponsors WHERE sponsor_logo=''  AND event_id = '".$event_id."' "));
         $total_sponsor = $this->get_count_all_total_sponsors_daily_notification($event_id);
         return round($count_without_logo / ($total_sponsor/100 ),2);
    }

    function get_total_count_sponsors_with_no_contact($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_sponsors WHERE sponsor_contact_number='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

    function get_total_percentage_sponsors_with_no_contact($event_id){
        $count_without_contact = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_sponsors WHERE sponsor_contact_number='' AND event_id = '".$event_id."' "));
        $total_sponsor = $this->get_count_all_total_sponsors_daily_notification($event_id);
         return round($count_without_contact / ($total_sponsor/100 ),2);
    }

    function get_total_count_masters_with_no_company($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_masters WHERE company='' AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

    function get_total_percentage_master_with_no_company($event_id){
        $count_without_company = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_masters WHERE company='' AND event_id = '".$event_id."' "));
         $total_master = $this->get_count_all_total_masters_daily_notification($event_id);
         return round($count_without_company / ($total_master/100 ),2);       
    }

     function get_total_count_masters_with_no_linked_handles($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_masters WHERE (linkedin_url='https://www.linkedin.com/' OR linkedin_url='' )   AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

    function get_total_percentage_master_with_no_linked_handles($event_id){
        $count_without_linkedin = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_masters WHERE (linkedin_url='https://www.linkedin.com/' OR linkedin_url='' )   AND event_id = '".$event_id."' "));

         $total_master = $this->get_count_all_total_masters_daily_notification($event_id);
         return round($count_without_linkedin / ($total_master/100 ),2);        
    }

    function get_total_count_masters_with_no_phone($event_id){
        $count = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_masters WHERE (phone='' OR phone= NULL )   AND event_id = '".$event_id."' "));
        if(empty($count))return 0;
        else return $count;
    }

    function get_total_percentage_master_with_no_phone($event_id){
        $count_without_linkedin = mysqli_num_rows(mysqli_query($this->connect,"SELECT * FROM all_masters WHERE (phone='' OR phone= NULL )   AND event_id = '".$event_id."' "));

         $total_master = $this->get_count_all_total_masters_daily_notification($event_id);
         return round($count_without_linkedin / ($total_master/100 ),2);        
    }

       function normal_search_master($searchtext=null,$evt_id){
         $event_id= $evt_id;

          $fetch_all_masters = mysqli_query($this->connect,"SELECT am.id,am.company,am.master_type,am.master_name,am.email_id,am.phone,am.job_title,'0' as template_id,mail_sent_count as total_email_sent, 'AA' as template_name FROM all_masters am WHERE event_id = '".$event_id."' AND is_approved = '1' AND (am.master_name like '%$searchtext%' OR am.email_id like '%$searchtext%' OR am.company like '%$searchtext%' OR am.phone like '%$searchtext%' OR am.job_title like '%$searchtext%') ORDER BY am.id DESC");

        // $fetch_all_masters = mysqli_query($this->connect,"SELECT am.id,am.company,am.master_type,am.master_name,am.email_id,am.phone,am.job_title,(select other_column_value from all_logs WHERE table_id=am.id AND (operation='sent email to master' OR operation='sent email to master scheduled') ORDER BY id DESC LIMIT 1) as template_id,(select count(id)  from all_logs WHERE table_id=am.id AND (operation='sent email to master' OR operation='sent email to master scheduled') AND event_id = '".$event_id."' ) as total_email_sent, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name FROM all_masters am WHERE event_id = '".$event_id."' AND is_approved = '1' AND (am.master_name like '%$searchtext%' OR am.email_id like '%$searchtext%' OR am.company like '%$searchtext%' OR am.phone like '%$searchtext%' OR am.job_title like '%$searchtext%') ORDER BY am.id DESC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function normal_search_new_master($searchtext=null,$evt_id){
        $event_id= $evt_id;

        $fetch_all_masters = mysqli_query($this->connect,"SELECT am.id,am.company,am.master_type,am.master_name,am.email_id,am.phone,am.job_title,'0' as template_id,mail_sent_count as total_email_sent, 'AA' as template_name FROM all_masters am WHERE event_id = '".$event_id."' AND is_approved != '1' AND (am.master_name like '%$searchtext%' OR am.email_id like '%$searchtext%' OR am.company like '%$searchtext%' OR am.phone like '%$searchtext%' OR am.job_title like '%$searchtext%') ORDER BY am.id DESC");

        // $fetch_all_masters = mysqli_query($this->connect,"SELECT am.id,am.company,am.master_type,am.master_name,am.email_id,am.phone,am.job_title,(select other_column_value from all_logs WHERE table_id=am.id AND (operation='sent email to master' OR operation='sent email to master scheduled') ORDER BY id DESC LIMIT 1) as template_id,(select count(id)  from all_logs WHERE table_id=am.id AND (operation='sent email to master' OR operation='sent email to master scheduled') AND event_id = '".$event_id."' ) as total_email_sent, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name FROM all_masters am WHERE event_id = '".$event_id."' AND is_approved != '1' AND (am.master_name like '%$searchtext%' OR am.email_id like '%$searchtext%' OR am.company like '%$searchtext%' OR am.phone like '%$searchtext%' OR am.job_title like '%$searchtext%') ORDER BY am.id DESC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

     function get_eventid($eid=null)
    {
        $event_id_enc = trim($eid);
        $event_id_exp = explode(':',$event_id_enc);
        $event_id_dec = base64_decode($event_id_exp[0]);
        return $event_id_dec;
    }

    function check_event_id($event_id_res=null){

        if(isset($event_id_res) && $event_id_res !='' ){
            $fetch_sql = mysqli_query($this->connect,"SELECT id from all_events where id='".$event_id_res."' "); 
            if(mysqli_num_rows($fetch_sql) > 0){
                return $event_id_res;  
            }else{
                header("location:logout.php");
            }               
        }else{
              header("location:logout.php");
        }
    }

    function get_tenant_id_from_eventid($event_id=null){   
           
        $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
        $res_sql = mysqli_fetch_array($fetch_sql);
         return $res_sql['tanent_id'];       
    }

    function get_tenant_id_from_userid($user_id=null){

        $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");   
        $res_sql = mysqli_fetch_array($fetch_sql);
         return $res_sql['tanent_id'];       
    }
    
    function get_user_with_email($email=null){

        $fetch_sql = mysqli_query($this->connect,"SELECT * from all_users as au LEFT JOIN all_tenants as at on at.id = au.tanent_id where au.email='".$email."' ");   
        $res_sql = mysqli_fetch_array($fetch_sql);
         return $res_sql;       
    }

    function add_customer_id($customer_id, $email, $tanent_id)
    {
        // mysqli_query($this->connect, "UPDATE all_users SET `customer_id` = '".$customer_id."' WHERE email = '".$email."'");
          mysqli_query($this->connect, "UPDATE all_users SET `customer_id` = '".$customer_id."' WHERE tanent_id = '".$tanent_id."'");
    }

    function update_tenant_subscription_status($user_id){
        $update_tenant_subscription_status = mysqli_query($this->connect, "UPDATE all_tenants SET `status` = 'active' WHERE id = (SELECT tanent_id FROM all_users WHERE user_id = '".$user_id."') ");
    }



     function fetch_all_email_templates_master_asc_new($evt_id){
        $event_id = $evt_id;
    
        // $fetch_all_email_templates = mysqli_query($this->connect,"SELECT * FROM (select id,template_name from all_email_templates where (event_id='all' OR event_id='".$event_id."') AND all_email_templates.template_type LIKE '%master%' order by updated_date desc) AS t GROUP BY template_name having count(*)>0");

        $fetch_all_email_templates = mysqli_query($this->connect,"SELECT * FROM (select aet.id,aet.template_name
            from all_email_templates aet left outer join all_email_template_usage_info aui ON aet.id=aui.template_id where
            (aet.event_id='all' OR aet.event_id='".$evt_id."') AND aet.template_type
            LIKE '%master%' AND  aet.id not in(select aetu.template_id from all_email_template_usage_info aetu 
            where aetu.event_id='".$evt_id."' and aetu.is_delete=1) order by updated_date desc) AS t GROUP BY template_name having count(*)>0");
        
        $inner_array = array();
        
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

     function fetch_all_email_templates_speaker_asc_new($evt_id=null){

        $event_id= $evt_id;

        $fetch_all_email_templates = mysqli_query($this->connect,"SELECT * FROM (select aet.id,aet.template_name
            from all_email_templates aet left outer join all_email_template_usage_info aui ON aet.id=aui.template_id where
            (aet.event_id='all' OR aet.event_id='".$evt_id."') AND aet.template_type
            LIKE '%speaker%' AND  aet.id not in(select aetu.template_id from all_email_template_usage_info aetu 
            where aetu.event_id='".$evt_id."' and aetu.is_delete=1) order by updated_date desc) AS t GROUP BY template_name having count(*)>0");

        // $fetch_all_email_templates = mysqli_query($this->connect,"SELECT * FROM (select id,template_name from all_email_templates where (event_id='all' OR event_id='".$event_id."') AND all_email_templates.template_type LIKE '%speaker%' order by updated_date desc) AS t GROUP BY template_name having count(*)>0");
        $inner_array = array();
        
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

        function fetch_all_email_templates_sponsor_asc_new($evt_id){
        
        $event_id= $evt_id;

        $fetch_all_email_templates = mysqli_query($this->connect,"SELECT * FROM (select aet.id,aet.template_name
            from all_email_templates aet left outer join all_email_template_usage_info aui ON aet.id=aui.template_id where
            (aet.event_id='all' OR aet.event_id='".$evt_id."') AND aet.template_type
            LIKE '%sponsor%' AND  aet.id not in(select aetu.template_id from all_email_template_usage_info aetu 
            where aetu.event_id='".$evt_id."' and aetu.is_delete=1) order by updated_date desc) AS t GROUP BY template_name having count(*)>0");

         // $fetch_all_email_templates = mysqli_query($this->connect,"SELECT * FROM (select id,template_name from all_email_templates where (event_id='all' OR event_id='".$event_id."') AND all_email_templates.template_type LIKE '%sponsor%' order by updated_date desc) AS t GROUP BY template_name having count(*)>0");
        $inner_array = array();
        
        if(mysqli_num_rows($fetch_all_email_templates) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_email_templates)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function fetch_all_login_history(){

       if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $fetch_sql = mysqli_query($this->connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");   
         $res_sql = mysqli_fetch_array($fetch_sql);
         $tanent_id= $res_sql['tanent_id'];

        $fetch_all_masters = mysqli_query($this->connect,"SELECT * FROM all_login_logs where tanent_id='".$tanent_id."' order by id desc limit 25");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

    function get_speaker_info_missing_value_temp($id=null)
    {
         $a= $this->get_personal_info_cal_temp($id);
        $b= $this->get_headshot_info_cal_temp($id);
        $c= $this->get_socialmedia_info_cal_temp($id);
        $total_missing=$a+$b+$c;
        $final_shorten=100-$total_missing;
        return round($final_shorten);
    }

   function get_personal_info_cal_temp($id)
    {
        $v1=0;
        $v2=0;
        $v3=0;
        $v4=0;
        $v5=0;

        $sql1 = "select speaker_name from all_speakers_upload_temp where id='".$id."'";
        $res1=mysqli_query($this->connect, $sql1);
        while($row1 = $res1->fetch_assoc()) {
             $rescnt1=$row1["speaker_name"];
         }

         if($rescnt1=='' or $rescnt1 == null or $rescnt1 == 'null')
         {
            $v1=8;
         }

         $sql2 = "select email_id from all_speakers_upload_temp where id='".$id."'";
        $res2=mysqli_query($this->connect, $sql2);
        while($row2 = $res2->fetch_assoc()) {
             $rescnt2=$row2["email_id"];
         }

         if($rescnt2=='' or $rescnt2 == null or $rescnt2 == 'null')
         {
            $v2=8;
         }

         $sql3 = "select phone from all_speakers_upload_temp where id='".$id."'";
        $res3=mysqli_query($this->connect, $sql3);
        while($row3 = $res3->fetch_assoc()) {
             $rescnt3=$row3["phone"];
         }

         if($rescnt3=='' or $rescnt3 == null or $rescnt3 == 'null')
         {
            $v3=8;
         }

         $sql4 = "select company from all_speakers_upload_temp where id='".$id."' ";
        $res4=mysqli_query($this->connect, $sql4);
        while($row4 = $res4->fetch_assoc()) {
             $rescnt4=$row4["company"];
         }

         if($rescnt4=='' or $rescnt4 == null or $rescnt4 == 'null')
         {
            $v4=8;
         }

         $sql5 = "select title from all_speakers_upload_temp where id='".$id."'";
        $res5=mysqli_query($this->connect, $sql5);
        while($row5 = $res5->fetch_assoc()) {
             $rescnt5=$row5["title"];
         }

         if($rescnt5=='' or $rescnt5 == null or $rescnt5 == 'null')
         {
            $v5=8;
         }

         $total_missing_personal_info=$v1+$v2+$v3+$v4+$v5;
         return $total_missing_personal_info;

    }

    function get_headshot_info_cal_temp($id)
    {
        $v1=0;
        $v2=0;
        $v3=0;

        $sql1 = "select head_shot from all_speakers_upload_temp where id='".$id."'";
        $res1=mysqli_query($this->connect, $sql1);
        while($row1 = $res1->fetch_assoc()) {
             $rescnt1=$row1["head_shot"];
         }

         if($rescnt1=='' or $rescnt1 == null or $rescnt1 == 'null')
         {
            $v1=13.33;
         }

         $sql2 = "select your_quote from all_speakers_upload_temp where id='".$id."'";
        $res2=mysqli_query($this->connect, $sql2);
        while($row2 = $res2->fetch_assoc()) {
             $rescnt2=$row2["your_quote"];
         }

         if($rescnt2=='' or $rescnt2 == null or $rescnt2 == 'null')
         {
            $v2=13.33;
         }

         $sql3 = "select short_bio from all_speakers_upload_temp where id='".$id."'";
        $res3=mysqli_query($this->connect, $sql3);
        while($row3 = $res3->fetch_assoc()) {
             $rescnt3=$row3["short_bio"];
         }

         if($rescnt3=='' or $rescnt3 == null or $rescnt3 == 'null')
         {
            $v3=13.33;
         }


         $headshot_info=$v1+$v2+$v3;
         return $headshot_info;  
    }

    function get_socialmedia_info_cal_temp($id)
    { 
        $v1=0;
        $v2=0;

        $sql1 = "select linkedin_handle from all_speakers_upload_temp where id='".$id."'";
        $res1=mysqli_query($this->connect, $sql1);
        while($row1 = $res1->fetch_assoc()) {
             $rescnt1=$row1["linkedin_handle"];
         }

         if($rescnt1=='' or $rescnt1 == null or $rescnt1 == 'null')
         {
            $v1=10;
         }

         $sql2 = "select linkedin_url from all_speakers_upload_temp where id='".$id."'";
        $res2=mysqli_query($this->connect, $sql2);
        while($row2 = $res2->fetch_assoc()) {
             $rescnt2=$row2["linkedin_url"];
         }

         if($rescnt2=='' or $rescnt2 == null or $rescnt2 == 'null')
         {
            $v2=10;
         } 

        $socialmedia_info=$v1+$v2;
      return $socialmedia_info;
    }

 function fetch_all_speakers_asc_new($evt_id=null){
        
          $event_id= $evt_id;

          $fetch_all_speakers = mysqli_query($this->connect,"SELECT id,speaker_name FROM all_speakers WHERE  all_speakers.event_id = '".$event_id."'  ORDER BY all_speakers.speaker_name ASC");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

     function normal_search_speaker($searchtext=null,$evt_id){
         $event_id= $evt_id;

        // $fetch_all_speakers = mysqli_query($this->connect,"SELECT all_status.status_name,company,phone,speaker_type,profile_completeness,speaker_name,email_id,social_media_total_score,all_status.id as status_id,all_speakers.id as id,0 as log_id,(select created_at from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as created_at,'AA' as template_name,(select other_column_value from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as template_id,(select count(*) from all_logs  WHERE table_id=all_speakers.id AND (operation='sent email to speaker' OR operation='sent email to speaker scheduled' OR all_logs.operation='request missing information' OR all_logs.operation='request missing documents' OR all_logs.operation='request missing information scheduled' OR all_logs.operation='request missing documents scheduled')) as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.status != '' and all_speakers.event_id = '".$event_id."'  AND (all_speakers.speaker_name like '%$searchtext%' OR all_speakers.email_id like '%$searchtext%' OR all_speakers.phone like '%$searchtext%' OR all_speakers.company like '%$searchtext%') ORDER BY all_speakers.id DESC");

         $fetch_all_speakers = mysqli_query($this->connect,"SELECT all_status.status_name,company,phone,speaker_type,profile_completeness,speaker_name,email_id,social_media_total_score,all_status.id as status_id,all_speakers.id as id,0 as log_id,now() as created_at,'AA' as template_name,0 as template_id,mail_sent_count as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.status != '' and all_speakers.event_id = '".$event_id."'  AND (all_speakers.speaker_name like '%$searchtext%' OR all_speakers.email_id like '%$searchtext%' OR all_speakers.phone like '%$searchtext%' OR all_speakers.company like '%$searchtext%') ORDER BY all_speakers.id DESC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function normal_search_speaker_new($searchtext=null,$evt_id){
         $event_id= $evt_id;

          $fetch_all_speakers = mysqli_query($this->connect,"SELECT all_status.status_name,company,phone,speaker_type,profile_completeness,speaker_name,email_id,social_media_total_score,all_status.id as status_id,all_speakers.id as id,0 as log_id,now() as created_at,'AA' as template_name,0 as template_id,mail_sent_count as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.status = ' ' and all_speakers.event_id = '".$event_id."'  AND (all_speakers.speaker_name like '%$searchtext%' OR all_speakers.email_id like '%$searchtext%' OR all_speakers.phone like '%$searchtext%' OR all_speakers.company like '%$searchtext%') ORDER BY all_speakers.id DESC");

        // $fetch_all_speakers = mysqli_query($this->connect,"SELECT all_status.status_name,company,phone,speaker_type,profile_completeness,speaker_name,email_id,social_media_total_score,all_status.id as status_id,all_speakers.id as id,0 as log_id,(select created_at from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as created_at,'AA' as template_name,(select other_column_value from all_logs WHERE table_id=all_speakers.id AND operation='sent email to speaker' ORDER BY id DESC LIMIT 1) as template_id,(select count(*) from all_logs  WHERE table_id=all_speakers.id AND (operation='sent email to speaker' OR operation='sent email to speaker scheduled' OR all_logs.operation='request missing information' OR all_logs.operation='request missing documents' OR all_logs.operation='request missing information scheduled' OR all_logs.operation='request missing documents scheduled')) as count_email_sent  FROM all_speakers LEFT JOIN all_status ON all_speakers.status = all_status.id WHERE all_speakers.status = ' ' and all_speakers.event_id = '".$event_id."'  AND (all_speakers.speaker_name like '%$searchtext%' OR all_speakers.email_id like '%$searchtext%' OR all_speakers.phone like '%$searchtext%' OR all_speakers.company like '%$searchtext%') ORDER BY all_speakers.id DESC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

         function normal_search_sponsor($searchtext=null,$evt_id){
         $event_id= $evt_id;

         $fetch_all_speakers = mysqli_query($this->connect,"SELECT  `status`,all_sponsors.id,sponsor_type,sponsor_company_name,sponsor_contact_person,sponsor_contact_email_address,sponsor_contact_number,'AA' as template_name,mail_sent_count as count_email_sent,now() as created_at FROM all_sponsors WHERE all_sponsors.event_id = '".$event_id."' AND (all_sponsors.sponsor_company_name like '%$searchtext%' OR all_sponsors.sponsor_contact_person like '%$searchtext%' OR all_sponsors.sponsor_contact_email_address like '%$searchtext%' OR all_sponsors.sponsor_contact_number like '%$searchtext%') ORDER BY all_sponsors.id DESC");

        // $fetch_all_speakers = mysqli_query($this->connect,"SELECT *,all_sponsors.id as id,(SELECT GROUP_CONCAT(d.sponsor_type_name)  FROM all_sponsor_types d WHERE find_in_set(d.id,all_sponsors.sponsor_type)) as sponsor_type_name, (select other_column_value from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as template_id,(select id from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as log_id, (select template_name from all_email_templates WHERE id=template_id ORDER BY id DESC LIMIT 1) as template_name, (select created_at from all_logs WHERE table_id=all_sponsors.id AND operation='sent email to sponsor' ORDER BY id DESC LIMIT 1) as created_at, (select count(all_logs.id) from all_logs WHERE table_id=all_sponsors.id AND (operation='sent email to sponsor' or operation='sent email to sponsor scheduled' or operation='request missing information sponsor' or operation='request missing documents sponsor' OR operation='request missing information sponsor scheduled' or operation='request missing documents sponsor scheduled') and all_logs.event_id='".$event_id."') as count_email_sent  FROM all_sponsors WHERE all_sponsors.event_id = '".$event_id."' AND (all_sponsors.sponsor_company_name like '%$searchtext%' OR all_sponsors.sponsor_contact_person like '%$searchtext%' OR all_sponsors.sponsor_contact_email_address like '%$searchtext%' OR all_sponsors.sponsor_contact_number like '%$searchtext%') ORDER BY all_sponsors.id DESC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speakers) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speakers)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        } 
        else{
            return $inner_array;
        }
    }

     function total_contact_checker($eid=null)
    {
         if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $fetch_sql = mysqli_query($this->connect,"SELECT * from all_users where user_id='".$user_id."' ");   
         $res_sql = mysqli_fetch_array($fetch_sql);
         $session_tanent_id= $res_sql['tanent_id'];
         $subscription_id = $res_sql['subscription_id'];

        $total_contact = $this->get_total_contacts_count_by_tenantid($session_tanent_id);

        //.......................
           $check_tenant_subs = mysqli_query($this->connect,"SELECT * FROM `all_tenants` WHERE `id` = '".$session_tanent_id."' ");
            $res_ten = mysqli_fetch_array($check_tenant_subs);
            $tenant_created_at = date('Y-m-d',strtotime($res_ten['created_at']));
            $now = time(); // or your date as well
            $your_date = strtotime($tenant_created_at);
            $datediff = $now - $your_date;
            $final_date= round($datediff / (60 * 60 * 24));
            
            if($final_date < 100){   
                if($subscription_id != ''){

                    $subs_details = $this->subscription_retrive_by_subscription_id_new($subscription_id);
                    $plan_id_fetched = $subs_details['subscription']->planId;
                    $fetch_contact_limit = mysqli_query($this->connect,"SELECT * FROM subscription_plans_details WHERE plan_id = '".$plan_id_fetched."' ");
                    $res_contact_limit = mysqli_fetch_array($fetch_contact_limit);
                    $contact_limit = $res_contact_limit['contact_limit'];

                }else{

                    //if not subscribed any plan and tenant in trial period
                    $fetch_contact_limit = mysqli_query($this->connect,"SELECT * FROM subscription_plans_details WHERE plan_id = 'essential' ");
                    $res_contact_limit = mysqli_fetch_array($fetch_contact_limit);
                    $contact_limit = $res_contact_limit['contact_limit'];

                }             

            }else{
                    $subs_details = $this->subscription_retrive_by_subscription_id_new($subscription_id);
                    $plan_id_fetched = $subs_details['subscription']->planId;
                    $fetch_contact_limit = mysqli_query($this->connect,"SELECT * FROM subscription_plans_details WHERE plan_id = '".$plan_id_fetched."' ");
                    $res_contact_limit = mysqli_fetch_array($fetch_contact_limit);
                    $contact_limit = $res_contact_limit['contact_limit'];
            }  

            //var_dump($total_contact ." || ".$contact_limit ); exit();    

        if($total_contact>=$contact_limit)
        {
            $total_contact_flag=1;
        }else
        {
             $total_contact_flag=0;
        }

        return  $total_contact_flag;
    }

    function get_total_storage_count($tenant_id=null)
    {
         /*if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $total_storage = 0;
         $fetch_sql = mysqli_query($this->connect,"SELECT * from all_users where user_id='".$user_id."' ");   
         $res_sql = mysqli_fetch_array($fetch_sql);
         $session_tanent_id= $res_sql['tanent_id'];
         $subscription_id = $res_sql['subscription_id'];
        */
        
        $fetch_total_storage = mysqli_query($this->connect,"SELECT * FROM all_total_storage WHERE tanent_id = '".$tenant_id."' ");
        if(mysqli_num_rows($fetch_total_storage) > 0){        
            $res_storage = mysqli_fetch_array($fetch_total_storage);
            $t_storage = $res_storage['speaker_storage']+$res_storage['sponsor_storage']+$res_storage['action_tracker_storage']+$res_storage['resource_tracker_storage']+$res_storage['profile_storage'];
            $total_storage = round($t_storage/ 1024, 2);
 
        }else{
            $total_storage = 0;
        }

        return  $total_storage;
    }

    function check_sendgrid_status($usr_nm=null, $passwd=null){
        
        $url = 'https://api.sendgrid.com/';
         // $user = 'AnweshanVerb';
         // $pass = 'verbinden@2019';

        $request =  $url.'api/profile.get.json?api_user='.trim($usr_nm).'&api_key='.trim($passwd);

        // Generate curl request
        $session = curl_init($request);
        // Tell curl to use HTTP POST
        //curl_setopt ($session, CURLOPT_POST, true);
        // Tell curl that this is the body of the POST
        //curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
        // Tell curl not to return headers, but do return the response
        curl_setopt($session, CURLOPT_HEADER, false);
        // Tell PHP not to use SSLv3 (instead opting for TLS)
        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

        // obtain response
        $response = curl_exec($session);
        curl_close($session);
        return $response;

        // print everything out
        //print_r($response);exit;
    }

    /*function calculate_master_dashboard_count($event_id){
           include("mysqli_connect.php");
           
           $master_counts_sp = "call Calculate_master_dashboard_count($event_id)";
           $call_sp = mysqli_query($connect,$master_counts_sp);
           $inner_array2 = array();
           if(mysqli_num_rows($call_sp) > 0)
           {            
               while($row2 = mysqli_fetch_array($call_sp)){
                   $inner_array2[] = $row2;
               }
               return $inner_array2;            
           }
           else{
               return $inner_array2;
           }
       }*/

    function calculate_speaker_status_count($evt_id=null){
        $event_id= $evt_id;

        $speakers_data1 = mysqli_query($this->connect,"SELECT group_concat(id) as status_id FROM all_status WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($speakers_data1) > 0)
            {  
                $res1 = mysqli_fetch_array($speakers_data1);
                $row_id = $res1['status_id'];
                $status_ids_array1 = explode(",",$row_id);

                foreach ($status_ids_array1 as $statusid) { 
                if($statusid!=0)
                {

                    $query_sql_sp = mysqli_query($this->connect,"SELECT count(*) as count_spk FROM all_speakers WHERE all_speakers.status='".$statusid."' and all_speakers.event_id='".$event_id."'");
                    $query_res_sp = mysqli_fetch_array($query_sql_sp);
                    $count_spk_res = mysqli_real_escape_string($this->connect,$query_res_sp['count_spk']);
                
                    $update_status_details = mysqli_query($this->connect, "UPDATE `all_status` SET `count_of_speaker_usage`='".$count_spk_res."'   WHERE id=".$statusid);

                }

             }
           }

            if($update_status_details){
                echo 'success';
            }else{
                echo 'failed';
            }

    }

    function calculate_speaker_type_count($evt_id=null){
        $event_id= $evt_id;

        $speakers_data1 = mysqli_query($this->connect,"SELECT group_concat(id) as type_id FROM all_speaker_types WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($speakers_data1) > 0)
            {  
                $res1 = mysqli_fetch_array($speakers_data1);
                $row_id = $res1['type_id'];
                $status_ids_array1 = explode(",",$row_id);

                foreach ($status_ids_array1 as $typeid) { 
                if($typeid!=0)
                {

                    $query_sql_sp = mysqli_query($this->connect,"SELECT count(*) as count_spk FROM all_speakers WHERE find_in_set('".$typeid."',all_speakers.speaker_type) and all_speakers.event_id='".$event_id."'");
                    $query_res_sp = mysqli_fetch_array($query_sql_sp);
                    $count_spk_res = mysqli_real_escape_string($this->connect,$query_res_sp['count_spk']);

                    $query_sql_sp2 = mysqli_query($this->connect,"SELECT count(*) as count_email FROM all_logs WHERE (all_logs.operation='sent email to speaker' OR all_logs.operation='sent email to speaker scheduled') AND all_logs.table_id in (select id from all_speakers where FIND_IN_SET('".$typeid."', speaker_type) AND event_id='".$event_id."')");
                    $query_res_sp2 = mysqli_fetch_array($query_sql_sp2);
                    $count_spk_res2 = mysqli_real_escape_string($this->connect,$query_res_sp2['count_email']);
                
                    $update_status_details = mysqli_query($this->connect, "UPDATE `all_speaker_types` SET `count_of_speaker_usage`='".$count_spk_res."',`total_email_count`='".$count_spk_res2."' WHERE id='".$typeid."' AND event_id='".$event_id."'");

                }

             }
           }

            if($update_status_details){
                echo 'success';
            }else{
                echo 'failed';
            }

    }


   function calculate_master_type_count($event_id=null){

        $masters_data1 = mysqli_query($this->connect,"SELECT group_concat(id) as type_id FROM all_master_types WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($masters_data1) > 0)
            {  
                $res1 = mysqli_fetch_array($masters_data1);
                $row_id = $res1['type_id'];
                $status_ids_array1 = explode(",",$row_id);

                foreach ($status_ids_array1 as $typeid) { 
                if($typeid!=0)
                {

                    $query_sql_sp = mysqli_query($this->connect,"SELECT count(*) as count_masters FROM all_masters WHERE find_in_set('".$typeid."',all_masters.master_type) and all_masters.event_id='".$event_id."'");
                    $query_res_sp = mysqli_fetch_array($query_sql_sp);
                    $count_master_res = mysqli_real_escape_string($this->connect,$query_res_sp['count_masters']);

                     $query_sql_sp2 = mysqli_query($this->connect,"SELECT count(*) as count_email FROM all_logs WHERE (all_logs.operation='sent email to master' OR all_logs.operation='sent email to master scheduled') AND all_logs.table_id in (select id from all_masters where FIND_IN_SET('".$typeid."', master_type) AND event_id='".$event_id."')");
                    $query_res_sp2 = mysqli_fetch_array($query_sql_sp2);
                    $count_spk_res2 = mysqli_real_escape_string($this->connect,$query_res_sp2['count_email']);
                
                    $update_status_details = mysqli_query($this->connect, "UPDATE `all_master_types` SET `total_masters_enrolled`='".$count_master_res."',`total_email_count`='".$count_spk_res2."' WHERE id='".$typeid."' AND event_id='".$event_id."'" );

                }

             }
           }
   }

   function fetch_sponsor_dashboard_count($ev_id){

        $fetch_all_masters = mysqli_query($this->connect,"SELECT * from sponsor_dashboard_counts  where  event_id='".$ev_id."'");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }


    function calculate_sponsor_status_count($evt_id=null){
        $event_id= $evt_id;

        $speakers_data1 = mysqli_query($this->connect,"SELECT group_concat(id) as status_id FROM all_status WHERE event_id = '".$event_id."' and status_for='sponsor' ");
            if(mysqli_num_rows($speakers_data1) > 0)
            {  
                $res1 = mysqli_fetch_array($speakers_data1);
                $row_id = $res1['status_id'];
                $status_ids_array1 = explode(",",$row_id);

                foreach ($status_ids_array1 as $statusid) { 
                if($statusid!=0)
                {

                    $query_sql_sp = mysqli_query($this->connect,"SELECT count(*) as count_spk FROM all_sponsors WHERE all_sponsors.status='".$statusid."' and all_sponsors.event_id='".$event_id."'");
                    $query_res_sp = mysqli_fetch_array($query_sql_sp);
                    $count_spk_res = mysqli_real_escape_string($this->connect,$query_res_sp['count_spk']);
                
                    $update_status_details = mysqli_query($this->connect, "UPDATE `all_status` SET `count_of_speaker_usage`='".$count_spk_res."'   WHERE id=".$statusid);

                }

             }
           }

            if($update_status_details){
                echo 'success';
            }else{
                echo 'failed';
            }

    }

    function calculate_sponsor_type_count($evt_id=null){
        $event_id= $evt_id;

        $speakers_data1 = mysqli_query($this->connect,"SELECT group_concat(id) as type_id FROM all_sponsor_types WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($speakers_data1) > 0)
            {  
                $res1 = mysqli_fetch_array($speakers_data1);
                $row_id = $res1['type_id'];
                $status_ids_array1 = explode(",",$row_id);

                foreach ($status_ids_array1 as $typeid) { 
                if($typeid!=0)
                {

                    $query_sql_sp = mysqli_query($this->connect,"SELECT count(*) as count_spk FROM all_sponsors WHERE find_in_set('".$typeid."',all_sponsors.sponsor_type) and all_sponsors.event_id='".$event_id."'");
                    $query_res_sp = mysqli_fetch_array($query_sql_sp);
                    $count_spk_res = mysqli_real_escape_string($this->connect,$query_res_sp['count_spk']);

                    $query_sql_sp2 = mysqli_query($this->connect,"SELECT count(*) as count_email FROM all_logs WHERE (all_logs.operation='sent email to sponsor' OR all_logs.operation='sent email to sponsor scheduled') AND all_logs.table_id in (select id from all_sponsors where FIND_IN_SET('".$typeid."', sponsor_type) AND event_id='".$event_id."')");
                    $query_res_sp2 = mysqli_fetch_array($query_sql_sp2);
                    $count_spk_res2 = mysqli_real_escape_string($this->connect,$query_res_sp2['count_email']);
                
                    $update_status_details = mysqli_query($this->connect, "UPDATE `all_sponsor_types` SET `total_enrolled`='".$count_spk_res."',`total_email_count`='".$count_spk_res2."'   WHERE id='".$typeid."' AND event_id='".$event_id."'");

                }

             }
           }

            if($update_status_details){
                echo 'success';
            }else{
                echo 'failed';
            }

    }

     function total_user_checker($eid=null)
     {
         if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $fetch_sql = mysqli_query($this->connect,"SELECT * from all_users where user_id='".$user_id."' ");   
         $res_sql = mysqli_fetch_array($fetch_sql);
         $session_tanent_id= $res_sql['tanent_id'];
         $subscription_id = $res_sql['subscription_id'];
          

                if(!empty($subscription_id) ){
                    
                    $total_user = $this->get_total_users_count_by_tenantid($session_tanent_id);
                    $subs_details = $this->subscription_retrive_by_subscription_id_new($subscription_id);
                    $plan_id_fetched = $subs_details['subscription']->planId;
                    $fetch_contact_limit = mysqli_query($this->connect,"SELECT * FROM subscription_plans_details WHERE plan_id = '".$plan_id_fetched."' ");
                    $res_contact_limit = mysqli_fetch_array($fetch_contact_limit);
                    $user_limit = $res_contact_limit['total_users'];

                }else{
                    $total_user = $this->get_total_users_count_by_tenantid($session_tanent_id);
                    //if not subscribed any plan and tenant in trial period
                    $fetch_contact_limit = mysqli_query($this->connect,"SELECT * FROM subscription_plans_details WHERE plan_id = 'essential' ");
                    $res_contact_limit = mysqli_fetch_array($fetch_contact_limit);
                    $user_limit = $res_contact_limit['total_users'];
                    
                }        

        if($total_user>=$user_limit)
        {
            $total_contact_flag=1;
        }else
        {
             $total_contact_flag=0;
        }

        return  $total_contact_flag;
    }

    function get_total_users_count_by_tenantid($tenant_id=null){
            
            $total_count = 0;
            $count_total_contacts = mysqli_query($this->connect,"SELECT  count(user_id) as total_count from all_users where tanent_id = '".$tenant_id."'");
            $res_count = mysqli_fetch_array($count_total_contacts);
            $total_count = $res_count['total_count'];
             return $total_count;

    }

    function calculate_template_usage($template_id,$event_id,$id_val){

         if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $fetch_sql = mysqli_query($this->connect,"SELECT * from all_users where user_id='".$user_id."' ");   
         $res_sql = mysqli_fetch_array($fetch_sql);
         $session_tanent_id= $res_sql['tanent_id'];

        if($template_id != '9998' || $template_id != '9999')
        {
            $template_usage_data = mysqli_query($this->connect,"SELECT count(id) as temp_cnt FROM all_logs WHERE event_id = '".$event_id."' AND other_column_name='template_id' AND other_column_value = '".$template_id."' ");
            $res1 = mysqli_fetch_array($template_usage_data);
            $total_count = $res1['temp_cnt'];

            $template_read_data = mysqli_query($this->connect,"SELECT count(id) as email_read FROM all_logs WHERE event_id = '".$event_id."' AND other_column_name='template_id' AND other_column_value = '".$template_id."' AND email_read='y' ");
            $result = mysqli_fetch_array($template_read_data);
            $total_count_read = $result['email_read'];

            $check_temp_exist = mysqli_query($this->connect, "SELECT * FROM `all_email_template_usage_info` WHERE `event_id` = '".$event_id."' AND template_id = '".$template_id."' ");
                if(mysqli_num_rows($check_temp_exist)> 0){
                    $update_template_details = mysqli_query($this->connect, "UPDATE `all_email_template_usage_info` SET `total_usage`='".$total_count."',`total_read`='".$total_count_read."' WHERE `event_id` = '".$event_id."' AND template_id = '".$template_id."'");
                }else{

                    $update_template_details = mysqli_query($this->connect, "INSERT INTO `all_email_template_usage_info` (tanent_id,event_id,template_id,total_usage,total_read) VALUES ('$session_tanent_id','$event_id','$template_id','$total_count','$total_count_read')");               
                }
        }

        if($id_val=='1')
        {

            if($template_id != '9998' || $template_id != '9999')
            {
                 $fetch_temp = mysqli_query($this->connect,"SELECT template_name FROM all_email_templates WHERE id = '".$template_id."'");
                 $res_template = mysqli_fetch_array($fetch_temp);
                 $templatename = $res_template['template_name'];

                $condition = "(all_logs.operation='sent email to speaker' OR all_logs.operation='sent email to speaker Event Presentation') AND all_logs.other_column_name='template_id' AND all_logs.other_column_value = '".$template_id."'";
            }
             if($template_id == '9998')
            {
                $templatename='Request missing information';
                $condition = "all_logs.operation='request missing information'";
            }

            if($template_id == '9999')
            {
                $templatename='Request missing documents';
                $condition = "all_logs.operation='request missing documents'";
            }

            $template_usage_spk = mysqli_query($this->connect,"SELECT count(id) as temp_cnt FROM all_logs WHERE ".$condition."  AND all_logs.event_id = '".$event_id."'");
            $res_spk = mysqli_fetch_array($template_usage_spk);
            $total_count_spk = $res_spk['temp_cnt'];

            $template_read_data_spk = mysqli_query($this->connect,"SELECT count(id) as email_read FROM all_logs WHERE ".$condition."  AND all_logs.event_id = '".$event_id."' AND all_logs.email_read='y' ");
            $result_spk = mysqli_fetch_array($template_read_data_spk);
            $total_count_read_spk = $result_spk['email_read'];

            $sql_query_log="DELETE from recent_communication_speaker where template_id='".$template_id."' AND event_id = '".$event_id."'";
            mysqli_query($this->connect,$sql_query_log);

            $insert_recent_commu = mysqli_query($this->connect, "INSERT INTO `recent_communication_speaker` (event_id,template_id,template_name,total_email_sent,total_email_opened,created_at) VALUES ('$event_id','$template_id','$templatename','$total_count_spk','$total_count_read_spk',now())");  

        }

        if($id_val=='2')
        {

            if($template_id != '9998' || $template_id != '9999')
            {
                 $fetch_temp = mysqli_query($this->connect,"SELECT template_name FROM all_email_templates WHERE id = '".$template_id."'");
                 $res_template = mysqli_fetch_array($fetch_temp);
                 $templatename = $res_template['template_name'];

                $condition = "all_logs.operation='sent email to sponsor' AND all_logs.other_column_name='template_id' AND all_logs.other_column_value = '".$template_id."'";
            }
          
            if($template_id == '9998')
           {
               $templatename='Request missing information sponsor';
               $condition = "all_logs.operation='Request missing information sponsor'";
           }

           if($template_id == '9999')
           {
               $templatename='Request missing documents sponsor';
               $condition = "all_logs.operation='Request missing documents sponsor'";
           }

            $template_usage_spn = mysqli_query($this->connect,"SELECT count(id) as temp_cnt FROM all_logs WHERE ".$condition."  AND all_logs.event_id = '".$event_id."'");
            $res_spn = mysqli_fetch_array($template_usage_spn);
            $total_count_spn = $res_spn['temp_cnt'];

            $template_read_data_spn = mysqli_query($this->connect,"SELECT count(id) as email_read FROM all_logs WHERE ".$condition."  AND all_logs.event_id = '".$event_id."' AND all_logs.email_read='y' ");
            $result_spn = mysqli_fetch_array($template_read_data_spn);
            $total_count_read_spn = $result_spn['email_read'];

            $del_query_log="DELETE from recent_communication_sponsor where template_id='".$template_id."' AND event_id = '".$event_id."'";
            mysqli_query($this->connect,$del_query_log);

            $insert_recent_commu_spn = mysqli_query($this->connect, "INSERT INTO `recent_communication_sponsor` (event_id,template_id,template_name,total_email_sent,total_email_opened,created_at) VALUES ('$event_id','$template_id','$templatename','$total_count_spn','$total_count_read_spn',now())");  

        }

        if($id_val=='3')
        {

            if($template_id != '9998')
            {
                 $fetch_temp = mysqli_query($this->connect,"SELECT template_name FROM all_email_templates WHERE id = '".$template_id."'");
                 $res_template = mysqli_fetch_array($fetch_temp);
                 $templatename = $res_template['template_name'];

                $condition = "all_logs.operation='sent email to master' AND all_logs.other_column_name='template_id' AND all_logs.other_column_value = '".$template_id."'";
            }
          
            if($template_id == '9998')
           {
               $templatename='Request missing information master';
               $condition = "all_logs.operation='Request missing information master'";
           }

             

            $template_usage_ms = mysqli_query($this->connect,"SELECT count(id) as temp_cnt FROM all_logs WHERE ".$condition."  AND all_logs.event_id = '".$event_id."'");
            $res_ms = mysqli_fetch_array($template_usage_ms);
            $total_count_ms = $res_ms['temp_cnt'];

            $template_read_data_ms = mysqli_query($this->connect,"SELECT count(id) as email_read FROM all_logs WHERE ".$condition."  AND all_logs.event_id = '".$event_id."' AND all_logs.email_read='y' ");
            $result_ms = mysqli_fetch_array($template_read_data_ms);
            $total_count_read_ms = $result_ms['email_read'];

            $del_query_log="DELETE from recent_communication_master where template_id='".$template_id."' AND event_id = '".$event_id."'";
            mysqli_query($this->connect,$del_query_log);

            $insert_recent_commu_spn = mysqli_query($this->connect, "INSERT INTO `recent_communication_master` (event_id,template_id,template_name,total_email_sent,total_email_opened,created_at) VALUES ('$event_id','$template_id','$templatename','$total_count_ms','$total_count_read_ms',now())");   

        }

        // if($update_template_details){
        //         echo 'success';
        //     }else{
        //         echo 'failed';
        //     }
    }

     function fetch_all_sponsors_asc_new($event_id){
          $fetch_all_sponsors = mysqli_query($this->connect,"SELECT id,sponsor_company_name FROM all_sponsors where all_sponsors.event_id='".$event_id."' ORDER BY all_sponsors.sponsor_company_name ASC");
          
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_sponsors) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_sponsors)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }

    }

        function sd_get_count_total_tenants(){
        $count_sql = mysqli_query($this->connect,"select count(id) as total_tenant_cnt from all_tenants");
        if(empty($count_sql)) $total_tenant = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_tenant=$res_sql['total_tenant_cnt'];
        return $total_tenant;
    }

    function sd_get_count_total_paid_tenants(){
        $count_sql = mysqli_query($this->connect,"select count(id) as total_tenant_cnt from all_tenants WHERE plan_id!=''");
        if(empty($count_sql)) $total_tenant = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_tenant=$res_sql['total_tenant_cnt'];
        return $total_tenant;
    }

    function sd_get_count_total_trial_tenants(){
        $count_sql = mysqli_query($this->connect,"select count(id) as total_tenant_cnt from all_tenants WHERE plan_id=''");
       // AND DATEDIFF(CURDATE(), DATE_FORMAT(created_at, '%Y-%m-%d')) > 0 AND DATEDIFF(CURDATE(), DATE_FORMAT(created_at, '%Y-%m-%d')) < 30
        if(empty($count_sql)) $total_tenant = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_tenant=$res_sql['total_tenant_cnt'];
        return $total_tenant;
    }

    function sd_get_count_total_essential_plan(){
        $count_sql = mysqli_query($this->connect,"select count(id) as total_tenant_cnt from all_tenants WHERE plan_id='essential'");
        if(empty($count_sql)) $total_tenant = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_tenant=$res_sql['total_tenant_cnt'];
        return $total_tenant;
    }

    function sd_get_count_total_professional_plan(){
        $count_sql = mysqli_query($this->connect,"select count(id) as total_tenant_cnt from all_tenants WHERE plan_id='professional-plan-1'");
        if(empty($count_sql)) $total_tenant = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_tenant=$res_sql['total_tenant_cnt'];
        return $total_tenant;
    }

    function sd_get_count_total_premier_plan(){
        $count_sql = mysqli_query($this->connect,"select count(id) as total_tenant_cnt from all_tenants WHERE plan_id='premier'");
        if(empty($count_sql)) $total_tenant = 0; 
        $res_sql=mysqli_fetch_array($count_sql);
        $total_tenant=$res_sql['total_tenant_cnt'];
        return $total_tenant;
    }

    function sd_get_count_total_email_sent(){


            $count_total_email_sent = mysqli_query($this->connect,"select sum(speaker_email_count) as speaker_cnt,sum(sponsor_email_count) as sponsor_cnt,sum(master_email_count) as master_cnt from all_event_email_count");   
            $total_email_sent = 0;    
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_speaker_cnt = $res['speaker_cnt'];
                $total_sponsor_cnt = $res['sponsor_cnt'];
                $total_master_cnt = $res['master_cnt'];
            }
            $total_email_sent=$total_speaker_cnt+$total_sponsor_cnt+$total_master_cnt;
            return $total_email_sent;
    }

    function sd_get_total_storage_count()
    {
        
        $fetch_total_storage = mysqli_query($this->connect,"SELECT sum(speaker_storage) as speaker_storage,sum(sponsor_storage) as sponsor_storage,sum(action_tracker_storage) as action_tracker_storage,sum(resource_tracker_storage) as resource_tracker_storage,sum(profile_storage) as profile_storage FROM all_total_storage");
        if(mysqli_num_rows($fetch_total_storage) > 0){        
            $res_storage = mysqli_fetch_array($fetch_total_storage);
            $t_storage = $res_storage['speaker_storage']+$res_storage['sponsor_storage']+$res_storage['action_tracker_storage']+$res_storage['resource_tracker_storage']+$res_storage['profile_storage'];
            $total_storage_in_mb = round($t_storage/ 1024, 2);

            $total_storage = round($total_storage_in_mb / 1024,3);
 
        }else{
            $total_storage = 0;
        }

        return  $total_storage;
    }

    function sd_get_total_event_count()
    {

        $count_total_events = mysqli_num_rows(mysqli_query($this->connect,"select * from all_events"));
        if(empty($count_total_events)) $count_total_events = 0; 
        return $count_total_events;
    }

    function sd_get_count_all_total_speakers(){


            $count_total_email_sent = mysqli_query($this->connect,"select ifnull(sum(total_speakers),0) as speaker_cnt from speaker_dashboard_count");   
            $total_email_sent = 0;  
            $total_speaker_cnt = 0; 
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_speaker_cnt = $res['speaker_cnt'];
            }
            return $total_speaker_cnt;
    }

    function sd_get_count_all_total_sponsors(){


            $count_total_email_sent = mysqli_query($this->connect,"select ifnull(sum(total_sponsors),0) as sponsor_cnt from sponsor_dashboard_counts");   
            $total_email_sent = 0; 
            $total_sponsor_cnt = 0;   
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_sponsor_cnt = $res['sponsor_cnt'];
            }
            return $total_sponsor_cnt;
    }

    function sd_get_count_all_unique_contacts(){

             $total_email_sent = 0; 

             $count_total_email_sent_speaker = mysqli_query($this->connect,"select sum(total_speakers) as speaker_cnt from speaker_dashboard_count");   

            if( mysqli_num_rows($count_total_email_sent_speaker) > 0){
                $res = mysqli_fetch_array($count_total_email_sent_speaker);
                $total_speaker_cnt = $res['speaker_cnt'];
            }

             $count_total_email_sent_sponsor = mysqli_query($this->connect,"select sum(total_sponsors) as sponsor_cnt from sponsor_dashboard_counts");   

            if( mysqli_num_rows($count_total_email_sent_sponsor) > 0){
                $res1 = mysqli_fetch_array($count_total_email_sent_sponsor);
                $total_sponsor_cnt = $res1['sponsor_cnt'];
            }

             $count_total_email_sent_master = mysqli_query($this->connect,"select sum(total_contact) as master_cnt from master_dashboard_counts");   

            if( mysqli_num_rows($count_total_email_sent_master) > 0){
                $res2 = mysqli_fetch_array($count_total_email_sent_master);
                $total_master_cnt = $res2['master_cnt'];
            }

            $total_email_sent=$total_speaker_cnt+$total_sponsor_cnt+$total_master_cnt;
            return $total_email_sent;
    }

 function fetch_all_recent_activities(){

             $fetch_all_masters = mysqli_query($this->connect,"SELECT id,tenant_name,plan_id as plan_name,date(created_at) as joining_date, date(created_at)  as renewal_date,created_at,
                (select created_at from payment_info  where tenant_id=alt.id order by id asc limit 1) as upgrade_date,
                (select first_name from all_users where user_id=alt.created_by) as admin_name,(select email from all_users where user_id=alt.created_by) as email
                 FROM all_tenants alt order by id DESC limit 10");
        
            $inner_array = array();
            if(mysqli_num_rows($fetch_all_masters) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_all_masters)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }

        }

         function fetch_all_recent_activities_page($start=1,$limit=null){


            $fetch_all_masters = mysqli_query($this->connect,"SELECT id,tenant_name,plan_id as plan_name,date(created_at) as joining_date, date(created_at)  as renewal_date,created_at,
                (select created_at from payment_info  where tenant_id=alt.id order by id asc limit 1) as upgrade_date,
                (select first_name from all_users where user_id=alt.created_by) as admin_name,(select email from all_users where user_id=alt.created_by) as email,
                (select coupon_code from payment_info where user_id=alt.created_by order by id desc limit 1) as coupon_code,
                 (select date(Last_payment_date) from payment_info where user_id=alt.created_by order by id desc limit 1) as Last_payment_date,
                  ifnull((select Last_payment_made from payment_info where user_id=alt.created_by order by id desc limit 1),0) as Last_payment_made
                 FROM all_tenants alt order by id DESC LIMIT $start, $limit");
            $inner_array = array();
            if(mysqli_num_rows($fetch_all_masters) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_all_masters)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }

        }

    function total_email_sent_per_month()
    {
         if(!isset($_SESSION)){ session_start(); }
         $user_id = $_SESSION['user_id'];
         $fetch_sql = mysqli_query($this->connect,"SELECT * from all_users where user_id='".$user_id."' ");   
         $res_sql = mysqli_fetch_array($fetch_sql);
         $session_tanent_id= $res_sql['tanent_id'];
         $subscription_id = $res_sql['subscription_id'];

        $total_email_sent = $this->get_total_email_sent_per_month($session_tanent_id);

        //.......................
           $check_tenant_subs = mysqli_query($this->connect,"SELECT * FROM `all_tenants` WHERE `id` = '".$session_tanent_id."' ");
            $res_ten = mysqli_fetch_array($check_tenant_subs);
            $tenant_created_at = date('Y-m-d',strtotime($res_ten['created_at']));
            $now = time(); // or your date as well
            $your_date = strtotime($tenant_created_at);
            $datediff = $now - $your_date;
            $final_date= round($datediff / (60 * 60 * 24));
            
            if($final_date < 100){   
                if($subscription_id != ''){

                    $subs_details = $this->subscription_retrive_by_subscription_id_new($subscription_id);
                    $plan_id_fetched = $subs_details['subscription']->planId;
                    $fetch_contact_limit = mysqli_query($this->connect,"SELECT * FROM subscription_plans_details WHERE plan_id = '".$plan_id_fetched."' ");
                    $res_contact_limit = mysqli_fetch_array($fetch_contact_limit);
                    $email_per_month = $res_contact_limit['email_per_month'];

                }else{

                    //if not subscribed any plan and tenant in trial period
                    $fetch_contact_limit = mysqli_query($this->connect,"SELECT * FROM subscription_plans_details WHERE plan_id = 'essential' ");
                    $res_contact_limit = mysqli_fetch_array($fetch_contact_limit);
                    $email_per_month = $res_contact_limit['email_per_month'];

                }             

            }else{

                if($subscription_id != ''){

                    $subs_details = $this->subscription_retrive_by_subscription_id_new($subscription_id);
                    $plan_id_fetched = $subs_details['subscription']->planId;
                    $fetch_contact_limit = mysqli_query($this->connect,"SELECT * FROM subscription_plans_details WHERE plan_id = '".$plan_id_fetched."' ");
                    $res_contact_limit = mysqli_fetch_array($fetch_contact_limit);
                    $email_per_month = $res_contact_limit['email_per_month'];

                }else{

                    //if not subscribed any plan and tenant in trial period
                    $fetch_contact_limit = mysqli_query($this->connect,"SELECT * FROM subscription_plans_details WHERE plan_id = 'essential' ");
                    $res_contact_limit = mysqli_fetch_array($fetch_contact_limit);
                    $email_per_month = $res_contact_limit['email_per_month'];

                }    
                    
            }  

            //var_dump($total_contact ." || ".$contact_limit ); exit();    

        if($total_email_sent>=$email_per_month)
        {
            $total_email_sent_flag=1;
        }else
        {
             $total_email_sent_flag=0;
        }

        return  $total_email_sent_flag;
    }

    function get_total_email_sent_per_month($tenant_id=null){
            $firstDayUTS = mktime (0, 0, 0, date("m"), 1, date("Y"));
            $lastDayUTS = mktime (0, 0, 0, date("m"), date('t'), date("Y"));

             // $firstDay = '2019-10-01';
             // $lastDay = '2019-10-31';
             $firstDay = date("Y-m-d", $firstDayUTS);
             $lastDay = date("Y-m-d", $lastDayUTS);

            $total_email_sent = 0;
            $count_total_email_sent_speaker = mysqli_query($this->connect,"select  count(id) as tot_cnt_spk from all_logs al where (al.operation='sent email to speaker' OR al.operation='sent email to speaker scheduled' OR al.operation='request missing information' OR al.operation='request missing documents' OR al.operation='request missing information scheduled' OR al.operation='request missing documents scheduled' OR al.operation='sent email to speaker Event Presentation' OR al.operation='Request for Update Agenda') AND tanent_id = '".$tenant_id."' AND date(created_at)>='".$firstDay."' AND date(created_at)<='".$lastDay."'");   

            if( mysqli_num_rows($count_total_email_sent_speaker) > 0){
                $res = mysqli_fetch_array($count_total_email_sent_speaker);
                $total_speaker_cnt = $res['tot_cnt_spk'];
            }

             $count_total_email_sent_sponsor = mysqli_query($this->connect,"select  count(id) as tot_cnt_sponsor from all_logs al where  (al.operation='sent email to sponsor' or al.operation='sent email to sponsor scheduled' or al.operation='request missing information sponsor' or al.operation='request missing documents sponsor' OR al.operation='request missing information sponsor scheduled' or al.operation='request missing documents sponsor scheduled') AND tanent_id = '".$tenant_id."' AND date(created_at)>='".$firstDay."' AND date(created_at)<='".$lastDay."'");   

            if( mysqli_num_rows($count_total_email_sent_sponsor) > 0){
                $res1 = mysqli_fetch_array($count_total_email_sent_sponsor);
                $total_sponsor_cnt = $res1['tot_cnt_sponsor'];
            }

             $count_total_email_sent_master = mysqli_query($this->connect,"select  count(id) as tot_cnt_master from all_logs   WHERE (all_logs.operation='sent email to master' OR all_logs.operation='sent email to master scheduled') AND tanent_id = '".$tenant_id."' AND date(created_at)>='".$firstDay."' AND date(created_at)<='".$lastDay."'");   

            if( mysqli_num_rows($count_total_email_sent_master) > 0){
                $res2 = mysqli_fetch_array($count_total_email_sent_master);
                $total_master_cnt = $res2['tot_cnt_master'];
            }

            $total_email_sent=$total_speaker_cnt+$total_sponsor_cnt+$total_master_cnt;
             
             return $total_email_sent;

    }

        function fetch_all_dropped_users(){

           if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id'];

            $fetch_all_masters = mysqli_query($this->connect,"SELECT pu.id,pu.email_id,concat(pu.first_name,' ',pu.last_name) as full_name,pu.created_at from pre_registered_users pu where pu.email_id not in (select email from all_users) group by email_id ORDER BY id DESC");
 
            $inner_array = array();
            if(mysqli_num_rows($fetch_all_masters) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_all_masters)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }

        }


    function backup_tables($host,$user,$pass,$name,$db_name,$tables = '*') {
                $return = "";
                $link = mysqli_connect($host,$user,$pass,$name);
                mysqli_set_charset( $link,"utf8");
                //mysqli_select_db($name,$link);
                //get all of the tables
                if($tables == '*') {
                    $tables = array();
                    $result = mysqli_query($link,'SHOW TABLES');
                    while($row = mysqli_fetch_row($result)) {
                        $tables[] = $row[0];
                    }
                } else {
                    $tables = is_array($tables) ? $tables : explode(',',$tables);
                }
                //cycle through
                foreach($tables as $table) {
                    $result = mysqli_query($link,'SELECT * FROM '.$table);
                    $num_fields = mysqli_num_fields($result);
                    $row2 = mysqli_fetch_row(mysqli_query($link,'SHOW CREATE TABLE '.$table));
                    $return.= $row2[1].";\n\n";
                    for ($i = 0; $i < $num_fields; $i++) {
                        while($row = mysqli_fetch_row($result)) {
                            $return.= 'INSERT INTO '.$table.' VALUES(';
                            for($j=0; $j<$num_fields; $j++) {
                                $row[$j] = addslashes($row[$j]);
                                $row[$j] = str_replace("\n","\\n",$row[$j]);
                                if (isset($row[$j])) { 
                                    $return.= '"'.$row[$j].'"' ;
                                } else { 
                                    $return.= '""'; 
                                }
                                if ($j<($num_fields-1)) { 
                                    $return.= ','; 
                                }
                            }
                            $return.= ");\n";
                        }
                    }
                    $return.="\n\n\n";
                }
                if(!file_exists('dbfiles/')){
                    mkdir("dbfiles/", 0777);
                }

            $handle = 'dbfiles/'.$db_name.date('d.m.Y').'.sql';
            $myfile = fopen($handle, "w") or die("Unable to open file!");
            fwrite($myfile,  $return);
            fclose($myfile);
    
    }
    
    function mail_curl($fileName=null,$body,$tomail,$mailsubject,$frommail,$cc_mails){
        $url = 'https://api.sendgrid.com/';
        $user = 'Meylahcorp';
        $pass = 'Em@ils19!';
        $filePath = dirname(__FILE__);

        $cc_array = explode(",", $cc_mails);


        $params = array(
            'api_user'  => $user,
            'api_key'   => $pass,
            'to'        => $tomail,
            'cc[0]'     => $cc_array[0],
            'cc[1]'     => $cc_array[1],
            // 'cc[2]'     => $cc_array[2],
            // 'cc[3]'     => $cc_array[3],
            'subject'   => $mailsubject,
            'html'      => $body,
            'from'      => $frommail,
           // 'files['.$fileName.']' =>  new CURLFile('dbfiles/'.$fileName)
          );

        $request =  $url.'api/mail.send.json';

        // Generate curl request
        $session = curl_init($request);

        // Tell curl to use HTTP POST
        curl_setopt ($session, CURLOPT_POST, true);

        // Tell curl that this is the body of the POST
        curl_setopt ($session, CURLOPT_POSTFIELDS, $params);

        // Tell curl not to return headers, but do return the response
        curl_setopt($session, CURLOPT_HEADER, false);
        // Tell PHP not to use SSLv3 (instead opting for TLS)
        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

        // obtain response
        $response = curl_exec($session);
        curl_close($session);

        // print everything out
        print_r($response);
            
    }

    function sd_get_total_event_count_by_tenantid($tid)
    {
        $count_total_events = mysqli_num_rows(mysqli_query($this->connect,"select * from all_events where tanent_id='".$tid."'"));
        if(empty($count_total_events)) $count_total_events = 0; 
        return $count_total_events;
    }

    function sd_get_count_all_total_speakers_by_tenantid($tid){
            $count_total_email_sent = mysqli_query($this->connect,"select ifnull(sum(total_speakers),0) as speaker_cnt from speaker_dashboard_count WHERE tanent_id='".$tid."'");   
            $total_email_sent = 0;  
            $total_speaker_cnt = 0; 
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_speaker_cnt = $res['speaker_cnt'];
            }
            return $total_speaker_cnt;
    }

    function sd_get_count_all_total_sponsors_by_tenantid($tid){
            $count_total_email_sent = mysqli_query($this->connect,"select ifnull(sum(total_sponsors),0) as sponsor_cnt from sponsor_dashboard_counts WHERE tanent_id='".$tid."'");   
            $total_email_sent = 0; 
            $total_sponsor_cnt = 0;   
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_sponsor_cnt = $res['sponsor_cnt'];
            }
            return $total_sponsor_cnt;
    }

        function sd_get_count_total_email_sent_by_tenantid($tid){

            $count_total_email_sent = mysqli_query($this->connect,"select sum(speaker_email_count) as speaker_cnt,sum(sponsor_email_count) as sponsor_cnt,sum(master_email_count) as master_cnt from all_event_email_count WHERE tanent_id='".$tid."'");   
            $total_email_sent = 0;    
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_speaker_cnt = $res['speaker_cnt'];
                $total_sponsor_cnt = $res['sponsor_cnt'];
                $total_master_cnt = $res['master_cnt'];
            }
            $total_email_sent=$total_speaker_cnt+$total_sponsor_cnt+$total_master_cnt;
            return $total_email_sent;
    }

    function sd_get_total_storage_count_by_tenantid($tid)
    {
        
        $fetch_total_storage = mysqli_query($this->connect,"SELECT sum(speaker_storage) as speaker_storage,sum(sponsor_storage) as sponsor_storage,sum(action_tracker_storage) as action_tracker_storage,sum(resource_tracker_storage) as resource_tracker_storage,sum(profile_storage) as profile_storage FROM all_total_storage WHERE tanent_id='".$tid."'");
        if(mysqli_num_rows($fetch_total_storage) > 0){        
            $res_storage = mysqli_fetch_array($fetch_total_storage);
            $t_storage = $res_storage['speaker_storage']+$res_storage['sponsor_storage']+$res_storage['action_tracker_storage']+$res_storage['resource_tracker_storage']+$res_storage['profile_storage'];
            $total_storage_in_mb = round($t_storage/ 1024, 2);

            $total_storage = round($total_storage_in_mb / 1024,3);
 
        }else{
            $total_storage = 0;
        }

        return  $total_storage;
    }

     function sd_get_count_all_unique_contacts_by_tenantid($tid){
             $total_email_sent = 0; 

             $count_total_email_sent_speaker = mysqli_query($this->connect,"select sum(total_speakers) as speaker_cnt from speaker_dashboard_count WHERE tanent_id='".$tid."'");   

            if( mysqli_num_rows($count_total_email_sent_speaker) > 0){
                $res = mysqli_fetch_array($count_total_email_sent_speaker);
                $total_speaker_cnt = $res['speaker_cnt'];
            }

             $count_total_email_sent_sponsor = mysqli_query($this->connect,"select sum(total_sponsors) as sponsor_cnt from sponsor_dashboard_counts WHERE tanent_id='".$tid."'");   

            if( mysqli_num_rows($count_total_email_sent_sponsor) > 0){
                $res1 = mysqli_fetch_array($count_total_email_sent_sponsor);
                $total_sponsor_cnt = $res1['sponsor_cnt'];
            }

             $count_total_email_sent_master = mysqli_query($this->connect,"select sum(total_contact) as master_cnt from master_dashboard_counts WHERE tanent_id='".$tid."'");   

            if( mysqli_num_rows($count_total_email_sent_master) > 0){
                $res2 = mysqli_fetch_array($count_total_email_sent_master);
                $total_master_cnt = $res2['master_cnt'];
            }

            $total_email_sent=$total_speaker_cnt+$total_sponsor_cnt+$total_master_cnt;
            return $total_email_sent;
    }

         function get_count_total_time_saving_by_tenantid($tid){
            
             $count_total_email_sent = mysqli_query($this->connect,"select round((sum(speaker_email_count)/1000)*25,2) as speaker_cnt,round((sum(sponsor_email_count)/1000)*25,2) as sponsor_cnt,round((sum(master_email_count)/1000)*25,2) as master_cnt from all_event_email_count WHERE tanent_id='$tid'");   

            $total_hour_saving = 0;    
            if( mysqli_num_rows($count_total_email_sent) > 0){
                $res = mysqli_fetch_array($count_total_email_sent);
                $total_speaker_cnt = $res['speaker_cnt'];
                $total_sponsor_cnt = $res['sponsor_cnt'];
                $total_master_cnt = $res['master_cnt'];
            }
            $total_hour_saving=$total_speaker_cnt+$total_sponsor_cnt+$total_master_cnt;
            return $total_hour_saving;

    }

       function SA_search_tenant_name($searchtext=null){

            $fetch_all_masters = mysqli_query($this->connect,"SELECT id,tenant_name,plan_id as plan_name,date(created_at) as joining_date, date(created_at)  as renewal_date,created_at,
                (select created_at from payment_info  where tenant_id=alt.id order by id asc limit 1) as upgrade_date,
                (select first_name from all_users where user_id=alt.created_by) as admin_name,(select email from all_users where user_id=alt.created_by) as email,
                (select coupon_code from payment_info where user_id=alt.created_by order by id desc limit 1) as coupon_code,
                 (select date(Last_payment_date) from payment_info where user_id=alt.created_by order by id desc limit 1) as Last_payment_date,
                  ifnull((select Last_payment_made from payment_info where user_id=alt.created_by order by id desc limit 1),0) as Last_payment_made
                 FROM all_tenants alt WHERE  alt.tenant_name like '%$searchtext%' order by id DESC");
            $inner_array = array();
            if(mysqli_num_rows($fetch_all_masters) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_all_masters)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }
    }



    function fetch_all_event_agenda_dates($evt_id=null){

        $event_id= $evt_id;

          $fetch_all_masters = mysqli_query($this->connect,"select distinct event_date, DATE_FORMAT(event_date,'%W,%M %d') AS showdate from event_presentation where event_id = '".$event_id."' order by event_date ASC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_event_agenda_info_by_date($evt_id,$evt_date){

        $event_id= $evt_id;

        if($evt_date=='0')
        {
            $count_total_email_sent_speaker = mysqli_query($this->connect,"select distinct event_date from event_presentation where event_id = '".$event_id."' order by event_date ASC limit 1");  

            if( mysqli_num_rows($count_total_email_sent_speaker) > 0){
                $res = mysqli_fetch_array($count_total_email_sent_speaker);
                $evt_date = $res['event_date'];
            }

        }

         $fetch_all_masters = mysqli_query($this->connect,"SELECT ep.*,(select group_concat(speaker_id) from event_agenda_speakers where event_agenda_speakers.ep_id=ep.ep_id) as speaker_id,total_email_sent as count_email_sent,total_team_scheduled_email as count_team_email_sent from event_presentation ep where event_id = '".$event_id."' AND event_date = '".$evt_date."' order by str_to_date(start_time, '%l:%i %p') ASC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

      function fetch_event_agenda_time_by_date($evt_id,$evt_date){

        $event_id= $evt_id;

        if($evt_date=='0')
        {
            $count_total_email_sent_speaker = mysqli_query($this->connect,"select distinct event_date from event_presentation where event_id = '".$event_id."' order by event_date ASC limit 1");  

            if( mysqli_num_rows($count_total_email_sent_speaker) > 0){
                $res = mysqli_fetch_array($count_total_email_sent_speaker);
                $evt_date = $res['event_date'];
            }

        }

         $fetch_all_masters = mysqli_query($this->connect,"SELECT distinct start_time from event_presentation ep where event_id = '".$event_id."' AND event_date = '".$evt_date."' order by str_to_date(start_time, '%l:%i %p') ASC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }


    function fetch_event_agenda_by_time($evt_id,$evt_date,$starttime){

        $event_id= $evt_id;

        if($evt_date=='0')
        {
            $count_total_email_sent_speaker = mysqli_query($this->connect,"select distinct event_date from event_presentation where event_id = '".$event_id."' order by event_date ASC limit 1");  

            if( mysqli_num_rows($count_total_email_sent_speaker) > 0){
                $res = mysqli_fetch_array($count_total_email_sent_speaker);
                $evt_date = $res['event_date'];
            }

        }

         $fetch_all_masters = mysqli_query($this->connect,"SELECT ep.*,(select group_concat(speaker_id) from event_agenda_speakers where event_agenda_speakers.ep_id=ep.ep_id) as speaker_id,total_email_sent as count_email_sent,total_team_scheduled_email as count_team_email_sent from event_presentation ep where event_id = '".$event_id."' AND event_date = '".$evt_date."' AND start_time = '".$starttime."' order by str_to_date(start_time, '%l:%i %p') ASC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_event_agenda_location($evt_id,$evt_date){

        $event_id= $evt_id;

        if($evt_date=='0')
        {
            $count_total_email_sent_speaker = mysqli_query($this->connect,"select distinct event_date from event_presentation where event_id = '".$event_id."' order by event_date ASC limit 1");  

            if( mysqli_num_rows($count_total_email_sent_speaker) > 0){
                $res = mysqli_fetch_array($count_total_email_sent_speaker);
                $evt_date = $res['event_date'];
            }

        }

         $fetch_all_masters = mysqli_query($this->connect,"SELECT DISTINCT location from event_presentation where event_id = '".$event_id."' order by str_to_date(start_time, '%l:%i %p') ASC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_event_agenda_type_name($evt_id,$evt_date){

        $event_id= $evt_id;

        if($evt_date=='0')
        {
            $count_total_email_sent_speaker = mysqli_query($this->connect,"select distinct event_date from event_presentation where event_id = '".$event_id."' order by event_date ASC limit 1");  

            if( mysqli_num_rows($count_total_email_sent_speaker) > 0){
                $res = mysqli_fetch_array($count_total_email_sent_speaker);
                $evt_date = $res['event_date'];
            }

        }

         $fetch_all_masters = mysqli_query($this->connect,"SELECT DISTINCT opportunity_type from event_presentation where event_id = '".$event_id."'  order by str_to_date(start_time, '%l:%i %p') ASC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }


    function fetch_event_agenda_by_location($evt_id,$location,$otype){

        $event_id= $evt_id;

        if($otype=='0')
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT DISTINCT event_date, DATE_FORMAT(event_date,'%W,%M %d') AS showdate from event_presentation where event_id = '".$event_id."' AND location='".$location."'  order by event_date ASC");
        }else
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT DISTINCT event_date, DATE_FORMAT(event_date,'%W,%M %d') AS showdate from event_presentation where event_id = '".$event_id."' AND (location='".$location."' AND opportunity_type='".$otype."') order by event_date ASC");
        }

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

     function fetch_event_agenda_time_by_date_location($evt_id,$location,$evt_date,$otype){

        $event_id= $evt_id;

        if($otype=='0')
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT DISTINCT start_time from event_presentation where event_id = '".$event_id."' AND location='".$location."' AND event_date='".$evt_date."' order by start_time ASC");
        }else
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT DISTINCT start_time from event_presentation where event_id = '".$event_id."' AND (location='".$location."' AND opportunity_type='".$otype."') AND event_date='".$evt_date."' order by start_time ASC");
        }
         

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

  function fetch_event_content_by_time($evt_id,$location,$starttime,$otype){

        $event_id= $evt_id;

        if($otype=='0')
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT ep.*,(select group_concat(speaker_id) from event_agenda_speakers where event_agenda_speakers.ep_id=ep.ep_id) as speaker_id from event_presentation ep where event_id = '".$event_id."' AND location='".$location."' AND start_time = '".$starttime."' order by str_to_date(start_time, '%l:%i %p') ASC");
        }else
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT ep.*,(select group_concat(speaker_id) from event_agenda_speakers where event_agenda_speakers.ep_id=ep.ep_id) as speaker_id from event_presentation ep where event_id = '".$event_id."' AND (location='".$location."' AND opportunity_type='".$otype."') AND start_time = '".$starttime."' order by str_to_date(start_time, '%l:%i %p') ASC");
        }
         

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_event_agenda_by_opportunity_type($evt_id,$otype,$location){

        $event_id= $evt_id;

        if($location=='0')
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT DISTINCT event_date, DATE_FORMAT(event_date,'%W,%M %d') AS showdate from event_presentation where event_id = '".$event_id."' AND opportunity_type='".$otype."' order by event_date ASC");
        }else
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT DISTINCT event_date, DATE_FORMAT(event_date,'%W,%M %d') AS showdate from event_presentation where event_id = '".$event_id."' AND (location='".$location."' AND opportunity_type='".$otype."') order by event_date ASC");
        }

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_event_agenda_time_by_date_otype($evt_id,$otype,$evt_date,$location){

        $event_id= $evt_id;

        if($location=='0')
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT DISTINCT start_time from event_presentation where event_id = '".$event_id."' AND opportunity_type='".$otype."' AND event_date='".$evt_date."' order by start_time ASC");
        }else
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT DISTINCT start_time from event_presentation where event_id = '".$event_id."' AND (location='".$location."' AND opportunity_type='".$otype."') AND event_date='".$evt_date."' order by start_time ASC");
        }

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    function fetch_event_content_by_time_otype($evt_id,$otype,$starttime,$location){

        $event_id= $evt_id;

        if($location=='0')
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT ep.*,(select group_concat(speaker_id) from event_agenda_speakers where event_agenda_speakers.ep_id=ep.ep_id) as speaker_id from event_presentation ep where event_id = '".$event_id."' AND opportunity_type='".$otype."' AND start_time = '".$starttime."' order by str_to_date(start_time, '%l:%i %p') ASC");
        }else
        {
            $fetch_all_masters = mysqli_query($this->connect,"SELECT ep.*,(select group_concat(speaker_id) from event_agenda_speakers where event_agenda_speakers.ep_id=ep.ep_id) as speaker_id from event_presentation ep where event_id = '".$event_id."' AND (location='".$location."' AND opportunity_type='".$otype."') AND start_time = '".$starttime."' order by str_to_date(start_time, '%l:%i %p') ASC");
        }
         

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

     function fetch_view_event_agenda_info_by_date($evt_id,$evt_date){

        $event_id= $evt_id;

        if($evt_date=='0')
        {
            $count_total_email_sent_speaker = mysqli_query($this->connect,"select distinct event_date from event_presentation where event_id = '".$event_id."' order by event_date ASC limit 1");  

            if( mysqli_num_rows($count_total_email_sent_speaker) > 0){
                $res = mysqli_fetch_array($count_total_email_sent_speaker);
                $evt_date = $res['event_date'];
            }

        }

         $fetch_all_masters = mysqli_query($this->connect,"select ep_id,date_format(event_date, '%d-%b-%Y') as event_date,presentation_topic as presentation_name,abstract as abstract,business_objective as business_objective,start_time as start_time,end_time as end_time,location as location,topic_owner as topic_owner,(select group_concat(speaker_name separator ', ') as sname from all_speakers als where als.id in (select speaker_id from event_agenda_speakers where event_agenda_speakers.ep_id=event_presentation.ep_id)) as speaker_name,(select speaker_type_name from all_speaker_types alst where find_in_set(alst.id,event_presentation.opportunity_type)) as opportunity_type,(select count(*) from event_documents ed where find_in_set(ed.ep_id,event_presentation.ep_id)) as ppt_avail from event_presentation where event_id = '".$event_id."' AND event_date = '".$evt_date."' order by str_to_date(event_presentation.start_time, '%l:%i %p') ASC");

        $inner_array = array();
        if(mysqli_num_rows($fetch_all_masters) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_masters)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{ 
            return $inner_array;
        }
    }
     function fetch_speaker_status_for_approved_speaker($event_id=null){

        $fetch_all_speaker_types = mysqli_query($this->connect,"SELECT * FROM all_status WHERE status_name IN ('Approved','New','Rejected') AND status_for='speaker' AND event_id = '".$event_id."'");
        $inner_array = array();
        if(mysqli_num_rows($fetch_all_speaker_types) > 0)
        {            
            while($row = mysqli_fetch_array($fetch_all_speaker_types)){
                $inner_array[] = $row;
            }
            return $inner_array;            
        }
        else{
            return $inner_array;
        }
    }

    
     function fetch_event_presentation_coloboration_note_by_id($ep_id){
            $fetch_all_speaker_ppt= mysqli_query($this->connect,"SELECT epn.id,epn.notes,epn.event_id,epn.ep_id,date_format(epn.created_at, '%d-%M-%Y') as created_at,ifnull((select speaker_name from all_speakers where id=epn.created_by), (select first_name from all_users where user_id=epn.created_by)) as addedby FROM event_presentation_coloboration_notes epn WHERE ep_id ='".$ep_id."' ORDER BY id DESC ");
            $inner_array = array();
            if(mysqli_num_rows($fetch_all_speaker_ppt) > 0)
            {            
                while($row = mysqli_fetch_array($fetch_all_speaker_ppt)){
                    $inner_array[] = $row;
                }
                return $inner_array;            
            }
            else{
                return $inner_array;
            }

    }
   



} //end of class
function call_live_events_sp($event_name=null,$email_address=null,$event_date=null,$speaker_name=null,$contact_num=null,$sponsor_name=null,$company_name=null,$resource_name=null){
    include("include/mysqli_connect.php");
             if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id'];
                       $fetch_live_events_sp_sql = "call sp_advanced_search('$user_id','$event_name','$email_address','$event_date','$speaker_name','$contact_num','$sponsor_name','$company_name','$resource_name')";

            $fetch_live_events_sp = mysqli_query($connect,$fetch_live_events_sp_sql);

            // var_dump($fetch_live_events_sp); 
            $inner_array2 = array();
            if(mysqli_num_rows($fetch_live_events_sp) > 0)
            {    
           // echo "select";         
                while($row2 = mysqli_fetch_array($fetch_live_events_sp)){
                    $inner_array2[] = $row2;
                }
                return $inner_array2;            
            }
            else{
                return $inner_array2;
            }


        }

 function call_past_events_sp($event_name,$email_address,$event_date,$speaker_name,$contact_num,$sponsor_name,$company_name,$resource_name){
    include("include/mysqli_connect.php");
             if(!isset($_SESSION)){ session_start(); }
             $user_id = $_SESSION['user_id'];
             
            $fetch_live_events_sp = "call sp_advanced_search_past_events('$user_id','$event_name','$email_address','$event_date','$speaker_name','$contact_num','$sponsor_name','$company_name','$resource_name')";

            //$call = mysqli_query($this->connect,$fetch_live_events);
            $fetch_live_events_sp = mysqli_query($connect,$fetch_live_events_sp);
            $inner_array2 = array();
            if(mysqli_num_rows($fetch_live_events_sp) > 0)
            {            
                while($row2 = mysqli_fetch_array($fetch_live_events_sp)){
                    $inner_array2[] = $row2;
                }
                return $inner_array2;            
            }
            else{
                return $inner_array2;
            }
        }

    function speaker_advanced_search($sp_expertise,$speaker_name,$company_name,$sp_request,$participation_type,$evt_id){
            include("include/mysqli_connect.php");
              $event_id= $evt_id;
             
            $fetch_live_events_sp = "call speaker_advanced_search('$event_id','$sp_expertise','$speaker_name','$company_name','$sp_request','$participation_type')";

            $fetch_live_events_sp = mysqli_query($connect,$fetch_live_events_sp);
            $inner_array2 = array();
            if(mysqli_num_rows($fetch_live_events_sp) > 0)
            {            
                while($row2 = mysqli_fetch_array($fetch_live_events_sp)){
                    $inner_array2[] = $row2;
                }
                return $inner_array2;            
            }
            else{
                return $inner_array2;
            }
        }

        function sponsor_advanced_search($ad_email,$sp_status,$sp_type,$sponsor_name,$company_name,$evt_id){
            include("include/mysqli_connect.php");
              $event_id= $evt_id;
             
            $fetch_live_events_sp = "call sponsor_advanced_search('$event_id','$ad_email','$sp_status','$sp_type','$sponsor_name','$company_name')";
            //$call = mysqli_query($this->connect,$fetch_live_events);
            $fetch_live_events_sp = mysqli_query($connect,$fetch_live_events_sp);
            $inner_array2 = array();
            if(mysqli_num_rows($fetch_live_events_sp) > 0)
            {            
                while($row2 = mysqli_fetch_array($fetch_live_events_sp)){
                    $inner_array2[] = $row2;
                }
                return $inner_array2;            
            }
            else{
                return $inner_array2;
            }
        }

        function master_advanced_search($master_name,$master_email,$contact,$company_name,$master_type,$evt_id){
            include("include/mysqli_connect.php");
              $event_id= $evt_id;
             
            $fetch_live_events_sp = "call master_advanced_search('$event_id','$master_name','$master_email','$contact','$company_name','$master_type')";
            //$call = mysqli_query($this->connect,$fetch_live_events);
            $fetch_live_events_sp = mysqli_query($connect,$fetch_live_events_sp);
            $inner_array2 = array();
            if(mysqli_num_rows($fetch_live_events_sp) > 0)
            {            
                while($row2 = mysqli_fetch_array($fetch_live_events_sp)){
                    $inner_array2[] = $row2;
                }
                return $inner_array2;            
            }
            else{
                return $inner_array2;
            }
        }

       function new_master_advanced_search($master_name,$master_email,$contact,$company_name,$master_type,$evt_id){
            include("include/mysqli_connect.php");
              $event_id= $evt_id;
             
            $fetch_live_events_sp = "call new_master_advanced_search('$event_id','$master_name','$master_email','$contact','$company_name','$master_type')";
            //$call = mysqli_query($this->connect,$fetch_live_events);
            $fetch_live_events_sp = mysqli_query($connect,$fetch_live_events_sp);
            $inner_array2 = array();
            if(mysqli_num_rows($fetch_live_events_sp) > 0)
            {            
                while($row2 = mysqli_fetch_array($fetch_live_events_sp)){
                    $inner_array2[] = $row2;
                }
                return $inner_array2;            
            }
            else{
                return $inner_array2;
            }
        }

        function calculate_speaker_dashboard_count($event_id){
            include("mysqli_connect.php");
             
            $fetch_live_events_sp = "call Calculate_speaker_dashboard_count($event_id)";
            $fetch_live_events_sp = mysqli_query($connect,$fetch_live_events_sp);
            $inner_array2 = array();
            if(mysqli_num_rows($fetch_live_events_sp) > 0)
            {            
                while($row2 = mysqli_fetch_array($fetch_live_events_sp)){
                    $inner_array2[] = $row2;
                }
                return $inner_array2;            
            }
            else{
                return $inner_array2;
            }
        }

        function calculate_sponsor_dashboard_count($event_id){
            include("mysqli_connect.php");
             
            $fetch_live_events_sp = "call Calculate_sponsor_dashboard_count($event_id)";
            $fetch_live_events_sp = mysqli_query($connect,$fetch_live_events_sp);
            $inner_array2 = array();
            if(mysqli_num_rows($fetch_live_events_sp) > 0)
            {            
                while($row2 = mysqli_fetch_array($fetch_live_events_sp)){
                    $inner_array2[] = $row2;
                }
                return $inner_array2;            
            }
            else{
                return $inner_array2;
            }
        }

        function calculate_master_dashboard_count($event_id){
           include("mysqli_connect.php");
           
           $master_counts_sp = "call Calculate_master_dashboard_count($event_id)";
           $call_sp = mysqli_query($connect,$master_counts_sp);

           //
           $inner_array2 = array();
           if(mysqli_num_rows($call_sp) > 0)
           {            
               while($row2 = mysqli_fetch_array($call_sp)){
                   $inner_array2[] = $row2;
               }
               return $inner_array2;            
           }
           else{
               return $inner_array2;
           }
       }

           
   

?>