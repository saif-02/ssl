<?php 

include('include/common_functions.php');
$common = new commonFunctions();
$connect = $common->connect();
$id_user = $common->idUser();
error_reporting(0);
if(isset($_GET['action'])){
	$action=$_GET['action'];
}
else{
	$action=$_POST['action'];
}


switch($action){
	
	case "multipleImageUpload":
	multipleImageUpload();
	break;
	case "deleteUser":
	deleteUser();
	break;
	case "emailidCheck":
	emailidCheck();
	break;
	case "usernameCheck":
	usernameCheck();
	break;
	case "getUser":
	getUser();
	break;
	case "statusCheck":
	statusCheck();
	break;
	case "emailTemplateNameCheck":
	emailTemplateNameCheck();
	break;
	case "deleteEmailTemplate":
	deleteEmailTemplate();
	break;
	case "deleteSpeaker":
	deleteSpeaker();
	break;
	case "saveCroppedImage":
	saveCroppedImage();
	break;
	case "changeStatus":
	changeStatus();
	break;
	case "changeSponsorStatus":
	changeSponsorStatus();
	break;
	case "getTemplateData":
	getTemplateData();
	break;
	case "getTemplateSubject":
	getTemplateSubject();
	break;
	case "getSpeakerTemplateModalContent":
	getSpeakerTemplateModalContent();
	break;
	case "getSponsorTemplateModalContent":
	getSponsorTemplateModalContent();
	break;
	case "sponsorTypeCheck":
	sponsorTypeCheck();
	break;
	case "deleteSponsorType":
	deleteSponsorType();
	break;
	case "speakerTypeCheck":
	speakerTypeCheck();
	break;
	case "masterTypeCheck":
	masterTypeCheck();
	break;
	case "deleteSpeakerType":
	deleteSpeakerType();
	break;
	case "deleteMasterType":
	deleteMasterType();
	break;
	case "deleteMaster":
	deleteMaster();
	break;
	case "deleteSponsor":
	deleteSponsor();
	break;
	case "fetchStatusBasedonType":
	fetchStatusBasedonType();
	break;
	case "getSpeakerEmailsSent":
	getSpeakerEmailsSent();
	break;
	case "getSponsorEmailsSent":
	getSponsorEmailsSent();
	break;
	case "getTemplateModalContent":
	getTemplateModalContent();
	break;
	case "viewUser":
	viewUser();
	break;
	case "tenent_url_check":
	tenent_url_check();
	break;
	case "tanent_email_check":
	tanent_email_check();
	break;
	case "email_count_tenant_update":
	email_count_tenant_update();
	break;
	case "tenant_url_check_update":
	tenant_url_check_update();
	break;
	case "deleteTenant":
	deleteTenant();
	break;
	case "add_speaker_note":
	add_speaker_note();
	break;
	case "fetch_speaker_notes_by_id":
	fetch_speaker_notes_by_id();
	break;
	case "update_speaker_note":
	update_speaker_note();
	break;
	case "deleteAction":
	deleteAction();
	break;
	case "deleteActionType":
	deleteActionType();
	break;
	case "actionTypeCheck":
	actionTypeCheck();
	break;
	case "deleteResource":
	deleteResource();
	break;
	case "deleteResourceType":
	deleteResourceType();
	break;
	case "resourceTypeCheck":
	resourceTypeCheck();
	break;
	case "getSpeakerEmailSent_by_id":
	getSpeakerEmailSent_by_id();
	break;
	case "getSpeakerTopEmailSentDetails":
	getSpeakerTopEmailSentDetails();
	break;
	case "getSponsorEmailSent_by_id":
	getSponsorEmailSent_by_id();
	break;
	case "getSponsorTopEmailSentDetails":
	getSponsorTopEmailSentDetails();
	break;
	case "deleteEvent":
	deleteEvent();
	break;
	case "getSpeakerScheduledTopEmailSentDetails":
	getSpeakerScheduledTopEmailSentDetails();
	break;
	case "getScheduledSpeakerTemplateModalContent":
	getScheduledSpeakerTemplateModalContent();
	break;
	case "getSpeakeropportunity":
	getSpeakeropportunity();
	break;
	case "get_count_speaker_details":
	get_count_speaker_details();
	break;
	case "get_count_speaker_type_details":
	get_count_speaker_type_details();
	break;
	case "getMasterEmailsSent":
	getMasterEmailsSent();
	break;
	case "getMasterTemplateModalContent":
	getMasterTemplateModalContent();
	break;
	case "add_new_speaker_note":
	add_new_speaker_note();
	break;
	case "fetch_speaker_notes_by_uniqueid":
	fetch_speaker_notes_by_uniqueid();
	break;
	case "update_new_speaker_note":
	update_new_speaker_note();
	break;
	case "getMasteropportunity":
	getMasteropportunity();
	break;
	case "getMasterScheduledTopEmailSentDetails":
	getMasterScheduledTopEmailSentDetails();
	break;

	case "add_ep_note":
	add_ep_note();
	break;
	case "fetch_ep_notes_by_id":
	fetch_ep_notes_by_id();
	break;
	case "update_ep_note":
	update_ep_note();
	break;
	case "getSpeakerAll":
	getSpeakerAll();
	break;
	case "add_new_sponsor_note":
	add_new_sponsor_note();
	break;
	case "fetch_sponsor_notes_by_uniqueid":
	fetch_sponsor_notes_by_uniqueid();
	break;
	case "update_new_sponsor_note":
	update_new_sponsor_note();
	break;
	case "fetch_sponsor_notes_by_id":
	fetch_sponsor_notes_by_id();
	break;
	case "add_sponsor_note":
	add_sponsor_note();
	break;
	case "update_sponsor_note":
	update_sponsor_note();
	break;
	case "add_new_sponsorship_type":
	add_new_sponsorship_type();
	break;
	case "fetch_sponsorship_added_by_uniqueid":
	fetch_sponsorship_added_by_uniqueid();
	break;
	case "fetch_sponsorship_added_by_id":
	fetch_sponsorship_added_by_id();
	break;
	case "add_sponsorship_type":
	add_sponsorship_type();
	break;
	case "update_sponsorship_type":
	update_sponsorship_type();
	break;
	case "getMasterEmailsSent_preview":
	getMasterEmailsSent_preview();
	break;
	case "get_count_sponsor_details":
	get_count_sponsor_details();
	break;
	case "get_count_sponsortype_details":
	get_count_sponsortype_details();
	break;
	case "getSponsoropportunity":
	getSponsoropportunity();
	break;
	case "getSponsorScheduledTopEmailSentDetails":
	getSponsorScheduledTopEmailSentDetails();
	break;
	case "deleteActionFile":
	deleteActionFile();
	break;
	case "deleteResourceFile":
	deleteResourceFile();
	break;
	case "actionNameCheck":
	actionNameCheck();
	break;
	case "resourceNameCheck":
	resourceNameCheck();
	break;
	case "resourceNameCheck_for_edit":
	resourceNameCheck_for_edit();
	break;

	case "actionNameCheck_for_edit":
	actionNameCheck_for_edit();
	break;
	case "getEPEmailsSent":
	getEPEmailsSent();
	break;
	case "getEPTemplateModalContent":
	getEPTemplateModalContent();
	break;
	case "fetch_all_speaker_for_event_presentation":
	fetch_all_speaker_for_event_presentation();
	break;
	case "fetch_all_speaker_for_event_presentation_new":
	fetch_all_speaker_for_event_presentation_new();
	break;
	case "add_master_note":
	add_master_note();
	break;
	case "fetch_master_notes_by_id":
	fetch_master_notes_by_id();
	break;
	case "update_master_note":
	update_master_note();
	break;
	case "fetch_all_speaker_after_upload":
	fetch_all_speaker_after_upload();
	break;
	case "speaker_upload_proceed":
	speaker_upload_proceed();
	break;
	case "speaker_upload_cancel":
	speaker_upload_cancel();
	break;
	case "speaker_upload_revert":
	speaker_upload_revert();
	break;
	case "get_revert_flag_data":
	get_revert_flag_data();
	break;
	case "fetch_all_sponsor_after_upload":
	fetch_all_sponsor_after_upload();
	break;
	case "sponsor_upload_proceed":
	sponsor_upload_proceed();
	break;
	case "sponsor_upload_cancel":
	sponsor_upload_cancel();
	break;
	case "sponsor_upload_revert":
	sponsor_upload_revert();
	break;
	case "sponsor_get_revert_flag_data":
	sponsor_get_revert_flag_data();
	break;
	case "fetch_all_master_after_upload":
	fetch_all_master_after_upload();
	break;
	case "master_upload_proceed":
	master_upload_proceed();
	break;
	case "master_upload_cancel":
	master_upload_cancel();
	break;
	case "master_upload_revert":
	master_upload_revert();
	break;
	case "master_get_revert_flag_data":
	master_get_revert_flag_data();
	break;
	case "StatusNameCheck":
	StatusNameCheck();
	break;
	case "StatusNameCheck_for_edit":
	StatusNameCheck_for_edit();
	break;
	case "speaker_type_NameCheck":
	speaker_type_NameCheck();
	break;
	case "speaker_type_NameCheck_for_edit":
	speaker_type_NameCheck_for_edit();
	break;
	case "master_type_Check":
	master_type_Check();
	break;
	case "master_type_Check_for_edit":
	master_type_Check_for_edit();
	break;
	case "speaker_email_check":
	speaker_email_check();
	break;
	case "speaker_email_check_for_edit":
	speaker_email_check_for_edit();
	break;
	case "master_email_check":
	master_email_check();
	break;
	case "master_email_check_for_edit":
	master_email_check_for_edit();
	break;
	case "check_sponsor_contact_email_address":
	check_sponsor_contact_email_address();
	break;
	case "fetch_speakers_for_popup":
	fetch_speakers_for_popup();
	break;
	case "fetch_sponsors_for_popup":
	fetch_sponsors_for_popup();
	break;
	case "fetch_masters_for_popup":
	fetch_masters_for_popup();
	break;
	case "fetch_speakers_for_total_spk_listing":
	fetch_speakers_for_total_spk_listing();
	break;
	case "fetch_speakers_for_total_sponsor_listing":
	fetch_speakers_for_total_sponsor_listing();
	break;
	case "fetch_email_templates_for_popup":
	fetch_email_templates_for_popup();
	break;
	case "fetch_all_approved_speaker":
	fetch_all_approved_speaker();
	break;

	case "fetch_all_approved_speaker_search":
	fetch_all_approved_speaker_search();
	break;

	case "fetch_all_approved_speaker_pagination":
	fetch_all_approved_speaker_pagination();
	break;


	case "add_new_coloboration_note":
	add_new_coloboration_note();
	break;
	case "fetch_coloboration_notes_by_uniqueid":
	fetch_coloboration_notes_by_uniqueid();
	break;
	case "update_new_coloboration_note":
	update_new_coloboration_note();
	break;
	case "update_ep_colb_note":
	update_ep_colb_note();
	break;
	case "fetch_ep_coloboration_notes_by_id":
	fetch_ep_coloboration_notes_by_id();
	break;
	case "add_ep_colloboration_note":
	add_ep_colloboration_note();
	break;

	

}


function fetch_all_approved_speaker(){

	$connect = $GLOBALS['connect'];
	$event_id =  $_POST['event_id'];
	$status_id = $_POST['spk_status_id'];

	$start =  $_POST['start'];
	$limit = $_POST['limit'];

	// $fetch_notes = mysqli_query($connect,"SELECT * FROM all_speakers WHERE `status` = '".$status_id."' AND `event_id` = '".$event_id."' LIMIT $start, $limit ");

	$fetch_notes = mysqli_query($connect,"SELECT * FROM all_speakers WHERE `status` = '".$status_id."' AND `event_id` = '".$event_id."' ");

	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}


function fetch_all_approved_speaker_pagination(){

	$connect = $GLOBALS['connect'];
	$event_id =  $_POST['event_id'];
	$adjacents = $_POST['adjacents'];

	$page =  $_POST['page'];
	$targetpage =  $_POST['targetpage'];
	$limit = $_POST['limit'];
	
			$fetch_all_speakers_temp = "SELECT * FROM all_speakers als WHERE event_id = '".$event_id."' AND status IN(select id from all_status where status_for = 'speaker' and event_id = '".$event_id."' and status_name='Approved')  ORDER BY id DESC";

			$event_sql = mysqli_query($connect,"SELECT count(*) as total_count FROM all_speakers als WHERE event_id = '".$event_id."' AND status IN(select id from all_status where status_for = 'speaker' and event_id = '".$event_id."' and status_name='Approved')  ORDER BY id DESC");
	       $event_row = mysqli_fetch_array($event_sql);

			$total_pages =  $event_row['total_count'];

			//your file name  (the name of this file)
			
			if($page)
				$start = ($page - 1) * $limit;          //first item to display on this page
			else
				$start = 0;                             //if no page var is given, set start to 0

			/* Get data. */
			$sql = $fetch_all_speakers_temp." LIMIT $start, $limit";



			$result = mysqli_query($connect,$sql);

			/* Setup page vars for display. */
			if ($page == 0) $page = 1;                  //if no page var is given, default to 1.
			$prev = $page - 1;                          //previous page is page - 1
			$next = $page + 1;                          //next page is page + 1
			$lastpage = ceil($total_pages/$limit);      //lastpage is = total pages / items per page, rounded up.
			$lpm1 = $lastpage - 1;                      //last page minus 1

			$initial=$start+1;
			$upto=$limit*$page;

			if($total_pages<10)
			{
			$upto=$total_pages;	
			}

			if($upto>$total_pages)
			{
			$upto=$total_pages;	
			}
			/*
				Now we apply our rules and draw the pagination object.
				We're actually saving the code to a variable in case we want to draw it more than once.
			*/
			$pagination = "";
			
			if($lastpage > 0)
			{
				$pagination .= "Showing $initial to $upto of $total_pages entries<div class=\"pagination dataTables_paginate paging_simple_numbers\" id=\"datatable_paginate\">";
				//previous button
				if ($page > 1)
					$pagination.= "<a href=\"$targetpage&page=$prev\" class=\"paginate_button previous\">Previous</a>";
				else
					$pagination.= "<span class=\"disabled paginate_button previous\">Previous</span>";

				//pages
				if ($lastpage < 7 + ($adjacents * 2))    //not enough pages to bother breaking it up
				{
					for ($counter = 1; $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current paginate_button \">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&page=$counter\" class=\"paginate_button \">$counter</a>";
					}
				}
				elseif($lastpage > 5 + ($adjacents * 2)) //enough pages to hide some
				{
					//close to beginning; only hide later pages
					if($page < 1 + ($adjacents * 2))
					{
						for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
						{
							if ($counter == $page)
								$pagination.= "<span class=\"current paginate_button \">$counter</span>";
							else
								$pagination.= "<a href=\"$targetpage&page=$counter\" class=\"paginate_button \">$counter</a>";
						}
						$pagination.= "...";
						$pagination.= "<a href=\"$targetpage&page=$lpm1\" class=\"paginate_button \">$lpm1</a>";
						$pagination.= "<a href=\"$targetpage&page=$lastpage\" class=\"paginate_button \">$lastpage</a>";
					}
					//in middle; hide some front and some back
					elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
					{
						$pagination.= "<a href=\"$targetpage&page=1\" class=\"paginate_button \">1</a>";
						$pagination.= "<a href=\"$targetpage&page=2\" class=\"paginate_button \">2</a>";
						$pagination.= "...";
						for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<span class=\"current paginate_button\">$counter</span>";
							else
								$pagination.= "<a href=\"$targetpage&page=$counter\" class=\"paginate_button \">$counter</a>";
						}
						$pagination.= "...";
						$pagination.= "<a href=\"$targetpage&page=$lpm1\" class=\"paginate_button \">$lpm1</a>";
						$pagination.= "<a href=\"$targetpage&page=$lastpage\" class=\"paginate_button \">$lastpage</a>";
					}
					//close to end; only hide early pages
					else
					{
						$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
						$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
						$pagination.= "...";
						for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
						{
							if ($counter == $page)
								$pagination.= "<span class=\"current paginate_button\">$counter</span>";
							else
								$pagination.= "<a href=\"$targetpage&page=$counter\" class=\"paginate_button \">$counter</a>";
						}
					}
				}


				//next button
				if ($page < $counter - 1)
					$pagination.= "<a href=\"$targetpage&page=$next\">Next</a>";
				else
					$pagination.= "<span class=\"disabled \">Next</span>";
				$pagination.= "</div>\n";
			}

			$final_data_array = array();
			$final_data_array["pagination"]= $pagination;
			$final_data_array["start"]= $start;

			echo  json_encode($final_data_array);

	 

}




function fetch_all_approved_speaker_search(){

	$connect = $GLOBALS['connect'];
	$event_id =  $_POST['event_id'];
	$status_id = $_POST['spk_status_id'];
	$searchval = $_POST['searchval'];
	//company

	$fetch_notes = mysqli_query($connect,"SELECT * FROM all_speakers WHERE (`speaker_name` LIKE '%".$searchval."%' OR `company` LIKE '%".$searchval."%' OR `title` LIKE '%".$searchval."%'  ) AND `status` = '".$status_id."' AND `event_id` = '".$event_id."'   ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}




function multipleImageUpload(){
	$uploadedImages="";
	$result="";
	$connect = $GLOBALS['connect'];
	if (!isset($_FILES['image']['tmp_name'])) {
		$profile_pic = "";
	}
	else{
		$alphas = range('A', 'Z');
		
		$i=0;$txt = "";
		$user_id = $_POST['user_id'];
		foreach($_FILES['image']['tmp_name'] as $key => $tmp_name ){
			    $file = $_FILES['image']['name'][$key];
				$image_name = addslashes($file);
				$extension = pathinfo($image_name, PATHINFO_EXTENSION);
				$bannerImage = pathinfo($image_name, PATHINFO_FILENAME)."-".rand().".".$extension;
				$extension = strtolower(trim($extension));
				$banner_pic = $bannerImage;	
				move_uploaded_file($_FILES["image"]["tmp_name"][$key],"documents/" . $bannerImage);
				$file = str_replace(".","",$bannerImage);
				$id = $_POST['id'];
				if($extension=="avi" || $extension=="mp4" || $extension=="mov"){
					$tag = "<video autobuffer controls autoplay style='width:100%'><source id='mp4' src='documents/".$bannerImage."' type='video/mp4' ></video>";
					$result .="<div class='col-lg-6 col-md-6  imgPreview' style='text-align:center' id='uploadedImage_".$id."'><center>".$tag."".$_FILES["image"]["name"][$key]."<br><br><input type='hidden' name='all_docs_names[]' value='".$bannerImage."' /><a class='btn btn-primary btn-sm remove' onClick='$(\"#uploadedImage_".$id."\").remove();uploadedCount--;$(\"#all_docs_names_removed\").val($(\"#all_docs_names_removed\").val()+\",\"+\"".$bannerImage."\")' removeAtrib='uploadedImage_".$id."' removeId='".$id."' >Remove</a></center><br></div>";
				}elseif($extension=="pdf"){
					$tag = "<img class='thumbnail' src='documents/pdf.jpg' style='width:120px;cursor:pointer' onclick=\"window.open('documents/".$bannerImage."')\" />";
					$result .="<div class='col-lg-2 col-md-2 col-sm-4 col-xs-12  imgPreview' style='text-align:center'  id='uploadedImage_".$id."'><center>".$tag."".$_FILES["image"]["name"][$key]."<br><br><input type='hidden' name='all_docs_names[]' value='".$bannerImage."' /><a class='btn btn-primary btn-sm remove' onClick='$(\"#uploadedImage_".$id."\").remove();uploadedCount--;$(\"#all_docs_names_removed\").val($(\"#all_docs_names_removed\").val()+\",\"+\"".$bannerImage."\")' removeAtrib='uploadedImage_".$id."' removeId='".$id."' >Remove</a></center><br></div>";
				}elseif($extension=="mp3"){
					$tag = "<img class='thumbnail' src='documents/mp3.jpg' style='width:120px;cursor:pointer' onclick=\"window.open('documents/".$bannerImage."')\" />";
					$result .="<div class='col-lg-2 col-md-2 col-sm-4 col-xs-12  imgPreview' style='text-align:center'  id='uploadedImage_".$id."'><center>".$tag."".$_FILES["image"]["name"][$key]."<br><br><input type='hidden' name='all_docs_names[]' value='".$bannerImage."' /><a class='btn btn-primary btn-sm remove' onClick='$(\"#uploadedImage_".$id."\").remove();uploadedCount--;$(\"#all_docs_names_removed\").val($(\"#all_docs_names_removed\").val()+\",\"+\"".$bannerImage."\")' removeAtrib='uploadedImage_".$id."' removeId='".$id."' >Remove</a></center><br></div>";
				}elseif($extension=="doc" || $extension=="docx" ||$extension=="txt"){
					$tag = "<img class='thumbnail' src='documents/word.png' style='width:120px;cursor:pointer' onclick=\"window.open('documents/".$bannerImage."')\" />";
					$result .="<div class='col-lg-2 col-md-2 col-sm-4 col-xs-12  imgPreview' style='text-align:center'  id='uploadedImage_".$id."'><center>".$tag."".$_FILES["image"]["name"][$key]."<br><br><input type='hidden' name='all_docs_names[]' value='".$bannerImage."' /><a class='btn btn-primary btn-sm remove' onClick='$(\"#uploadedImage_".$id."\").remove();uploadedCount--;$(\"#all_docs_names_removed\").val($(\"#all_docs_names_removed\").val()+\",\"+\"".$bannerImage."\")' removeAtrib='uploadedImage_".$id."' removeId='".$id."' >Remove</a></center><br></div>";
				}elseif($extension=="xlsx" || $extension=="xls" || $extension=="csv" ){
					$tag = "<img class='thumbnail' src='documents/xlsx.png' style='width:120px;cursor:pointer' onclick=\"window.open('documents/".$bannerImage."')\" />";
					$result .="<div class='col-lg-2 col-md-2 col-sm-4 col-xs-12  imgPreview' style='text-align:center'  id='uploadedImage_".$id."'><center>".$tag."".$_FILES["image"]["name"][$key]."<br><br><input type='hidden' name='all_docs_names[]' value='".$bannerImage."' /><a class='btn btn-primary btn-sm remove' onClick='$(\"#uploadedImage_".$id."\").remove();uploadedCount--;$(\"#all_docs_names_removed\").val($(\"#all_docs_names_removed\").val()+\",\"+\"".$bannerImage."\")' removeAtrib='uploadedImage_".$id."' removeId='".$id."' >Remove</a></center><br></div>";
				}
				else{
					$tag = "<img class='thumbnail' src='documents/".$bannerImage."' style='width:200px;' />";
					$result .="<div class='col-lg-3 col-md-3 col-sm-3 col-xs-12  imgPreview'  style='text-align:center'  id='uploadedImage_".$id."'><center>".$tag."".$_FILES['image']['name'][$key]."<br><br><input type='hidden' name='all_docs_names[]' value='".$bannerImage."' /><a class='btn btn-primary btn-sm remove' onClick='$(\"#uploadedImage_".$id."\").remove();uploadedCount--;$(\"#all_docs_names_removed\").val($(\"#all_docs_names_removed\").val()+\",\"+\"".$bannerImage."\")' removeAtrib='uploadedImage_".$id."' removeId='".$id."' >Remove</a></center><br></div>";
				}
				
				
				  

				
		}
	}
	echo $result ;
}



function websiteUrl($website_url){
	if(strpos($website_url, "ttp://") || strpos($website_url, "ttps://")) $website_url = $website_url;
		else $website_url = "http://$website_url";
		return $website_url;
}

function deleteUser(){
	if(!isset($_SESSION)){ session_start(); }
	$created_by= $_SESSION['user_id'];
	$connect = $GLOBALS['connect'];
	$id= mysqli_real_escape_string($connect, $_POST['id']);
	$fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_users where user_id='".$created_by."' ");   
    $res_sql = mysqli_fetch_array($fetch_sql);
    $tanent_id= $res_sql['tanent_id'];

    $sql_f = mysqli_query($connect,"select * from all_users where tanent_id='".$tanent_id."'");
	$number_of_users=mysqli_num_rows($sql_f);
	if($number_of_users>1)
	{
		 $sql_query_log="DELETE FROM all_users WHERE user_id=".$id;
		 mysqli_query($connect,$sql_query_log);
		 mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$tanent_id."','0','Delete User','".$id."','".$created_by."',now(),\"".$sql_query_log."\")");
		 echo 'success';	
	}else
	{
		echo 'failed';	
	}
   
	
}
function emailidCheck(){
	if(!isset($_SESSION)){ session_start(); }
	$created_by= $_SESSION['user_id'];
	$connect = $GLOBALS['connect'];
	$fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_users where user_id='".$created_by."' ");   
    $res_sql = mysqli_fetch_array($fetch_sql);
    $tanent_id= $res_sql['tanent_id'];

	if(isset($_POST['emailID']) && !isset($_POST['id'])){
		$email = mysqli_real_escape_string($connect, $_POST['emailID']);
		$sql = mysqli_query($connect,"select * from all_users where email='".$email."' AND tanent_id='".$tanent_id."'");
		$email_count=mysqli_num_rows($sql);
		if($email_count=='0')
		{
			$sql1 = mysqli_query($connect,"select * from all_users where email='".$email."'");
			$email_count1=mysqli_num_rows($sql1);
			if($email_count1>0)
			{
				$another_tenant1=2;
			}else
			{
				$another_tenant1=0;
			}
			echo $another_tenant1;
		}else
		{
			echo $email_count;
		}
	}else{
		$email=$_POST['emailID'];
		$id=$_POST['id'];
		$sql = mysqli_query($connect,"select * from all_users where email='".$email."' AND user_id!=".$id."");
		$email_count=mysqli_num_rows($sql);
		if($email_count=='0')
		{
			$sql1 = mysqli_query($connect,"select * from all_users where email='".$email."' AND tanent_id!='".$tanent_id."'");
			$email_count1=mysqli_num_rows($sql1);
			if($email_count1>0)
			{
				$another_tenant1=2;
			}else
			{
				$another_tenant1=0;
			}
			echo $another_tenant1;
		}else
		{
			echo $email_count;
		}
	}
}

function usernameCheck(){
	$connect = $GLOBALS['connect'];
	if(isset($_POST['username'])){
		$username =  mysqli_real_escape_string($connect, $_POST['username']);
		$sql = mysqli_query($connect,"select * from all_users where email='".$username."'");
		echo $username_count=mysqli_num_rows($sql);
	}
}

function statusCheck(){
	$connect = $GLOBALS['connect'];
	$status =  mysqli_real_escape_string($connect, $_POST['status']);
	$type =  mysqli_real_escape_string($connect, $_POST['type']);
	$sql = mysqli_query($connect,"select * from all_status where status_name='".$status."' AND status_for='".$type."'");
	echo $count = mysqli_num_rows($sql);
}



function emailTemplateNameCheck(){
	$connect = $GLOBALS['connect'];

	if(!isset($_SESSION)){ session_start(); }
		$event_id= $_SESSION['current_event_id'];	

	$template_name =  mysqli_real_escape_string($connect, $_POST['template_name']);
	$template_id =  mysqli_real_escape_string($connect, $_POST['template_id']);
	if(empty($template_id)){
		$template_id = 0;
	}
	$sql = mysqli_query($connect,"select * from all_email_templates where template_name='".$template_name."' AND event_id = '".$event_id."' AND id!=".$template_id);
	echo $count=mysqli_num_rows($sql);
}
 
function deleteEmailTemplate(){
	if(!isset($_SESSION)){ session_start(); }
		$created_by= $_SESSION['user_id'];

	 $connect = $GLOBALS['connect'];
	 $id1 = mysqli_real_escape_string($connect, $_POST['id']);
	 $event_id_enc = trim($id1);
     $event_id_exp = explode(':',$event_id_enc);
     $id = base64_decode($event_id_exp[0]);
     $eventid = base64_decode($event_id_exp[1]);

     $fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$eventid."' ");       
     $res_sql = mysqli_fetch_array($fetch_sql);
     $session_tanent_id=$res_sql['tanent_id'];


     $fetch_sql_evt = mysqli_query($connect,"SELECT event_id from all_email_templates where id='".$id."' ");       
     $res_sql_evt = mysqli_fetch_array($fetch_sql_evt);
     $event_id_fetched=$res_sql_evt['event_id'];

     if($event_id_fetched!='all')
     {
     	$sql_query_log="DELETE from all_email_templates where id='".$id."'";
		mysqli_query($connect,"DELETE from all_email_templates where id=".$id);
     }

      $check_temp_exist = mysqli_query($connect, "SELECT * FROM `all_email_template_usage_info` WHERE `event_id` = '".$eventid."' AND template_id = '".$id."' ");
                if(mysqli_num_rows($check_temp_exist)> 0){
                    $update_template_details = mysqli_query($connect, "UPDATE `all_email_template_usage_info` SET `is_delete`='1' WHERE `event_id` = '".$eventid."' AND template_id = '".$id."'");
                }else{
				     $insert_template_details = mysqli_query($connect, "INSERT INTO `all_email_template_usage_info` (tanent_id,event_id,template_id,total_usage,total_read,is_delete) VALUES ('$session_tanent_id','$eventid','$id','0','0','1')"); 
				 }

	// $sql_query_log="DELETE from all_email_templates where id='".$id."'";

	// mysqli_query($connect,"DELETE from all_email_templates where id=".$id);

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$eventid."','Delete Email Template','".$id."','".$created_by."',now(),\"".$sql_query_log."\")");

	echo base64_encode($eventid).':'.base64_encode(rand(100,999));
	
}


function deleteSpeaker(){

	if(!isset($_SESSION)){ session_start(); }
	$logged_in_user= $_SESSION['user_id'];	

	 $connect = $GLOBALS['connect'];
	 $id1 = mysqli_real_escape_string($connect, $_POST['id']);
	 $event_id_enc = trim($id1);
     $event_id_exp = explode(':',$event_id_enc);
     $id = base64_decode($event_id_exp[0]);
     $event_id = base64_decode($event_id_exp[1]);

     $fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
     $res_sql = mysqli_fetch_array($fetch_sql);
     $session_tanent_id=$res_sql['tanent_id'];

	$sql = "DELETE from all_speakers where id='".$id."'";
	$delete_speaker = mysqli_query($connect,$sql);

	$all_speakers_array = calculate_speaker_dashboard_count($event_id);
	$speakers_data1 = mysqli_query($connect,"SELECT group_concat(id) as status_id FROM all_status WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($speakers_data1) > 0)
            {  
                $res1 = mysqli_fetch_array($speakers_data1);
                $row_id = $res1['status_id'];
                $status_ids_array1 = explode(",",$row_id);

                foreach ($status_ids_array1 as $statusid) { 
                if($statusid!=0)
                {

                    $query_sql_sp = mysqli_query($connect,"SELECT count(*) as count_spk FROM all_speakers WHERE all_speakers.status='".$statusid."' and all_speakers.event_id='".$event_id."'");
                    $query_res_sp = mysqli_fetch_array($query_sql_sp);
                    $count_spk_res = mysqli_real_escape_string($connect,$query_res_sp['count_spk']);
                
                    $update_status_details = mysqli_query($connect, "UPDATE `all_status` SET `count_of_speaker_usage`='".$count_spk_res."'   WHERE id=".$statusid);

                }

             }
           }

            $speakers_data2 = mysqli_query($connect,"SELECT group_concat(id) as type_id FROM all_speaker_types WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($speakers_data2) > 0)
            {  
                $res2 = mysqli_fetch_array($speakers_data2);
                $row_id2 = $res2['type_id'];
                $status_ids_array2 = explode(",",$row_id2);

                foreach ($status_ids_array2 as $typeid2) { 
                if($typeid2!=0)
                {

                    $query_sql_sp2 = mysqli_query($connect,"SELECT count(*) as count_spk FROM all_speakers WHERE find_in_set('".$typeid2."',all_speakers.speaker_type) and all_speakers.event_id='".$event_id."'");
                    $query_res_sp2 = mysqli_fetch_array($query_sql_sp2);
                    $count_spk_res2 = mysqli_real_escape_string($connect,$query_res_sp2['count_spk']);
                
                    $update_status_details2 = mysqli_query($connect, "UPDATE `all_speaker_types` SET `count_of_speaker_usage`='".$count_spk_res2."'   WHERE id=".$typeid2);

                }

             }
           }

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','delete speaker','".$id."','".$logged_in_user."',now(),\"".$sql."\")");

	echo base64_encode($event_id).':'.base64_encode(rand(100,999));
	
}

function convertAndSaveImages($filesArr,$heading){
	$i=0;$allFileNames = "";
	foreach($filesArr as $fileData){
		if($fileData){
			if(strpos($fileData, ';base64') !== false){
				$data = $fileData;
				if($data){
					list($type, $data) = explode(';', $data);
					list(, $data)      = explode(',', $data);
					$data = base64_decode($data);
					$heading = preg_replace('/[^A-Za-z0-9\-]/', '', $heading);
					$rand = rand().$i;
					$allFileNames .= $file_name = $heading.'_'.$rand.'.jpg';
					file_put_contents('images/'.$file_name, $data);
					$allFileNames .= "~";
					$i++;
					
				}
				
			}else{
				$allFileNames .= $fileData;
				$allFileNames .= "~";
				
			}
			
		}
	}
	return rtrim($allFileNames,"~");
}

function saveCroppedImage(){
	session_start();
	$connect = $GLOBALS['connect'];
	$img_data = $_POST['img_data'];
	$site_url = $_SESSION['site_url'];
	echo $file_name = $site_url."/images/".convertAndSaveImages(array($img_data),"email_banner");
	
}
 
function changeStatus(){
	$connect = $GLOBALS['connect'];
	$id_user = $GLOBALS['id_user'];
	$speaker_id = mysqli_real_escape_string($connect, $_POST['speaker_id']);
	$status_id = mysqli_real_escape_string($connect, $_POST['status_id']);
	$sql = "UPDATE all_speakers SET status = '".$status_id."' where id=".$speaker_id;
	mysqli_query($connect,$sql);
	mysqli_query($connect, "INSERT INTO all_logs(operation,table_id,table_name,other_column_name,other_column_value,created_by,sql_qry) VALUES ('update speaker status','".$speaker_id."','all_speakers','status_id','".$status_id."','".$id_user."',\"".$sql."\")");
	
	
}
 function changeSponsorStatus(){
	$connect = $GLOBALS['connect'];
	$id_user = $GLOBALS['id_user'];
	$sponsor_id = mysqli_real_escape_string($connect, $_POST['sponsor_id']);
	$status_id = mysqli_real_escape_string($connect, $_POST['status_id']);
	$sql = "UPDATE all_sponsors SET status = '".$status_id."' where id=".$sponsor_id;
	mysqli_query($connect,$sql);
	mysqli_query($connect, "INSERT INTO all_logs(operation,table_id,table_name,other_column_name,other_column_value,created_by,sql_qry) VALUES ('update sponsor status','".$sponsor_id."','all_sponsors','status_id','".$status_id."','".$id_user."',\"".$sql."\")");
	
	
}
 
function getTemplateData(){
	$connect = $GLOBALS['connect'];
	$template_id = mysqli_real_escape_string($connect, $_POST['template_id']);
	$sql_all_email_templates = mysqli_query($connect,"SELECT * FROM all_email_templates WHERE id=".$template_id);
    $all_email_templates = mysqli_fetch_assoc($sql_all_email_templates);
	echo $all_email_templates['template_data'];
	
	
}

function getTemplateSubject(){
	$connect = $GLOBALS['connect'];
	$template_id = mysqli_real_escape_string($connect, $_POST['template_id']);
	$sql_all_email_templates = mysqli_query($connect,"SELECT * FROM all_email_templates WHERE id=".$template_id);
    $all_email_templates = mysqli_fetch_assoc($sql_all_email_templates);
	echo $all_email_templates['template_subject'];
	
	
}

function getSpeakerTemplateModalContent(){
	$connect = $GLOBALS['connect'];
	$log_table_id = mysqli_real_escape_string($connect, $_POST['log_table_id']);
	$sql_all_logs = mysqli_query($connect,"SELECT * FROM all_logs LEFT JOIN all_email_templates ON all_email_templates.id = all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by WHERE all_logs.id=".$log_table_id);
    $all_logs = mysqli_fetch_assoc($sql_all_logs);
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><img src="images/cancel.png" width="20"></button>
         <h4 class="modal-title">'.$all_logs['template_name'].'</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">';
	  $cc = $all_logs['cc_emails'];
	  $speaker_manager_email = $all_logs['speaker_manager_email'];
	  $email_subject = $all_logs['email_subject'];
	  if(!$cc) $cc = " Not Found ";
	  if(!$speaker_manager_email) $speaker_manager_email = " Not Found ";
	  if(!$email_subject) $email_subject = " Not Found ";
	  if($all_logs['email_content']){
		  
        echo ' <br>
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-6"><label>Email Subject: </label><br><span style="font-weight:normal">'.$email_subject.'</span></div>
            <div class="col-xs-6"><label>Speaker Manager Email Address: </label><br><span style="font-weight:normal">'.$speaker_manager_email.'</span></div>
           
         </div>
		 <br>
         <div class="row clear-fix" style="margin-bottom:30px">
            <div class="col-xs-6"><label>Cc Email Address: </label><br><span style="font-weight:normal">'.$cc.'</span></div>
           
         </div>
        
       
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-12"><label>Email Content </label><br></div>
            <div class="col-xs-12"><div class="row clear-fix" style="border: 1px solid #5254568c;margin: 24px;padding: 12px;margin:0px">
				<span style="font-weight:normal">'.$all_logs['email_content'].'</span>
			</div>
			</div>
            <br><br>
         </div>
      </div>
   </div>
         ';
	  }else{
		 echo ' <br>
         <div class="row  clear-fix" style="margin-bottom:30px">
         <center>This feature is implemented on 20th Dec 2018, Previously sent email notifications are not captured properly, so please try to send new notifications and check it!</center>
           
         </div>
		 
        
      </div>
   </div>
         ';
	  }
}

function getMasterTemplateModalContent(){
	$connect = $GLOBALS['connect'];
	$log_table_id = mysqli_real_escape_string($connect, $_POST['log_table_id']);
	// var_dump("arkaa: ".$log_table_id); exit();
	$sql_all_logs = mysqli_query($connect,"SELECT * FROM all_logs LEFT JOIN all_email_templates ON all_email_templates.id = all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by WHERE all_logs.id=".$log_table_id);
    $all_logs = mysqli_fetch_assoc($sql_all_logs);
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><img src="images/cancel.png" width="20"></button>
         <h4 class="modal-title">'.$all_logs['template_name'].'</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">';
	  $cc = $all_logs['cc_emails'];
	  $speaker_manager_email = $all_logs['speaker_manager_email'];
	  $email_subject = $all_logs['email_subject'];
	  if(!$cc) $cc = " Not Found ";
	  //if(!$speaker_manager_email) $speaker_manager_email = " Not Found ";
	  if(!$email_subject) $email_subject = " Not Found ";
	  if($all_logs['email_content']){
		  
        echo ' <br>
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-6"><label>Email Subject: </label><br><span style="font-weight:normal">'.$email_subject.'</span></div>           
           
         </div>
		 <br>
         <div class="row clear-fix" style="margin-bottom:30px">
            <div class="col-xs-6"><label>Cc Email Address: </label><br><span style="font-weight:normal">'.$cc.'</span></div>           
         </div>
        
       
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-12"><label>Email Content </label><br></div>
            <div class="col-xs-12"><div class="row clear-fix" style="border: 1px solid #5254568c;margin: 24px;padding: 12px;margin:0px">
				<span style="font-weight:normal">'.$all_logs['email_content'].'</span>
			</div>
			</div>
            <br><br>
         </div>
      </div>
   </div>
         ';
	  }else{
		 echo ' <br>
         <div class="row  clear-fix" style="margin-bottom:30px">
         <center>This feature is implemented on 20th Dec 2018, Previously sent email notifications are not captured properly, so please try to send new notifications and check it!</center>
           
         </div>
		 
        
      </div>
   </div>
         ';
	  }
}

 
 function getSponsorTemplateModalContent(){
	$connect = $GLOBALS['connect'];
	$log_table_id = mysqli_real_escape_string($connect, $_POST['log_table_id']);
	$sql_all_logs = mysqli_query($connect,"SELECT * FROM all_logs LEFT JOIN all_email_templates ON all_email_templates.id = all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by WHERE all_logs.id=".$log_table_id);
    $all_logs = mysqli_fetch_assoc($sql_all_logs);
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">'.$all_logs['template_name'].'</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">';
	  $cc = $all_logs['cc_emails'];
	  $email_subject = $all_logs['email_subject'];
	  if(!$cc) $cc = " Not Found ";
	  if(!$email_subject) $email_subject = " Not Found ";
	  if($all_logs['email_content']){
		  
        echo '<br>
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-6"><label>Email Subject: </label><br><span style="font-weight:normal">'.$email_subject.'</span></div>
             <div class="col-xs-6"><label>Cc Email Address: </label><br><span style="font-weight:normal">'.$cc.'</span></div>
           
         </div>
		 <br>
               
       
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-12"><label>Email Content </label><br></div>
            <div class="col-xs-12"><div class="row clear-fix" style="border: 1px solid #5254568c;margin: 24px;padding: 12px;margin:0px">
				<span style="font-weight:normal">'.$all_logs['email_content'].'</span>
			</div>
			</div>
            <br><br>
         </div>
      </div>
   </div>
         ';
	  }else{
		 echo '<br>
         <div class="row  clear-fix" style="margin-bottom:30px">
         <center>This feature is implemented on 20th Dec 2018, Previously sent email notifications are not captured properly, so please try to send new notifications and check it!</center>
           
         </div>
		 
        
      </div>
   </div>
         ';
	  }
	
	
	
}
 
function getSpeakerEmailsSent(){
$connect = $GLOBALS['connect'];
$id = mysqli_real_escape_string($connect,$_POST['id']);

$all_logs_array = mysqli_query($connect,"SELECT all_logs.*,all_users.*,all_logs.id as idd,all_email_templates.id,all_logs.operation as tempname,all_email_templates.template_name FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE (all_logs.operation='sent email to speaker' OR all_logs.operation='sent email to speaker scheduled' OR all_logs.operation='sent email to speaker Event Presentation') AND all_logs.table_id='".$id."'  
	union
	SELECT all_logs.*,all_users.*,all_logs.id as idd,0 as id,all_logs.operation as tempname ,'Missing Information' as template_name FROM all_logs  LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE (all_logs.operation='request missing information' OR all_logs.operation='request missing documents' OR all_logs.operation='request missing information scheduled' OR all_logs.operation='request missing documents scheduled') AND all_logs.table_id='".$id."' ");

$content =' <div class="">
                    <table id="datatable" class="table table-bordered test1 table-responsive" style="width:100%">
                       <thead><tr><th>Email Subject</th><th>Sent By</th><th>Date</th><th>Action</th></tr></thead><tbody>';
while($all_logs = mysqli_fetch_array($all_logs_array)){
	if($all_logs['template_name']=='Missing Information')
	{
		if($all_logs['tempname']=='request missing information')
		{
			$template_name = "<p>".ucfirst($all_logs['tempname'])."</p>";	
		}else
		{
			$template_name = "<p>".ucfirst($all_logs['tempname'])."</p>";
		}
		
	}else
	{
		$template_name = "<a href='#' onclick='speakerTemplateModal1(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";
	}

$read = "";
if($all_logs['email_read']=='y') {
$read = '<span class="opened" >Opened</span>';
}else{
$read = '<span class="not_opened" >Not Opened</span>';
}
$content .="<tr>
<td>".$template_name."</td>	
<td>".$all_logs['first_name']."</td>
<td>".date('d-M-Y', strtotime($all_logs['created_at']))."</td>
<td>".$read."</td>
</tr>";
}
echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
  <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
  </button> <!-- Modal content-->
  <div class="modal-content">
     <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><img src="images/cancel.png" width="20"></button>
        <h4 class="modal-title">Previous Emails List</h4>
     </div>
     <div class="custom-modal-text " id="modal_content">
 '.$content.'</tbody></table></div>
 
     </div>
  </div>';	
}

function getMasterEmailsSent(){

$connect = $GLOBALS['connect'];
$id = mysqli_real_escape_string($connect,$_POST['id']);

$all_logs_array = mysqli_query($connect,"SELECT all_logs.*,all_users.*,all_logs.id as idd,all_email_templates.id,all_logs.operation as tempname,all_email_templates.template_name FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE (all_logs.operation='sent email to master' OR all_logs.operation='sent email to master scheduled') AND all_logs.table_id='".$id."' 
	union
	SELECT all_logs.*,all_users.*,all_logs.id as idd,0 as id,all_logs.operation as tempname ,'Missing Information' as template_name FROM all_logs  LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE (all_logs.operation='request missing information master') AND all_logs.table_id='".$id."' ");

$content =' <div class="">
                    <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                       <thead><tr><th>Email Subject</th><th>Sent By</th><th>Date</th><th>Action</th></tr></thead>
                       <tbody>';
while($all_logs = mysqli_fetch_array($all_logs_array)){
		if($all_logs['template_name']=='Missing Information')
	{
		if($all_logs['tempname']=='request missing information')
		{
			$template_name = "<p>".ucfirst($all_logs['tempname'])."</p>";	
		}else
		{
			$template_name = "<p>".ucfirst($all_logs['tempname'])."</p>";
		}
		
	}else
	{
		$template_name = "<a href='#' onclick='masterTemplateModal(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";
		}
$read = "";
if($all_logs['email_read']=='y') {
$read = '<span class="opened">Opened</span>';
}else{
$read = '<span class="not_opened">Not opened</span>';
}
$content .="<tr>
<td>".$template_name."</td>	
<td>".$all_logs['first_name']."</td>
<td> ".date('d-M-Y', strtotime($all_logs['created_at']))."</td>
<td> ".$read."</td>
</tr>";
}
echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
  <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
  </button> <!-- Modal content-->
  <div class="modal-content">
     <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><img src="images/cancel.png" width="20"></button>
        <h4 class="modal-title">Previous Emails List</h4>
     </div>
     <div class="custom-modal-text " id="modal_content">
 '.$content.'</tbody></table></div>
 
     </div>
  </div>';



}


function getSpeakerEmailSent_by_id(){
	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['template_id']);
	$event_id= mysqli_real_escape_string($connect,$_POST['event_id']);
	$limit= mysqli_real_escape_string($connect,$_POST['limit']);		

	if($id != '9998' || $id != '9999')
	{
	$all_logs_array = mysqli_query($connect,"SELECT *,all_logs.id as idd,all_speakers.email_id as speaker_email FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_speakers ON all_speakers.id=all_logs.table_id  WHERE (all_logs.operation='sent email to speaker' OR all_logs.operation='sent email to speaker Event Presentation') AND all_logs.event_id='".$event_id."' AND all_logs.other_column_value='".$id."' AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC Limit ".$limit);
	}
	 if($id == '9998')
	{
	$all_logs_array = mysqli_query($connect,"SELECT *,all_logs.id as idd,'Request missing information' as template_name,ifnull(all_speakers.email_id,'Speaker has been deleted.') as speaker_email FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_speakers ON all_speakers.id=all_logs.table_id  WHERE all_logs.operation='request missing information' AND all_logs.event_id='".$event_id."'  ORDER BY all_logs.id DESC Limit ".$limit);
	}

	if($id == '9999')
	{
	$all_logs_array = mysqli_query($connect,"SELECT *,all_logs.id as idd,'Request missing documents' as template_name,ifnull(all_speakers.email_id,'Speaker has been deleted.') as speaker_email FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_speakers ON all_speakers.id=all_logs.table_id  
	WHERE all_logs.operation='request missing documents' AND all_logs.event_id='".$event_id."'  ORDER BY all_logs.id DESC Limit ".$limit);
	}

	
	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Template Used</th><th>Sent To</th><th>Sent By</th><th> Date</th><th>Status</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		if($all_logs['template_name']=='Request missing information' || $all_logs['template_name']=='Request missing documents')
		{
			$template_name = "<p>".$all_logs['template_name']."</p>";
		}
		else
		{
			$template_name = "<a href='#' onclick='speakerTemplateModal1(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";	
		}
		
		$read = "";
		if($all_logs['email_read']=='y') 
			{
				$read = '<span class="badge badge-light" style="color: white;background: green;">Opened</span>';
			}else{
				$read = '<span class="badge badge-light" style="color: white;background: red;">Not Opened</span>';
			}

		$sp_email = "";
		if($all_logs['speaker_email']!='') 
			{
				$sp_email = $all_logs['speaker_email'];
			}else{
				$sp_email = 'Speaker has been deleted';
			}



		$content .="<tr>
		<td>".$template_name."</td>
		<td>".$sp_email."</td>
		<td>".$all_logs['first_name']."</td>
		<td> ".date('d-M-Y', strtotime($all_logs['created_at']))."</td>
		<td> ".$read."</td>
		
		
		
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Previous Emails List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}

function getSponsorEmailSent_by_id(){

$connect = $GLOBALS['connect'];
$event_id= mysqli_real_escape_string($connect,$_POST['event_id']);

	$id = mysqli_real_escape_string($connect,$_POST['template_id']);

	if($id != '9998' || $id != '9999')
	{
	$all_logs_array = mysqli_query($connect,"SELECT *,all_logs.id as idd,all_sponsors.sponsor_contact_email_address as sponsor_email FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_sponsors ON all_sponsors.id=all_logs.table_id  WHERE all_logs.operation='sent email to sponsor' AND all_logs.event_id='".$event_id."' AND all_logs.other_column_value='".$id."' AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC");
	}
	 if($id == '9998')
	{
	$all_logs_array = mysqli_query($connect,"SELECT *,all_logs.id as idd,'Request missing information' as template_name,ifnull(all_sponsors.sponsor_contact_email_address,'Sponsor has been deleted.') as sponsor_email FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_sponsors ON all_sponsors.id=all_logs.table_id  WHERE all_logs.operation='Request missing information sponsor' AND all_logs.event_id='".$event_id."'  ORDER BY all_logs.id DESC");
	}

	if($id == '9999')
	{
		$all_logs_array = mysqli_query($connect,"SELECT *,all_logs.id as idd,'Request missing documents' as template_name,ifnull(all_sponsors.sponsor_contact_email_address,'Sponsor has been deleted.') as sponsor_email FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_sponsors ON all_sponsors.id=all_logs.table_id  WHERE all_logs.operation='Request missing documents sponsor' AND all_logs.event_id='".$event_id."'  ORDER BY all_logs.id DESC");
	}

	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Template Used</th><th>Sent To</th><th>Sent By</th><th>Date</th><th>Status</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){

		if($all_logs['template_name']=='Request missing information' || $all_logs['template_name']=='Request missing documents')
		{
			$template_name = "<p>".$all_logs['template_name']."</p>";
		}
		else
		{
			$template_name = "<a  onclick='speakerTemplateModal1(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";
		}
		
		$read = "";
		// if($all_logs['email_read']=='y') $read = '<span class="badge badge-light" style="color: white;background: green;">Opened</span>';
		if($all_logs['email_read']=='y') 
			{
				$read = '<span class="badge badge-light" style="color: white;background: green;">Opened</span>';
			}else{
				$read = '<span class="badge badge-light" style="color: white;background: red;">Not Opened</span>';
			}

		$sp_email = "";
		if($all_logs['sponsor_email']!='') 
			{
				$sp_email = $all_logs['sponsor_email'];
			}else{
				$sp_email = 'Sponsor has been deleted';
			}

		$content .="<tr>
		<td>".$template_name."</td>
		<td>".$sp_email."</td>
		<td>".$all_logs['first_name']."</td>
		<td> ".date('d-M-Y', strtotime($all_logs['created_at']))."</td>
		<td>".$read."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Previous Emails List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}

function getSpeakerTopEmailSentDetails(){



	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['template_id']);	

	$all_logs_array = mysqli_query($connect,"SELECT *,all_logs.id as idd,all_speakers.email_id as speaker_email FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_speakers ON all_speakers.id=all_logs.table_id  WHERE all_logs.operation='sent email to speaker' AND all_logs.other_column_value='".$id."' AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC  ");


	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Template Used</th><th>Sent To</th><th>Sent By | Date2</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$sp_email = '';
		if($all_logs['speaker_email'] != ''){$sp_email = $all_logs['speaker_email'];}else{$sp_email = 'Speaker has been deleted';}
		$template_name = "<a href='#' onclick='speakerTemplateModal1(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";
		$read = "";
		if($all_logs['email_read']=='y') $read = '<span class="badge badge-light" style="color: white;background: green;">Opened</span>';
		$content .="<tr>
		<td>".$template_name." ".$read."</td>
		<td>".$sp_email."</td>
		<td>".$all_logs['first_name']." | ".date('d-M-Y', strtotime($all_logs['created_at']))."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Previous Emails List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}


function getSponsorTopEmailSentDetails(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['template_id']);	

	$all_logs_array = mysqli_query($connect,"SELECT *,all_logs.id as idd,all_sponsors.sponsor_contact_email_address as sponsor_email FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_sponsors ON all_sponsors.id=all_logs.table_id  WHERE all_logs.operation='sent email to sponsor' AND all_logs.other_column_value='".$id."' AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC ");

	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Template Used</th><th>Sent To</th><th>Sent By | Date</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){

		$spn_email = '';
		if($all_logs['sponsor_email'] != ''){$spn_email = $all_logs['sponsor_email'];}else{$spn_email = 'Sponsor has been deleted';}

		$template_name = "<a href='#' onclick='speakerTemplateModal1(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";
		$read = "";
		if($all_logs['email_read']=='y') $read = '<span class="badge badge-light" style="color: white;background: green;">Opened</span>';
		$content .="<tr>
		<td>".$template_name." ".$read."</td>
		<td>".$spn_email."</td>
		<td>".$all_logs['first_name']." | ".date('d-M-Y', strtotime($all_logs['created_at']))."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Previous Emails List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';

}
 
function getSponsorEmailsSent(){
	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['id']);
	$all_logs_array = mysqli_query($connect,"SELECT all_logs.*,all_users.*,all_logs.id as idd,all_email_templates.id,all_logs.operation as tempname,all_email_templates.template_name FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE (all_logs.operation='sent email to sponsor' OR all_logs.operation='sent email to sponsor scheduled') AND all_logs.table_id='".$id."'
		union
	SELECT all_logs.*,all_users.*,all_logs.id as idd,0 as id,all_logs.operation as tempname,'Missing Information' as template_name FROM all_logs  LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE (all_logs.operation='request missing information sponsor' OR all_logs.operation='request missing documents sponsor' OR all_logs.operation='request missing information sponsor scheduled' OR all_logs.operation='request missing documents sponsor scheduled') AND all_logs.table_id='".$id."' ");
	$content =' <div class="">
                       <table id="datatable" class="table table-bordered test1 table-responsive" style="width:100%">
                       <thead><tr><th>Email Subject</th><th>Sent By</th><th>Date</th><th>Action</th></tr></thead><tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		if($all_logs['template_name']=='Missing Information')
		{
			if($all_logs['tempname']=='request missing information sponsor')
			{
				$template_name = "<p>".ucfirst($all_logs['tempname'])."</p>";	
			}else
			{
				$template_name = "<p>".ucfirst($all_logs['tempname'])."</p>";
			}
		}else
		{
			$template_name = "<a  onclick='sponsorTemplateModal1(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";
		}
			$read = "";
			if($all_logs['email_read']=='y') {
			$read = '<span class="opened" >Opened</span>';
			}else{
			$read = '<span class="not_opened" >Not Opened</span>';
			}
		$content .="<tr>
		<td>".$template_name."</td>	
		<td>".$all_logs['first_name']."</td>
		<td>".date('d-M-Y', strtotime($all_logs['created_at']))."</td>
		<td>".$read."</td>
		</tr>";
	}

	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><img src="images/cancel.png" width="20"></button>
         <h4 class="modal-title">Previous Emails List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>
         ';	
	
}
 
function sponsorTypeCheck(){
	if(!isset($_SESSION)){ session_start(); }
		$event_id= $_SESSION['current_event_id'];

	$connect = $GLOBALS['connect'];
	$sponsor_type_name =  mysqli_real_escape_string($connect, $_POST['sponsor_type_name']);
	$id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"select * from all_sponsor_types where sponsor_type_name='".$sponsor_type_name."' AND event_id = '".$event_id."' AND id!=".$id);
	echo $count = mysqli_num_rows($sql);
}

function deleteSponsorType(){
	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
	$logged_in_user= $_SESSION['user_id'];	
	$res_array = array();
	$id = base64_decode( mysqli_real_escape_string($connect, $_POST['id']));
	$event_id =  mysqli_real_escape_string($connect, $_POST['event_id']);

	mysqli_query($connect,"DELETE from all_sponsor_types where id=".$id);
	mysqli_query($connect, "INSERT INTO all_crud_logs(event_id,operation,action_pk_id,created_by,table_name) VALUES ('".$event_id."','delete sponsor type','".$id."','".$logged_in_user."','all_sponsor_types')");
	$res_array['status'] = 'success';
	$res_array['encoded_eventid'] = base64_encode($event_id).':'.base64_encode(rand(100,999));
	echo json_encode($res_array);
}

function deleteTenant(){
	$connect = $GLOBALS['connect'];
	$id = base64_decode( mysqli_real_escape_string($connect, $_POST['id']));
		// echo "DELETE from all_tanents WHERE id=".$id; exit();
	mysqli_query($connect,"DELETE from all_tanents WHERE id=".$id);	
	mysqli_query($connect,"DELETE FROM all_users WHERE tanent_id=".$id);
}


function deleteAction(){
	if(!isset($_SESSION)){ session_start(); }
	$logged_in_user= $_SESSION['user_id'];
	$connect = $GLOBALS['connect'];
	$id1 = mysqli_real_escape_string($connect, $_POST['id']);
	 $event_id_enc = trim($id1);
     $event_id_exp = explode(':',$event_id_enc);
     $id = base64_decode($event_id_exp[0]);
     $event_id = base64_decode($event_id_exp[1]);

     $fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
     $res_sql = mysqli_fetch_array($fetch_sql);
     $session_tanent_id=$res_sql['tanent_id'];  

	$sql_query_log="DELETE from action_trackers where id='".$id."'";
	mysqli_query($connect,$sql_query_log);

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','delete action tracker','".$id."','".$logged_in_user."',now(),\"".$sql_query_log."\")");

	echo base64_encode($event_id).':'.base64_encode(rand(100,999));
}

function deleteActionType(){	
	if(!isset($_SESSION)){ session_start(); }
	$logged_in_user= $_SESSION['user_id'];
	$connect = $GLOBALS['connect'];
	$id1 = mysqli_real_escape_string($connect, $_POST['id']);
	 $event_id_enc = trim($id1);
     $event_id_exp = explode(':',$event_id_enc);
     $id = base64_decode($event_id_exp[0]);
     $event_id = base64_decode($event_id_exp[1]);

     $fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
     $res_sql = mysqli_fetch_array($fetch_sql);
     $session_tanent_id=$res_sql['tanent_id'];  

	$sql_query_log="DELETE from all_action_types where id='".$id."'";
	mysqli_query($connect,$sql_query_log);

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','delete action type','".$id."','".$logged_in_user."',now(),\"".$sql_query_log."\")");

	echo base64_encode($event_id).':'.base64_encode(rand(100,999));

}

function deleteResource(){
	if(!isset($_SESSION)){ session_start(); }
	$logged_in_user= $_SESSION['user_id'];
	$connect = $GLOBALS['connect'];
	$id1 = mysqli_real_escape_string($connect, $_POST['id']);
	 $event_id_enc = trim($id1);
     $event_id_exp = explode(':',$event_id_enc);
     $id = base64_decode($event_id_exp[0]);
     $event_id = base64_decode($event_id_exp[1]);

     $fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
     $res_sql = mysqli_fetch_array($fetch_sql);
     $session_tanent_id=$res_sql['tanent_id'];  

	$sql_query_log="DELETE from resource_trackers where id='".$id."'";
	mysqli_query($connect,$sql_query_log);

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','delete resource trackers','".$id."','".$logged_in_user."',now(),\"".$sql_query_log."\")");

	echo base64_encode($event_id).':'.base64_encode(rand(100,999));
}

function deleteResourceType(){
	if(!isset($_SESSION)){ session_start(); }
	$logged_in_user= $_SESSION['user_id'];
	$connect = $GLOBALS['connect'];
	$id1 = mysqli_real_escape_string($connect, $_POST['id']);
	 $event_id_enc = trim($id1);
     $event_id_exp = explode(':',$event_id_enc);
     $id = base64_decode($event_id_exp[0]);
     $event_id = base64_decode($event_id_exp[1]);

     $fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
     $res_sql = mysqli_fetch_array($fetch_sql);
     $session_tanent_id=$res_sql['tanent_id'];  

	$sql_query_log="DELETE from all_resource_types where id='".$id."'";
	mysqli_query($connect,$sql_query_log);

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','delete resource type','".$id."','".$logged_in_user."',now(),\"".$sql_query_log."\")");

	echo base64_encode($event_id).':'.base64_encode(rand(100,999));
}


function deleteEvent(){
	$connect = $GLOBALS['connect'];
	$id = base64_decode( mysqli_real_escape_string($connect, $_POST['id']));
	mysqli_query($connect,"DELETE from all_events where id=".$id);
}


function deleteActionFile(){

	$connect = $GLOBALS['connect'];
	$id = base64_decode( mysqli_real_escape_string($connect, $_POST['id']));
	$action_id = base64_decode( mysqli_real_escape_string($connect, $_POST['action_id']));	

	mysqli_query($connect,"DELETE from all_uploaded_files where id=".$id);

	$resource_files = mysqli_query($connect,"SELECT * from all_uploaded_files where action_id = '".$action_id."' ");
	$resource_file_count = mysqli_num_rows($resource_files);
	if($resource_file_count == 0){
		$update_file_status = mysqli_query($connect,"UPDATE action_trackers SET is_file_available = 0 WHERE id = '".$action_id."' ");
	}

}

function deleteResourceFile(){

	$connect = $GLOBALS['connect'];
	$id = base64_decode( mysqli_real_escape_string($connect, $_POST['id']));
	$resource_id = base64_decode( mysqli_real_escape_string($connect, $_POST['resource_id']));	
	mysqli_query($connect,"DELETE from all_uploaded_files where id=".$id);

	$resource_files = mysqli_query($connect,"SELECT * from all_uploaded_files where resource_id = '".$resource_id."' ");
	$resource_file_count = mysqli_num_rows($resource_files);

	if($resource_file_count == 0){
		$update_file_status = mysqli_query($connect,"UPDATE resource_trackers SET is_file_available = 0 WHERE id = '".$resource_id."' ");
	}


}


function speakerTypeCheck(){
	$connect = $GLOBALS['connect'];
	$speaker_type_name =  mysqli_real_escape_string($connect, $_POST['speaker_type_name']);
	$id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"select * from all_speaker_types where speaker_type_name='".$speaker_type_name."' AND id!=".$id);
	echo $count = mysqli_num_rows($sql);
}

function deleteSpeakerType(){
	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
	$created_by= $_SESSION['user_id'];
	$session_tanent_id=0;
	$event_id =  mysqli_real_escape_string($connect, $_POST['event_id']);
	$id = base64_decode( mysqli_real_escape_string($connect, $_POST['id']));
	$sql_query_log="DELETE from all_speaker_types where id=".$id;
	mysqli_query($connect,$sql_query_log);

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','Delete Speaker Type','".$id."','".$created_by."',now(),\"".$sql_query_log."\")");
	
}

function masterTypeCheck(){
	if(!isset($_SESSION)){ session_start(); }
		$event_id= $_SESSION['current_event_id'];

	$connect = $GLOBALS['connect'];
	$master_type_name =  mysqli_real_escape_string($connect, $_POST['master_type_name']);
	$id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"SELECT * from all_master_types where master_type_name='".$master_type_name."' AND event_id = '".$event_id."' AND  id!=".$id);
	echo $count = mysqli_num_rows($sql);
}

function actionTypeCheck(){
	$connect = $GLOBALS['connect'];
	$action_type_name =  mysqli_real_escape_string($connect, $_POST['action_type_name']);
	$id =  mysqli_real_escape_string($connect, $_POST['id']);
	$event_id =  mysqli_real_escape_string($connect, $_POST['event_id']);

	$sql = mysqli_query($connect,"SELECT * from all_action_types where event_id = '".$event_id."' AND action_type_name='".$action_type_name."' AND id!=".$id );
	
	echo $count = mysqli_num_rows($sql);
}

function actionNameCheck(){

	$connect = $GLOBALS['connect'];
	$action_name =  mysqli_real_escape_string($connect, $_POST['action_name']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	// $id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"SELECT * from action_trackers where action='".$action_name."' AND event_id = '".$event_id."' ");
	 echo $count = mysqli_num_rows($sql);
	 // echo "SELECT * from action_trackers where action='".$action_name."' AND event_id = '".$event_id."'";
}

function actionNameCheck_for_edit(){

	$connect = $GLOBALS['connect'];
	$action_name =  mysqli_real_escape_string($connect, $_POST['action_name']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	 $id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"SELECT * from action_trackers where action='".$action_name."' AND event_id = '".$event_id."' AND id != '".$id."' ");
	 echo $count = mysqli_num_rows($sql);
	 // echo "SELECT * from action_trackers where action='".$action_name."' AND event_id = '".$event_id."'";
}


function resourceNameCheck(){
	$connect = $GLOBALS['connect'];
	$resource_name =  mysqli_real_escape_string($connect, $_POST['resource_name']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	 // $id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"SELECT * from resource_trackers where resource = '".$resource_name."' AND event_id = '".$event_id."' ");
	 echo $count = mysqli_num_rows($sql);
	}

	function resourceNameCheck_for_edit(){
	$connect = $GLOBALS['connect'];
	$resource_name =  mysqli_real_escape_string($connect, $_POST['resource_name']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	  $id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"SELECT * from resource_trackers where resource = '".$resource_name."' AND event_id = '".$event_id."' AND id != '".$id."' ");
	 echo $count = mysqli_num_rows($sql);
	}

	




function resourceTypeCheck(){
	$connect = $GLOBALS['connect'];
	$resource_type_name =  mysqli_real_escape_string($connect, $_POST['resource_type_name']);
	$id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"SELECT * from all_resource_types where resource_type_name='".$resource_type_name."' AND id!=".$id);
	echo $count = mysqli_num_rows($sql);

}


function deleteMasterType(){
	if(!isset($_SESSION)){ session_start(); }
	$logged_in_user= $_SESSION['user_id'];
	$connect = $GLOBALS['connect'];
	$id1 = mysqli_real_escape_string($connect, $_POST['id']);
	 $event_id_enc = trim($id1);
     $event_id_exp = explode(':',$event_id_enc);
     $id = base64_decode($event_id_exp[0]);
     $event_id = base64_decode($event_id_exp[1]);

     $fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
     $res_sql = mysqli_fetch_array($fetch_sql);
     $session_tanent_id=$res_sql['tanent_id'];  

	$sql_query_log="DELETE from all_master_types where id='".$id."'";
	mysqli_query($connect,$sql_query_log);

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','delete master type','".$id."','".$logged_in_user."',now(),\"".$sql_query_log."\")");

	return base64_encode($event_id).':'.base64_encode(rand(100,999));

	
}

function deleteMaster(){ 

if(!isset($_SESSION)){ session_start(); }
	 $logged_in_user= $_SESSION['user_id'];
	 $connect = $GLOBALS['connect'];
	 $id1 = mysqli_real_escape_string($connect, $_POST['id']);
	 $event_id_enc = trim($id1);
     $event_id_exp = explode(':',$event_id_enc);
     $id = base64_decode($event_id_exp[0]);
     $event_id = base64_decode($event_id_exp[1]);

     $fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
     $res_sql = mysqli_fetch_array($fetch_sql);
     $session_tanent_id=$res_sql['tanent_id'];  

	$sql_query_log="DELETE from all_masters where id='".$id."'";
	mysqli_query($connect,$sql_query_log);

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','delete master','".$id."','".$logged_in_user."',now(),\"".$sql_query_log."\")");
	
		$all_masters_count_sp = calculate_master_dashboard_count($event_id);
	//****************   calculating master types counts **********************//
		$masters_data1 = mysqli_query($connect,"SELECT group_concat(id) as type_id FROM all_master_types WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($masters_data1) > 0)
            {  
                $res1 = mysqli_fetch_array($masters_data1);
                $row_id = $res1['type_id'];
                $status_ids_array1 = explode(",",$row_id);

                foreach ($status_ids_array1 as $typeid) { 
                if($typeid!=0)
                {

                    $query_sql_sp = mysqli_query($connect,"SELECT count(*) as count_masters FROM all_masters WHERE find_in_set('".$typeid."',all_masters.master_type) and all_masters.event_id='".$event_id."'");
                    $query_res_sp = mysqli_fetch_array($query_sql_sp);
                    $count_master_res = mysqli_real_escape_string($connect,$query_res_sp['count_masters']);
                
                    $update_status_details = mysqli_query($connect, "UPDATE `all_master_types` SET `total_masters_enrolled`='".$count_master_res."'   WHERE id=".$typeid);

                }

             }
           } 

	return base64_encode($event_id).':'.base64_encode(rand(100,999));
	
} 


function deleteSponsor(){
	if(!isset($_SESSION)){ session_start(); }
	 $logged_in_user= $_SESSION['user_id'];
	 $connect = $GLOBALS['connect'];
	 $id1 = mysqli_real_escape_string($connect, $_POST['id']);
	 $event_id_enc = trim($id1);
     $event_id_exp = explode(':',$event_id_enc);
     $id = base64_decode($event_id_exp[0]);
     $event_id = base64_decode($event_id_exp[1]);

     $fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
     $res_sql = mysqli_fetch_array($fetch_sql);
     $session_tanent_id=$res_sql['tanent_id'];  

	$sql_query_log="DELETE from all_sponsors where id='".$id."'";
	mysqli_query($connect,$sql_query_log);
	$all_speakers_array = calculate_sponsor_dashboard_count($event_id);

	$speakers_data1 = mysqli_query($connect,"SELECT group_concat(id) as status_id FROM all_status WHERE event_id = '".$event_id."' and status_for='sponsor' ");
            if(mysqli_num_rows($speakers_data1) > 0)
            {  
                $res1 = mysqli_fetch_array($speakers_data1);
                $row_id = $res1['status_id'];
                $status_ids_array1 = explode(",",$row_id);

                foreach ($status_ids_array1 as $statusid) { 
                if($statusid!=0)
                {

                    $query_sql_sp = mysqli_query($connect,"SELECT count(*) as count_spk FROM all_sponsors WHERE all_sponsors.status='".$statusid."' and all_sponsors.event_id='".$event_id."'");
                    $query_res_sp = mysqli_fetch_array($query_sql_sp);
                    $count_spk_res = mysqli_real_escape_string($connect,$query_res_sp['count_spk']);
                
                    $update_status_details = mysqli_query($connect, "UPDATE `all_status` SET `count_of_speaker_usage`='".$count_spk_res."'   WHERE id=".$statusid);

                }

             }
           }

          $speakers_data2 = mysqli_query($connect,"SELECT group_concat(id) as type_id FROM all_sponsor_types WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($speakers_data2) > 0)
            {  
                $res2 = mysqli_fetch_array($speakers_data2);
                $row_id2 = $res2['type_id'];
                $status_ids_array2 = explode(",",$row_id2);

                foreach ($status_ids_array2 as $typeid) { 
                if($typeid!=0)
                {

                    $query_sql_sp2 = mysqli_query($connect,"SELECT count(*) as count_spk FROM all_sponsors WHERE find_in_set('".$typeid."',all_sponsors.sponsor_type) and all_sponsors.event_id='".$event_id."'");
                    $query_res_sp2 = mysqli_fetch_array($query_sql_sp2);
                    $count_spk_res2 = mysqli_real_escape_string($connect,$query_res_sp2['count_spk']);
                
                    $update_status_details2 = mysqli_query($connect, "UPDATE `all_sponsor_types` SET `total_enrolled`='".$count_spk_res2."'   WHERE id=".$typeid);

                }

             }
           }

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','delete sponsor','".$id."','".$logged_in_user."',now(),\"".$sql_query_log."\")");

	echo base64_encode($event_id).':'.base64_encode(rand(100,999));
}

function fetchStatusBasedonType(){
	$connect = $GLOBALS['connect'];
	$template_type = mysqli_real_escape_string($connect, implode(",",$_POST['template_type']));
	$sql = mysqli_query($connect,"SELECT * from all_status where status_for LIKE '%".$template_type."%'");
	$condition = "status_for LIKE '%".$template_type."%'";
	if(strpos(implode(",",$_POST['template_type']),"speaker")>-1){ $condition .=" OR status_for  LIKE '%speaker%' ";}
	if(strpos(implode(",",$_POST['template_type']),"sponsor")>-1){ $condition .=" OR status_for  LIKE '%sponsor%' ";}
	if(strpos(implode(",",$_POST['template_type']),"master")>-1){ $condition .=" OR status_for  LIKE '%master%' ";}
		$sql = mysqli_query($connect,"SELECT * from all_status where  ".$condition." ");
	while($row = mysqli_fetch_array($sql)){
		echo '<option value="'.$row['id'].'">'.$row['status_name'].'</option>';
	}
	
}

function getTemplateModalContent(){
	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect, base64_decode($_POST['id']));
	$sql_all_logs = mysqli_query($connect,"SELECT * FROM all_email_templates WHERE id=".$id);
    $all_logs = mysqli_fetch_assoc($sql_all_logs);
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">'.$all_logs['template_name'].'</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">';
		$email_subject = $all_logs['template_subject'];
	  if(!$email_subject) $email_subject = " Not Found ";
	  if(1){
		  
        echo ' <br>
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-12"><label>Email Subject: </label><br><span style="font-weight:normal">'.$email_subject.'</span></div>
           
           
         </div>
		 <br>
                
       
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-12"><label>Email Content </label><br></div>
            <div class="col-xs-12"><div class="row clear-fix" style="border: 1px solid #5254568c;margin: 24px;padding: 12px;margin:0px">
				<span style="font-weight:normal">'.$all_logs['template_data'].'</span>
			</div>
			</div>
            <br><br>
         </div>
      </div>
   </div>
         ';
	  }else{
		 echo ' <br>
         <div class="row  clear-fix" style="margin-bottom:30px">
         <center>This feature is implemented on 20th Dec 2018, Previously sent email notifications are not captured properly, so please try to send new notifications and check it!</center>
           
         </div>
		 
        
      </div>
   </div>
         ';
	  }
	
	
	
}

function viewUser(){
			$connect = $GLOBALS['connect'];
			$id = base64_decode( mysqli_real_escape_string($connect, $_POST['id']));
			$sql = mysqli_query($connect,"SELECT * FROM all_users WHERE user_id=".$id);
			$result ="";
	
			while($row = mysqli_fetch_array($sql)){
				$first_name = $row['first_name'];
				$last_name = $row['last_name'];
				$phone_number = $row['phone_number'];
				$password = $row['password'];
				$email = $row['email'];
				$organization = $row['organization_name'];
				$gender = $row['gender'];
				$role = $role1 = $row['role'];
				$pic = $row['profile_pic'];
				if(empty($email)){
				    $email =" - ";
				}
				
				if(empty($gender)){
				    $gender =" - ";
				}
				
				if(empty($last_name)){
				    $last_name =" - ";
				}
				
				if(empty($organization)){
				    $organization =" - ";
				}
				
				if(empty($pic)){
				    $pic ="user-default-icon.jpg";
				}
				
				$image ="<img src='images/user_images/".$pic."' style='border: 1px solid black;width: 120px;margin:0 auto'/>";
				
				$result ='<button type="button" class="close" onclick="Custombox.close();" style="color:black">
							<span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black" >Close</span>
						</button>
						<div class="modal-content" >
						<div class="modal-header" >
							<button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
							<h4 class="modal-title" >'.ucfirst($role1).'</h4>
						 </div>
						<div class="custom-modal-text" style="" id="modal_content">';
				$result .= "<br><div class='col-xs-12' style='text-align: center;'>".$image."</div><div class='clearfix'></div>";
				
				$result .= "<br><div class='row'><div class='col-xs-5'><b>Name  </b></div><div class='col-xs-7'>".$first_name."</div></div>";
				// $result .= "<br><div class='row'><div class='col-xs-5'><b>Gender  </b></div><div class='col-xs-7'>".$gender."</div></div>";
				$result .= "<br><div class='row'><div class='col-xs-5'><b>Phone Number </b></div><div class='col-xs-7'> ".$phone_number."</div></div>";
				$result .= "<br><div class='row'><div class='col-xs-5'><b>Email Address </b></div><div class='col-xs-7'> ".$email."</div></div>";
				$result .= "<br><div class='row'><div class='col-xs-5'><b>Organization </b></div><div class='col-xs-7'>".$organization."</div></div>";
				$result .= "<br><div class='row'><div class='col-xs-5'><b>Role </b></div><div class='col-xs-7'> ".ucfirst($role)."</div></div>";
				
				$result .="</div>";
				
			}
			
			echo '<br>
         <div class="row  clear-fix" style="margin-bottom:30px">
         '.$result.'
           
         </div>
		 
        
      </div>
   </div>';
			//echo $result;
}

function tenent_url_check(){
	$connect = $GLOBALS['connect'];
	
		$tanent_url_structure = mysqli_real_escape_string($connect, $_POST['tanent_url_structure']);
		$sql = mysqli_query($connect,"select * from all_tanents where url_structure ='".$tanent_url_structure."'");
		echo $email_count=mysqli_num_rows($sql);
	
}

function tenant_url_check_update(){
	$connect = $GLOBALS['connect']; 
	
		$tanent_url_structure = mysqli_real_escape_string($connect, $_POST['tanent_url_structure']);
		$tenant_id = mysqli_real_escape_string($connect, $_POST['tenant_id']);
		$sql = mysqli_query($connect,"select * from all_tanents where url_structure ='".$tanent_url_structure."' AND id != '$tenant_id'");
		echo $email_count=mysqli_num_rows($sql);

}

function tanent_email_check(){
	$connect = $GLOBALS['connect'];
	$total_count = 0;
	
	$tanent_email = mysqli_real_escape_string($connect, $_POST['tanent_email']);
	$sql = mysqli_query($connect,"select * from all_tanents where email ='".$tanent_email."'");
    $email_count=mysqli_num_rows($sql);

    $sql2 = mysqli_query($connect,"select * from all_users where email ='".$tanent_email."'");
    $email_count2=mysqli_num_rows($sql2);
    echo $total_count = $email_count + $email_count2;
}


function email_count_tenant_update(){
	$connect = $GLOBALS['connect'];
	$total_count = 0;
	
	$tanent_email = mysqli_real_escape_string($connect, $_POST['tanent_email']);
	$tenant_id = mysqli_real_escape_string($connect, $_POST['tenant_id']);
	//echo $tenant_id;

	$sql = mysqli_query($connect,"select * from all_tanents where email ='".$tanent_email."' AND id != '$tenant_id' ");
	// echo "select * from all_tanents where email ='".$tanent_email."' WHERE id != '$tenant_id' ";
    $email_count=mysqli_num_rows($sql);

    $sql2 = mysqli_query($connect,"select * from all_users where email ='".$tanent_email."' AND tanent_id != '$tenant_id' ");
    $email_count2=mysqli_num_rows($sql2);
    echo $total_count = $email_count + $email_count2;
}

function add_speaker_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$speaker_id = mysqli_real_escape_string($connect, $_POST['speaker_id']);

	$insert_note = mysqli_query($connect,"INSERT INTO speaker_notes(notes,speaker_id,created_by) VALUES('$note_val','$speaker_id','$loggedin_userid') ");
	if($insert_note){
		echo 'success';
	}else{
		echo 'failed';
	}
}

function update_speaker_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$speaker_id = mysqli_real_escape_string($connect, $_POST['speaker_id']);
	$note_id = mysqli_real_escape_string($connect, $_POST['note_id']);
	$current_time = date('Y-m-d H:i:s');

	$update_note = mysqli_query($connect,"UPDATE speaker_notes SET notes ='$note_val',created_by='$loggedin_userid',created_at = '$current_time',is_updated = '1' WHERE speaker_id = '$speaker_id' AND id  = '$note_id' ");
	if($update_note){
		echo 'success';
	}else{
		echo 'failed';
	}

}

function fetch_speaker_notes_by_id(){

	$connect = $GLOBALS['connect'];
	 $speaker_id =  $_POST['speaker_id'];
	 //$speaker_id = 224;
	//echo "Arka= ".$speaker_id ;
	$fetch_notes = mysqli_query($connect,"SELECT sn.id as id, sn.notes, sn.speaker_id, sn.created_by,STR_TO_DATE(sn.created_at, '%Y-%m-$d') as created_at,date_format(sn.created_at, '%d-%b-%Y') as createdon, au.first_name as created_by_name  FROM speaker_notes sn, all_users au WHERE au.user_id = sn.created_by AND  sn.speaker_id ='$speaker_id' ORDER BY sn.id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function getSpeakerScheduledTopEmailSentDetails(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['template_id']);	
	$event_id = mysqli_real_escape_string($connect,$_POST['event_id']);
	$limit = mysqli_real_escape_string($connect,$_POST['limit']);

	if($id != '9998' || $id != '9999')
	{
	$all_logs_array = mysqli_query($connect,"SELECT  *,ts.id as idd,al.email_read FROM tbl_sendlatermaildetails ts LEFT JOIN all_email_templates aet ON aet.id=ts.template_id 
		LEFT JOIN all_users au ON au.user_id=ts.user_id LEFT JOIN all_logs al ON ts.id=al.scheduled_row_id WHERE (ts.type='Speaker' or ts.type='Speaker-bulkmail')
		AND ts.template_id='".$id."' AND aet.template_name !='' and ts.event_id='".$event_id."' ORDER BY ts.id DESC LIMIT ".$limit);
	}
	 if($id == '9998')
	{
	$all_logs_array = mysqli_query($connect,"SELECT  *,ts.id as idd,'Request missing information' as template_name,al.email_read FROM tbl_sendlatermaildetails ts 
		LEFT JOIN all_users au ON au.user_id=ts.user_id LEFT JOIN all_logs al ON ts.id=al.scheduled_row_id WHERE ts.type='missing-info-collect'
		AND ts.event_id='".$event_id."' ORDER BY ts.id DESC LIMIT ".$limit);
	}

	if($id == '9999')
	{
	$all_logs_array = mysqli_query($connect,"SELECT  *,ts.id as idd,'Request missing documents' as template_name,al.email_read FROM tbl_sendlatermaildetails ts 
		LEFT JOIN all_users au ON au.user_id=ts.user_id LEFT JOIN all_logs al ON ts.id=al.scheduled_row_id WHERE ts.type='missing-document-collect'
		AND ts.event_id='".$event_id."' ORDER BY ts.id DESC LIMIT ".$limit);
	}


	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Template Used</th><th>Sent To</th><th>Sent By</th><th> Date</th> <th>Status</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$sp_email = '';
		if($all_logs['speaker_emailid'] != ''){$sp_email = $all_logs['speaker_emailid'];}else{$sp_email = 'Speaker has been deleted';}
		if($all_logs['template_name']=='Request missing information' || $all_logs['template_name']=='Request missing documents')
		{
			$template_name = "<p>".$all_logs['template_name']."</p>";
		}
		else
		{
			$template_name = "<a href='#' onclick='speakerscheduledTemplateModal1(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";
		}
		
		$read = "";
		if($all_logs['email_read']=='y') {
			$read = '<span class="badge badge-light" style="color: white;background: green;">Opened</span>';
		}else{
			$read = '<span class="badge badge-light" style="color: white;background: red;">Not Opened</span>';
		}



		$content .="<tr>
		<td>".$template_name."</td>
		<td>".$sp_email."</td>
		<td>".$all_logs['username']."</td>
		<td> ".date('d-M-Y', strtotime($all_logs['createdon']))."</td>
		<td>".$read."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Previous Emails List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}

function getScheduledSpeakerTemplateModalContent(){
	$connect = $GLOBALS['connect'];
	$log_table_id = mysqli_real_escape_string($connect, $_POST['log_table_id']);
	$sql_all_logs = mysqli_query($connect,"SELECT * FROM tbl_sendlatermaildetails ts LEFT JOIN all_email_templates aet ON aet.id=ts.template_id LEFT JOIN all_users au ON au.user_id=ts.user_id WHERE ts.id=".$log_table_id);
    $all_logs = mysqli_fetch_assoc($sql_all_logs);
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">'.$all_logs['template_name'].'</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">';
	  $cc = $all_logs['cc_emails'];
	  $speaker_manager_email = $all_logs['speaker_manager_id'];
	  $email_subject = $all_logs['template_sub'];
	  if(!$cc) $cc = " Not Found ";
	  if(!$speaker_manager_email) $speaker_manager_email = " Not Found ";
	  if(!$email_subject) $email_subject = " Not Found ";
	  if($all_logs['template_data']){
		  
        echo ' <br>
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-6"><label>Email Subject: </label><br><span style="font-weight:normal">'.$email_subject.'</span></div>
            <div class="col-xs-6"><label>Speaker Manager Email Address: </label><br><span style="font-weight:normal">'.$speaker_manager_email.'</span></div>
           
         </div>
		 <br>
         <div class="row clear-fix" style="margin-bottom:30px">
            <div class="col-xs-6"><label>Cc Email Address: </label><br><span style="font-weight:normal">'.$cc.'</span></div>
           
         </div>
        
       
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-12"><label>Email Content </label><br></div>
            <div class="col-xs-12"><div class="row clear-fix" style="border: 1px solid #5254568c;margin: 24px;padding: 12px;margin:0px">
				<span style="font-weight:normal">'.$all_logs['template_data'].'</span>
			</div>
			</div>
            <br><br>
         </div>
      </div>
   </div>
         ';
	  }else{
		 echo ' <br>
         <div class="row  clear-fix" style="margin-bottom:30px">
         <center>This feature is implemented on 20th Dec 2018, Previously sent email notifications are not captured properly, so please try to send new notifications and check it!</center>
           
         </div>
		 
        
      </div>
   </div>
         ';
	  }
	
	
	
}

function getSpeakeropportunity(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['template_id']);	
	$event_id = mysqli_real_escape_string($connect,$_POST['event_id']);

	$all_logs_array = mysqli_query($connect,"SELECT all_email_templates.template_name,all_speakers.email_id as sent_to,all_users.email as sent_by,all_logs.created_at as sent_on,all_logs.email_read FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value 
		LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_speakers ON all_speakers.id=all_logs.table_id  WHERE all_logs.operation='sent email to speaker' 
		AND all_logs.table_id in (select id from all_speakers where FIND_IN_SET('".$id."', speaker_type) AND event_id='".$event_id."') AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC");


	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Email Subject</th><th>Sent To</th><th>Sent By</th><th>Date</th><th>Action</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$sp_email = '';
		if($all_logs['sent_to'] != ''){$sp_email = $all_logs['sent_to'];}else{$sp_email = 'Speaker has been deleted';}
		$template_name = "<b>".$all_logs['template_name']."</b>";
		$read = "";
		if($all_logs['email_read']=='y') {
			$read = '<span class="badge badge-light" style="color: white;background: green;">Opened</span>';
		}else{
			$read = '<span class="badge badge-light" style="color: white;background: red;">Not Opened</span>';
		}

		$content .="<tr>
		<td>".$template_name." </td>
		<td>".$all_logs['sent_to']."</td>
		<td>".$all_logs['sent_by']."</td>
		<td>".date('d-M-Y', strtotime($all_logs['sent_on']))."</td>
		<td>".$read."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Total Email Sent List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}

function get_count_speaker_details(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['status_id']);	
	$event_id = mysqli_real_escape_string($connect,$_POST['event_id']);

	$all_logs_array = mysqli_query($connect,"select speaker_name,company from all_speakers where status='".$id."' and event_id='".$event_id."' order by id desc");


	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Speaker Name</th><th>Company</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$content .="<tr>
		<td>".$all_logs['speaker_name']."</td>
		<td>".$all_logs['company']."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Speaker List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}

function get_count_speaker_type_details(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['types_id']);	
	$event_id = mysqli_real_escape_string($connect,$_POST['event_id']);

	$all_logs_array = mysqli_query($connect,"select speaker_name,company from all_speakers where find_in_set('".$id."',all_speakers.speaker_type)  and event_id='".$event_id."' order by id desc");


	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Speaker Name</th><th>Company</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$content .="<tr>
		<td>".$all_logs['speaker_name']."</td>
		<td>".$all_logs['company']."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Speaker List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}


function add_new_speaker_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$uniq_token = mysqli_real_escape_string($connect, $_POST['uniq_token']);

	$insert_note = mysqli_query($connect,"INSERT INTO new_speaker_notes(notes,uniqueid,created_by) VALUES('$note_val','$uniq_token','$loggedin_userid') ");
	if($insert_note){
		echo 'success';
	}else{
		echo 'failed';
	}
}

function fetch_speaker_notes_by_uniqueid(){

	$connect = $GLOBALS['connect'];
	 $uniq_token =  $_POST['uniq_token'];
	 //$speaker_id = 224;
	//echo "Arka= ".$speaker_id ;
	$fetch_notes = mysqli_query($connect,"SELECT sn.id as id, sn.notes, sn.uniqueid as speaker_id, sn.created_by,STR_TO_DATE(sn.created_at, '%Y-%m-$d') as created_at,date_format(sn.created_at, '%d-%b-%Y') as createdon, au.first_name as created_by_name  FROM new_speaker_notes sn, all_users au WHERE au.user_id = sn.created_by AND  sn.uniqueid ='$uniq_token' ORDER BY sn.id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function update_new_speaker_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$uniq_token = mysqli_real_escape_string($connect, $_POST['uniq_token']);
	$note_id = mysqli_real_escape_string($connect, $_POST['note_id']);
	$current_time = date('Y-m-d H:i:s');

	$update_note = mysqli_query($connect,"UPDATE new_speaker_notes SET notes ='$note_val',created_by='$loggedin_userid',created_at = '$current_time',is_updated = '1' WHERE uniqueid = '$uniq_token' AND id  = '$note_id' ");
	if($update_note){
		echo 'success';
	}else{
		echo 'failed';
	}

}

function getMasteropportunity(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['id']);	
	$event_id = mysqli_real_escape_string($connect,$_POST['event_id']);

	$all_logs_array = mysqli_query($connect,"SELECT all_email_templates.template_name,all_masters.email_id as sent_to,all_users.email as sent_by,all_logs.created_at as sent_on,all_logs.email_read FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value 
        LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_masters ON all_masters.id=all_logs.table_id  WHERE all_logs.operation='sent email to master' AND all_logs.table_id in (select id from all_masters where FIND_IN_SET('".$id."', master_type) AND event_id='".$event_id."') AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC");


	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Email Subject</th><th>Sent To</th><th>Sent By</th><th>Date</th><th>Action</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$sp_email = '';
		if($all_logs['sent_to'] != ''){$sp_email = $all_logs['sent_to'];}else{$sp_email = 'Speaker has been deleted';}
		$template_name = "<b>".$all_logs['template_name']."</b>";
		$read = "";
		if($all_logs['email_read']=='y') 
		{
			$read = '<span class="badge badge-light" style="color: white;background: green;">Opened</span>';
		}else
		{
			$read = '<span class="badge badge-light" style="color: white;background: red;">Not Opened</span>';
		}
		$content .="<tr>
		<td>".$template_name." </td>
		<td>".$all_logs['sent_to']."</td>
		<td>".$all_logs['sent_by']."</td>
		<td>".date('d-M-Y', strtotime($all_logs['sent_on']))."</td>
		<td>".$read."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Total Email Sent List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}


function getMasterScheduledTopEmailSentDetails(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['template_id']);	
	$event_id = mysqli_real_escape_string($connect,$_POST['event_id']);

	// $all_logs_array = mysqli_query($connect,"SELECT *,ts.id as idd FROM tbl_sendlatermaildetails ts  LEFT JOIN all_email_templates aet ON aet.id=ts.template_id LEFT JOIN all_users au ON au.user_id=ts.user_id WHERE (ts.type='Master' or ts.type='Master-bulkmail')
	// 	AND ts.template_id='".$id."' AND aet.template_name !='' and ts.event_id='".$event_id."' ORDER BY ts.id DESC  ");

	$all_logs_array = mysqli_query($connect,"SELECT  *,ts.id as idd,al.email_read FROM tbl_sendlatermaildetails ts LEFT JOIN all_email_templates aet ON aet.id=ts.template_id 
			LEFT JOIN all_users au ON au.user_id=ts.user_id LEFT JOIN all_logs al ON ts.id=al.scheduled_row_id WHERE (ts.type='Master' or ts.type='Master-bulkmail')
		AND ts.template_id='".$id."' AND aet.template_name !='' and ts.event_id='".$event_id."' ORDER BY ts.id DESC  ");


	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Template Used</th><th>Sent To</th><th>Sent By </td>
                     	<td> Date</th>
                     	<td>Status</td>
                     	</tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$sp_email = '';
		if($all_logs['speaker_emailid'] != ''){$sp_email = $all_logs['speaker_emailid'];}else{$sp_email = 'Speaker has been deleted';}
		$template_name = "<a href='#' onclick='speakerscheduledTemplateModal1(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";
		$read = "";
		if($all_logs['email_read']=='y') 
		{
			$read = '<span class="badge badge-light" style="color: white;background: green;">Opened</span>';
		}else
		{
			$read = '<span class="badge badge-light" style="color: white;background: red;">Not Opened</span>';
		}
		$content .="<tr>
		<td>".$template_name."</td>
		<td>".$sp_email."</td>
		<td>".$all_logs['username']."</td>
		<td> ".date('d-M-Y', strtotime($all_logs['createdon']))."</td>
		<td>".$read."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Previous Emails List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}

function add_ep_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$ep_id = mysqli_real_escape_string($connect, $_POST['ep_id']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);

	$insert_note = mysqli_query($connect,"INSERT INTO event_presentation_notes(notes,event_id,ep_id,created_by) VALUES('$note_val','$event_id','$ep_id','$loggedin_userid') ");
	if($insert_note){
		echo 'success';
	}else{
		echo 'failed';
	}
}

function fetch_ep_notes_by_id(){

	$connect = $GLOBALS['connect'];
	 $ep_id =  $_POST['ep_id'];
	 //$speaker_id = 224;
	//echo "Arka= ".$speaker_id ;
	$fetch_notes = mysqli_query($connect,"SELECT epn.id,epn.notes,epn.event_id,epn.ep_id,date_format(epn.created_at, '%d-%b-%Y') as created_at,ifnull((select speaker_name from all_speakers where id=epn.created_by), (select first_name from all_users where user_id=epn.created_by)) as addedby FROM event_presentation_notes epn WHERE ep_id ='".$ep_id."' ORDER BY id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function update_ep_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$ep_id = mysqli_real_escape_string($connect, $_POST['ep_id']);
	$note_id = mysqli_real_escape_string($connect, $_POST['note_id']);
	$current_time = date('Y-m-d H:i:s');

	$update_note = mysqli_query($connect,"UPDATE event_presentation_notes SET notes ='$note_val',created_by='$loggedin_userid',created_at = '$current_time' WHERE ep_id = '$ep_id' AND id  = '$note_id' ");
	if($update_note){
		echo 'success';
	}else{
		echo 'failed';
	}

}

function getSpeakerAll(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['ep_id']);	
	$fetch_url_query = mysqli_query($connect,"select group_concat(speaker_id) as speaker_id from event_agenda_speakers where event_agenda_speakers.ep_id='".$id."'");
    if(mysqli_num_rows($fetch_url_query) > 0)
        {            
            while($row1 = mysqli_fetch_array($fetch_url_query))
            {
                $speakers_id = $row1['speaker_id'];
            }
         }  

	$resource_ids_array = explode(",",$speakers_id);

	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Speaker Name</th></tr>
                        <tbody>';
                        $attached_links = '';
                        foreach ($resource_ids_array as $resource_id) { 
							//echo $resource_id; 
							$fetch_resource_details = mysqli_query($connect,"select id,speaker_name from all_speakers WHERE `id` = '".$resource_id."' ");
							$res = mysqli_fetch_array($fetch_resource_details);
							//$attached_links .= '<div class="speakerNamediv">'.$res['speaker_name'].'</div>';
							$attached_links .= '<div class="speakerNamediv"><a  style="width: 100%;float: left;font-size: 13px;padding-bottom: 3px;cursor:pointer;" onClick="setSpeakerIDforPreview('.$res['id'].')" data-toggle="modal" data-target="#previewModal2">'.$res['speaker_name'].'</a></div>';

						}
		$content=$attached_links;

			echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content darkHeaderModal" style="border-radius:0px;">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Speaker List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';

	
}

function add_new_sponsor_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$uniq_token = mysqli_real_escape_string($connect, $_POST['uniq_token']);

	$insert_note = mysqli_query($connect,"INSERT INTO new_sponsor_notes(notes,uniqueid,created_by) VALUES('$note_val','$uniq_token','$loggedin_userid') ");
	if($insert_note){
		echo 'success';
	}else{
		echo 'failed';
	}
}

function fetch_sponsor_notes_by_uniqueid(){

	$connect = $GLOBALS['connect'];
	 $uniq_token =  $_POST['uniq_token'];
	 //$speaker_id = 224;
	//echo "Arka= ".$speaker_id ;
	$fetch_notes = mysqli_query($connect,"SELECT sn.id as id, sn.notes, sn.uniqueid as speaker_id, sn.created_by,STR_TO_DATE(sn.created_at, '%Y-%m-$d') as created_at,date_format(sn.created_at, '%d-%b-%Y') as createdon, au.first_name as created_by_name  FROM new_sponsor_notes sn, all_users au WHERE au.user_id = sn.created_by AND  sn.uniqueid ='$uniq_token' ORDER BY sn.id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function update_new_sponsor_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$uniq_token = mysqli_real_escape_string($connect, $_POST['uniq_token']);
	$note_id = mysqli_real_escape_string($connect, $_POST['note_id']);
	$current_time = date('Y-m-d H:i:s');

	$update_note = mysqli_query($connect,"UPDATE new_sponsor_notes SET notes ='$note_val',created_by='$loggedin_userid',created_at = '$current_time',is_updated = '1' WHERE uniqueid = '$uniq_token' AND id  = '$note_id' ");
	if($update_note){
		echo 'success';
	}else{
		echo 'failed';
	}

}
function fetch_sponsor_notes_by_id(){

	$connect = $GLOBALS['connect'];
	 $sponsor_id =  $_POST['sponsor_id'];
	 //$speaker_id = 224;
	//echo "Arka= ".$speaker_id ;
	$fetch_notes = mysqli_query($connect,"SELECT sn.id as id, sn.notes, sn.sponsor_id, sn.created_by,STR_TO_DATE(sn.created_at, '%Y-%m-$d') as created_at,date_format(sn.created_at, '%d-%b-%Y') as createdon, au.first_name as created_by_name  FROM sponsor_notes sn, all_users au WHERE au.user_id = sn.created_by AND  sn.sponsor_id ='$sponsor_id' ORDER BY sn.id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function add_sponsor_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$sponsor_id = mysqli_real_escape_string($connect, $_POST['sponsor_id']);

	$insert_note = mysqli_query($connect,"INSERT INTO sponsor_notes(notes,sponsor_id,created_by) VALUES('$note_val','$sponsor_id','$loggedin_userid') ");
	if($insert_note){
		echo 'success';
	}else{
		echo 'failed';
	}
}

function update_sponsor_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$sponsor_id = mysqli_real_escape_string($connect, $_POST['sponsor_id']);
	$note_id = mysqli_real_escape_string($connect, $_POST['note_id']);
	$current_time = date('Y-m-d H:i:s');

	$update_note = mysqli_query($connect,"UPDATE sponsor_notes SET notes ='$note_val',created_by='$loggedin_userid',created_at = '$current_time',is_updated = '1' WHERE sponsor_id = '$sponsor_id' AND id  = '$note_id' ");
	if($update_note){
		echo 'success';
	}else{
		echo 'failed';
	}

}

function add_new_sponsorship_type(){

	$connect = $GLOBALS['connect'];
	$sponsor_type = mysqli_real_escape_string($connect, $_POST['sponsor_type']);
	$committed_unit = mysqli_real_escape_string($connect, $_POST['committed_unit']);
	$sponsorship_values = mysqli_real_escape_string($connect, $_POST['sponsorship_values']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$uniq_token = mysqli_real_escape_string($connect, $_POST['uniq_token']);

	$insert_note = mysqli_query($connect,"INSERT INTO new_sponsorship_type(sponsor_type,committed_unit,sponsorship_values,uniqueid,created_by) VALUES('$sponsor_type','$committed_unit','$sponsorship_values','$uniq_token','$loggedin_userid') ");
	if($insert_note){
		echo 'success';
	}else{
		echo 'failed';
	}
}

function fetch_sponsorship_added_by_uniqueid(){

	$connect = $GLOBALS['connect'];
	$uniq_token =  $_POST['uniq_token'];

	$fetch_notes = mysqli_query($connect,"SELECT sn.id as id, (SELECT sponsor_type_name from all_sponsor_types where id=sn.sponsor_type) as sponsor_type,sn.committed_unit,sn.sponsorship_values, sn.uniqueid as speaker_id, sn.created_by,STR_TO_DATE(sn.created_at, '%Y-%m-$d') as created_at,date_format(sn.created_at, '%d-%b-%Y') as createdon, au.first_name as created_by_name  FROM new_sponsorship_type sn, all_users au WHERE au.user_id = sn.created_by AND  sn.uniqueid ='$uniq_token' ORDER BY sn.id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function fetch_sponsorship_added_by_id(){

	$connect = $GLOBALS['connect'];
	 $sponsor_id =  $_POST['sponsor_id'];
	 //$speaker_id = 224;
	//echo "Arka= ".$speaker_id ;
	$fetch_notes = mysqli_query($connect,"SELECT sn.id as id, (SELECT sponsor_type_name from all_sponsor_types where id=sn.sponsor_type) as sponsor_type,sn.committed_unit,sn.sponsorship_values, sn.sponsor_id as speaker_id, sn.created_by,STR_TO_DATE(sn.created_at, '%Y-%m-$d') as created_at,date_format(sn.created_at, '%d-%b-%Y') as createdon, au.first_name as created_by_name  FROM sponsor_sponsorship_type sn, all_users au WHERE au.user_id = sn.created_by AND  sn.sponsor_id ='$sponsor_id' ORDER BY sn.id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function add_sponsorship_type(){

	$connect = $GLOBALS['connect'];
	$sponsor_type = mysqli_real_escape_string($connect, $_POST['sponsor_type']);
	$committed_unit = mysqli_real_escape_string($connect, $_POST['committed_unit']);
	$sponsorship_values = mysqli_real_escape_string($connect, $_POST['sponsorship_values']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$sponsor_id = mysqli_real_escape_string($connect, $_POST['sponsor_id']);

	$insert_note = mysqli_query($connect,"INSERT INTO sponsor_sponsorship_type(sponsor_type,committed_unit,sponsorship_values,sponsor_id,created_by) VALUES('$sponsor_type','$committed_unit','$sponsorship_values','$sponsor_id','$loggedin_userid') ");
	if($insert_note){
		echo 'success';
	}else{
		echo 'failed';
	}
}

function update_sponsorship_type(){

	$connect = $GLOBALS['connect'];
	$committed_unit = mysqli_real_escape_string($connect, $_POST['committed_unit']);
	$sponsorship_values = mysqli_real_escape_string($connect, $_POST['sponsorship_values']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$row_id = mysqli_real_escape_string($connect, $_POST['row_id']);
	$current_time = date('Y-m-d H:i:s');

	$update_query = mysqli_query($connect,"UPDATE sponsor_sponsorship_type SET committed_unit ='$committed_unit',created_by='$loggedin_userid',created_at = '$current_time',sponsorship_values = '$sponsorship_values' WHERE id  = '".$row_id."' ");

	if($update_query){
		echo 'success';
	}else{
		echo 'failed';
	}
}

function getMasterEmailsSent_preview(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['id']);

	$all_logs_array = mysqli_query($connect,"SELECT *,all_logs.id as idd FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE (all_logs.operation='sent email to master' OR all_logs.operation='sent email to master scheduled') AND all_logs.table_id='".$id."' AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC ");

	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$template_name = "<a href='#' onclick='masterTemplateModal(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";
		$read = "";
		if($all_logs['email_read']=='y') $read = '<span class="opened">Opened</span>';
		$content .="<tr>
		<td>".$template_name." ".$read."</td>
		<td>".$all_logs['first_name']." ".date('d-M-Y', strtotime($all_logs['created_at']))."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><img src="images/cancel.png" width="20"></button>
         <h4 class="modal-title">Previous Emails List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';



}

function get_count_sponsor_details(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['status_id']);	
	$event_id = mysqli_real_escape_string($connect,$_POST['event_id']);

	$all_logs_array = mysqli_query($connect,"select sponsor_contact_person,sponsor_company_name from all_sponsors where status='".$id."' and event_id='".$event_id."' order by id desc");


	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Sponsor Name</th><th>Company</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$content .="<tr>
		<td>".$all_logs['sponsor_contact_person']."</td>
		<td>".$all_logs['sponsor_company_name']."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Speaker List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}

function get_count_sponsortype_details(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['status_id']);	
	$event_id = mysqli_real_escape_string($connect,$_POST['event_id']);

	$all_logs_array = mysqli_query($connect,"select sponsor_contact_person,sponsor_company_name from all_sponsors where find_in_set('".$id."',all_sponsors.sponsor_type) and event_id='".$event_id."' order by id desc");


	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Sponsor Name</th><th>Company</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$content .="<tr>
		<td>".$all_logs['sponsor_contact_person']."</td>
		<td>".$all_logs['sponsor_company_name']."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Speaker List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}

function getSponsoropportunity(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['type_id']);	
	$event_id = mysqli_real_escape_string($connect,$_POST['event_id']);

	$all_logs_array = mysqli_query($connect,"SELECT all_email_templates.template_name,all_sponsors.sponsor_contact_email_address as sent_to,all_users.email as sent_by,all_logs.created_at as sent_on,all_logs.email_read FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by LEFT JOIN all_sponsors ON all_sponsors.id=all_logs.table_id  WHERE all_logs.operation='sent email to sponsor' 
        AND all_logs.table_id in (select id from all_sponsors where FIND_IN_SET('".$id."', sponsor_type) AND event_id='".$event_id."') AND all_email_templates.template_name !='' ORDER BY all_logs.id DESC");


	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Email Subject</th><th>Sent To</th><th>Sent By</th><th>Date</th><th>Action</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$sp_email = '';
		if($all_logs['sent_to'] != ''){$sp_email = $all_logs['sent_to'];}else{$sp_email = 'Speaker has been deleted';}
		$template_name = "<b>".$all_logs['template_name']."</b>";
		$read = "";
		if($all_logs['email_read']=='y') 
			{
				$read = '<span class="badge badge-light" style="color: white;background: green;">Opened</span>';
			}else
			{
				$read = '<span class="badge badge-light" style="color: white;background: red;">Not Opened</span>';
			}
		$content .="<tr>
		<td>".$template_name." </td>
		<td>".$all_logs['sent_to']."</td>
		<td>".$all_logs['sent_by']."</td>
		<td>".date('d-M-Y', strtotime($all_logs['sent_on']))."</td>
		<td>".$read."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Total Email Sent List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}

function getSponsorScheduledTopEmailSentDetails(){

	$connect = $GLOBALS['connect'];
	$id = mysqli_real_escape_string($connect,$_POST['template_id']);	
	$event_id = mysqli_real_escape_string($connect,$_POST['event_id']);

	if($id != '9998' || $id != '9999')
	{
	$all_logs_array = mysqli_query($connect,"SELECT  *,ts.id as idd,al.email_read FROM tbl_sendlatermaildetails ts LEFT JOIN all_email_templates aet ON aet.id=ts.template_id 
		LEFT JOIN all_users au ON au.user_id=ts.user_id LEFT JOIN all_logs al ON ts.id=al.scheduled_row_id WHERE (ts.type='Sponser' or ts.type='Sponser-bulkmail')
		AND ts.template_id='".$id."' AND aet.template_name !='' and ts.event_id='".$event_id."' ORDER BY ts.id DESC  ");
	}
	 if($id == '9998')
	{
	$all_logs_array = mysqli_query($connect,"SELECT  *,ts.id as idd,'Request missing information' as template_name,al.email_read FROM tbl_sendlatermaildetails ts 
		LEFT JOIN all_users au ON au.user_id=ts.user_id LEFT JOIN all_logs al ON ts.id=al.scheduled_row_id WHERE ts.type='missing-info-collect-sponsor'
		AND ts.event_id='".$event_id."' ORDER BY ts.id DESC");
	}

	if($id == '9999')
	{
	$all_logs_array = mysqli_query($connect,"SELECT  *,ts.id as idd,'Request missing documents' as template_name,al.email_read FROM tbl_sendlatermaildetails ts 
		LEFT JOIN all_users au ON au.user_id=ts.user_id LEFT JOIN all_logs al ON ts.id=al.scheduled_row_id WHERE ts.type='missing-document-collect-sponsor'
		AND ts.event_id='".$event_id."' ORDER BY ts.id DESC ");
	}


	$content =' <div class="">
                     <table id="datatable" class="table table-striped table-bordered table-responsive" style="width:100%">
                     	<tr><th>Template Used</th><th>Sent To</th><th>Sent By</th><th> Date</th> <th>Status</th></tr>
                        <tbody>';
	while($all_logs = mysqli_fetch_array($all_logs_array)){
		$sp_email = '';
		if($all_logs['speaker_emailid'] != ''){$sp_email = $all_logs['speaker_emailid'];}else{$sp_email = 'Speaker has been deleted';}
		
		if($all_logs['template_name']=='Request missing information' || $all_logs['template_name']=='Request missing documents')
		{
			$template_name = "<p>".$all_logs['template_name']."</p>";
		}
		else
		{
			$template_name = "<a href='#' onclick='speakerscheduledTemplateModal1(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";
		}
		
		$read = "";
		if($all_logs['email_read']=='y') {
			$read = '<span class="badge badge-light" style="color: white;background: green;">Opened</span>';
		}else{
			$read = '<span class="badge badge-light" style="color: white;background: red;">Not Opened</span>';
		}



		$content .="<tr>
		<td>".$template_name."</td>
		<td>".$sp_email."</td>
		<td>".$all_logs['username']."</td>
		<td> ".date('d-M-Y', strtotime($all_logs['createdon']))."</td>
		<td>".$read."</td>
		</tr>";
	}
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><span aria-hidden="true"><img src="images/cancel.png" width="20"></span></button>
         <h4 class="modal-title">Previous Emails List</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">
	  '.$content.'</tbody></table></div>
	  
      </div>
   </div>';
}

function getEPEmailsSent(){
$connect = $GLOBALS['connect'];
$id = mysqli_real_escape_string($connect,$_POST['id']);
$event_id= mysqli_real_escape_string($connect,$_POST['event_id']);

$all_logs_array = mysqli_query($connect,"SELECT all_logs.email_read,all_users.first_name,all_logs.id as idd,all_email_templates.id,all_logs.operation as tempname,all_email_templates.template_name,(select email_id from all_speakers where id=all_logs.table_id) as sentto,all_logs.created_at FROM all_logs  LEFT JOIN all_email_templates ON all_email_templates.id=all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by  WHERE (all_logs.operation='sent email to speaker Event Presentation' OR all_logs.operation='sent email to speaker Event Presentation scheduled') AND all_logs.event_id='".$event_id."' and all_logs.event_presentation_id='".$id."'
		union
	SELECT all_logs.email_read,all_users.first_name,all_logs.id as idd,0 as id,all_logs.operation as tempname ,'Missing Information' as template_name,(select email_id from all_speakers where id=all_logs.table_id) as sentto,all_logs.created_at FROM all_logs  LEFT JOIN all_users ON all_users.user_id=all_logs.created_by WHERE (all_logs.operation='Request for Update Agenda') AND all_logs.event_id='".$event_id."' and all_logs.event_presentation_id='".$id."'
	  union
	  SELECT response as email_read,(select first_name from all_users where user_id=tse.created_by) as first_name,tse.id as idd,0 as id,'Schedule Invite' as tempname ,'Schedule Invite' as template_name,tse.email_id as sentto,tse.created_at from team_scheduled_email tse
	 where tse.ep_id='".$id."' and tse.event_id='".$event_id."'");


$content =' <div class="">
                    <table id="datatable" class="table table-bordered test1 table-responsive" style="width:100%">
                       <thead><tr><th>Email Subject</th><th>Sent By</th><th>Sent To</th><th>Date</th><th>Action</th></tr></thead><tbody>';
while($all_logs = mysqli_fetch_array($all_logs_array)){
	if($all_logs['template_name']=='Missing Information' || $all_logs['template_name']=='Schedule Invite')
	{
		if($all_logs['tempname']=='Request for Update Agenda')
		{
			$template_name = "<p>".ucfirst($all_logs['tempname'])."</p>";	
		}else
		{
			$template_name = "<p>".ucfirst($all_logs['tempname'])."</p>";
		}
		
	}else
	{
		$template_name = "<a  onclick='EPTemplateModal1(".$all_logs['idd'].")' data-dismiss='modal' data-toggle='modal' data-target='myModal'>".$all_logs['template_name']."</a>";
	}

$read = "";
if($all_logs['email_read']=='y') {
$read = '<span class="opened" >Opened</span>';
}else{
	if($all_logs['email_read']!='' && $all_logs['template_name']=='Schedule Invite')
	{
		if($all_logs['email_read']=='none')
		{
			$read = '<span class="btn btn-success" style="margin-bottom: -6px;margin-top: -6px;border-radius: 15px !important;padding: 0px 5px 1px;font-size: 12px;display: block;width: 80px;text-align: center;background-color: #f0ad4e !important;border-color: #f0ad4e !important;">'.ucfirst('Not Responded').'</span>';
		}else
		{
			if($all_logs['email_read'] =='accepted' || $all_logs['email_read'] =='tentativelyAccepted')
			{
				$read = '<span class="btn btn-success" style="margin-bottom: -6px;margin-top: -6px;border-radius: 15px !important;padding: 0px 5px 1px;font-size: 12px;display: block;width: 80px;text-align: center;background-color: green !important;border-color: green !important;">'.ucfirst($all_logs['email_read']).'</span>';
			}else
			if($all_logs['email_read'] =='declined')
			{
				$read = '<span class="btn btn-success" style="margin-bottom: -6px;margin-top: -6px;border-radius: 15px !important;padding: 0px 5px 1px;font-size: 12px;display: block;width: 80px;text-align: center;background-color: red !important;border-color: red !important;">'.ucfirst($all_logs['email_read']).'</span>';
			}else
			{
				$read = '<span class="btn btn-success" style="margin-bottom: -6px;margin-top: -6px;border-radius: 15px !important;padding: 0px 5px 1px;font-size: 12px;display: block;width: 80px;text-align: center;">'.ucfirst($all_logs['email_read']).'</span>';
			}

			
		}
		
	}else
	{
		if($all_logs['template_name']=='Schedule Invite')
		{
			$read = '<span class="btn btn-success" style="margin-bottom: -6px;margin-top: -6px;border-radius: 15px !important;padding: 0px 5px 1px;font-size: 12px;display: block;width: 80px;text-align: center;background-color: #f0ad4e !important;border-color: #f0ad4e !important;">Not Responded</span>';
		}else
		{
			$read = '<span class="not_opened" >Not Opened</span>';
		}
		
	}

}
$content .="<tr>
<td>".$template_name."</td>	
<td>".$all_logs['first_name']."</td>
<td>".$all_logs['sentto']."</td>
<td>".date('d-M-Y', strtotime($all_logs['created_at']))."</td>
<td>".$read."</td>
</tr>";
}
echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
  <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
  </button> <!-- Modal content-->
  <div class="modal-content">
     <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><img src="images/cancel.png" width="20"></button>
        <h4 class="modal-title">Previous Emails List</h4>
     </div>
     <div class="custom-modal-text " id="modal_content">
 '.$content.'</tbody></table></div>
 
     </div>
  </div>';	
}

function getEPTemplateModalContent(){
	$connect = $GLOBALS['connect'];
	$log_table_id = mysqli_real_escape_string($connect, $_POST['log_table_id']);
	$sql_all_logs = mysqli_query($connect,"SELECT * FROM all_logs LEFT JOIN all_email_templates ON all_email_templates.id = all_logs.other_column_value LEFT JOIN all_users ON all_users.user_id=all_logs.created_by WHERE all_logs.id=".$log_table_id);
    $all_logs = mysqli_fetch_assoc($sql_all_logs);
	echo '<button type="button" class="close" onclick="Custombox.close();" style="color:black">
   <span onclick="Custombox.close();"><img src="images/cancel.png" width="20"></span><span class="sr-only" style="color:black">Close</span>
   </button> <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="Custombox.close();"><img src="images/cancel.png" width="20"></button>
         <h4 class="modal-title">'.$all_logs['template_name'].'</h4>
      </div>
      <div class="custom-modal-text " id="modal_content">';
	  $cc = $all_logs['cc_emails'];
	  $speaker_manager_email = $all_logs['speaker_manager_email'];
	  $email_subject = $all_logs['email_subject'];
	  if(!$cc) $cc = " Not Found ";
	  if(!$speaker_manager_email) $speaker_manager_email = " Not Found ";
	  if(!$email_subject) $email_subject = " Not Found ";
	  if($all_logs['email_content']){
		  
        echo ' <br>
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-6"><label>Email Subject: </label><br><span style="font-weight:normal">'.$email_subject.'</span></div>
            <div class="col-xs-6"><label>Speaker Manager Email Address: </label><br><span style="font-weight:normal">'.$speaker_manager_email.'</span></div>
           
         </div>
		 <br>
         <div class="row clear-fix" style="margin-bottom:30px">
            <div class="col-xs-6"><label>Cc Email Address: </label><br><span style="font-weight:normal">'.$cc.'</span></div>
           
         </div>
        
       
         <div class="row  clear-fix" style="margin-bottom:30px">
            <div class="col-xs-12"><label>Email Content </label><br></div>
            <div class="col-xs-12"><div class="row clear-fix" style="border: 1px solid #5254568c;margin: 24px;padding: 12px;margin:0px">
				<span style="font-weight:normal">'.$all_logs['email_content'].'</span>
			</div>
			</div>
            <br><br>
         </div>
      </div>
   </div>
         ';
	  }else{
		 echo ' <br>
         <div class="row  clear-fix" style="margin-bottom:30px">
         <center>This feature is implemented on 20th Dec 2018, Previously sent email notifications are not captured properly, so please try to send new notifications and check it!</center>
           
         </div>
		 
        
      </div>
   </div>
         ';
	  }
}

function fetch_all_speaker_for_event_presentation(){

	$connect = $GLOBALS['connect'];
	$ep_id =  $_POST['ep_id'];
	$event_id= $_POST['event_id'];

	$fetch_notes = mysqli_query($connect,"select id,speaker_name,email_id,company from all_speakers where event_id='".$event_id."' and id not in(select speaker_id from event_agenda_speakers where ep_id='".$ep_id."') ORDER BY id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function fetch_all_speaker_for_event_presentation_new(){

	$connect = $GLOBALS['connect'];
	$uniq_token =  $_POST['uniq_token'];
	$event_id= $_POST['event_id'];

	$fetch_notes = mysqli_query($connect,"select id,speaker_name,email_id,company from all_speakers where event_id='".$event_id."' and id not in(select speaker_id from new_event_agenda_speakers where token='".$uniq_token."') ORDER BY id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function add_master_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$master_id = mysqli_real_escape_string($connect, $_POST['master_id']);

	$insert_note = mysqli_query($connect,"INSERT INTO master_notes(notes,master_id,created_by) VALUES('$note_val','$master_id','$loggedin_userid') ");
	if($insert_note){
		echo 'success';
	}else{
		echo 'failed';
	}
}

function fetch_master_notes_by_id(){

	$connect = $GLOBALS['connect'];
	 $master_id =  $_POST['master_id'];
	 //$speaker_id = 224;
	//echo "Arka= ".$speaker_id ;
	$fetch_notes = mysqli_query($connect,"SELECT sn.id as id, sn.notes, sn.master_id, sn.created_by,STR_TO_DATE(sn.created_at, '%Y-%m-$d') as created_at,date_format(sn.created_at, '%d-%b-%Y') as createdon, au.first_name as created_by_name  FROM master_notes sn, all_users au WHERE au.user_id = sn.created_by AND  sn.master_id ='$master_id' ORDER BY sn.id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function update_master_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$master_id = mysqli_real_escape_string($connect, $_POST['master_id']);
	$note_id = mysqli_real_escape_string($connect, $_POST['note_id']);
	$current_time = date('Y-m-d H:i:s');

	$update_note = mysqli_query($connect,"UPDATE master_notes SET notes ='$note_val',created_by='$loggedin_userid',created_at = '$current_time',is_updated = '1' WHERE master_id = '$master_id' AND id  = '$note_id' ");
	if($update_note){
		echo 'success';
	}else{
		echo 'failed';
	}

}

function fetch_all_speaker_after_upload(){

	$connect = $GLOBALS['connect'];
	$event_id =  $_POST['event_id'];

	$fetch_notes = mysqli_query($connect,"select id,speaker_name,email_id,company,phone,is_duplicate from all_speakers_upload_temp where event_id='".$event_id."' ORDER BY is_duplicate desc ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function speaker_upload_proceed(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
		$logged_in_user= $_SESSION['user_id'];	
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	$fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
    $res_sql = mysqli_fetch_array($fetch_sql);
    $session_tanent_id=$res_sql['tanent_id'];

	mysqli_query($connect, "DELETE FROM all_speakers_upload_bkp WHERE event_id=".$event_id."");

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','Proceed upload Speaker','0','".$logged_in_user."',now(),'Proceed upload Speaker')");

	$insert_speaker = mysqli_query($connect, "INSERT INTO `all_speakers_upload_bkp` (`tanent_id`,`speaker_ref_id`,`speaker_name`,`speaker_type`, `email_id`, `company`,`created_by`, `topic_choosen`, `time_slot_from`,`time_slot_to`, `linkedin_handle`,`short_bio`, `title`, `head_shot`,`linkedin_url`, `address1`,`address2`,`city`,`state`,`willing_to_promote`,`willing_to_promote_yes`,`presentation_title1`, `presentation_description1`,`presentation_title2`, `presentation_description2`, `presentation_title3`, `presentation_description3`,`speaker_manager`, `phone`,`speaker_manager_phone`, `speaker_manager_email`,`other_documents`,`status`,`updated_date`,`participation`,`your_quote`,`twitter`,`address`,`country`,`zip`,`facebook`, `instagram`,`linkedin_connections`,`linkedin_lastupdated`,`twitter_followers`, `twitter_lastupdated`,`social_media_total_score`, `is_social_media_sharing_complete`,`is_website_listing_complete`,`is_speaker_coach_assign`,`is_video_promotion_complete`,`is_orientation_attend`,`is_reception_invitation_accept`,`event_id`,`website_name`,`website_url`,`participation_types`,`speaker_requests`,`speaker_expertise`,`acknowledgement`,`profile_completeness`) 

	select tanent_id,id,speaker_name,speaker_type, email_id, company,$logged_in_user, topic_choosen, time_slot_from,time_slot_to, linkedin_handle,short_bio, title, head_shot,linkedin_url, address1,address2,city,state,willing_to_promote,willing_to_promote_yes,presentation_title1, presentation_description1,presentation_title2, presentation_description2, presentation_title3, presentation_description3,speaker_manager, phone,speaker_manager_phone, speaker_manager_email, other_documents,status,updated_date,participation,your_quote,twitter,address,country,zip,facebook, instagram,linkedin_connections,linkedin_lastupdated,twitter_followers, twitter_lastupdated,
				 social_media_total_score, is_social_media_sharing_complete,is_website_listing_complete,is_speaker_coach_assign,is_video_promotion_complete,is_orientation_attend,is_reception_invitation_accept,event_id,website_name,website_url,participation_types,speaker_requests,speaker_expertise,acknowledgement,profile_completeness from all_speakers WHERE `event_id` = '".$event_id."';");
	$version_val=0;
	$query_sql_ver = mysqli_query($connect,"select ifnull(max(version),0) as version  from all_speakers_upload_bkp_archive where event_id='".$event_id."'");
	$query_res_ver = mysqli_fetch_array($query_sql_ver);
	$version_val = $query_res_ver['version'];
	$version_val=$version_val+1;

	$insert_speaker_arch = mysqli_query($connect, "INSERT INTO `all_speakers_upload_bkp_archive` (`tanent_id`,`speaker_ref_id`,`speaker_name`,`speaker_type`, `email_id`, `company`,`created_by`, `topic_choosen`, `time_slot_from`,`time_slot_to`, `linkedin_handle`,`short_bio`, `title`, `head_shot`,`linkedin_url`, `address1`,`address2`,`city`,`state`,`willing_to_promote`,`willing_to_promote_yes`,`presentation_title1`, `presentation_description1`,`presentation_title2`, `presentation_description2`, `presentation_title3`, `presentation_description3`,`speaker_manager`, `phone`,`speaker_manager_phone`, `speaker_manager_email`,`other_documents`,`status`,`updated_date`,`participation`,`your_quote`,`twitter`,`address`,`country`,`zip`,`facebook`, `instagram`,`linkedin_connections`,`linkedin_lastupdated`,`twitter_followers`, `twitter_lastupdated`,`social_media_total_score`, `is_social_media_sharing_complete`,`is_website_listing_complete`,`is_speaker_coach_assign`,`is_video_promotion_complete`,`is_orientation_attend`,`is_reception_invitation_accept`,`event_id`,`website_name`,`website_url`,`participation_types`,`speaker_requests`,`speaker_expertise`,`acknowledgement`,`profile_completeness`,`version`) 

	select tanent_id,id,speaker_name,speaker_type, email_id, company,$logged_in_user, topic_choosen, time_slot_from,time_slot_to, linkedin_handle,short_bio, title, head_shot,linkedin_url, address1,address2,city,state,willing_to_promote,willing_to_promote_yes,presentation_title1, presentation_description1,presentation_title2, presentation_description2, presentation_title3, presentation_description3,speaker_manager, phone,speaker_manager_phone, speaker_manager_email, other_documents,status,updated_date,participation,your_quote,twitter,address,country,zip,facebook, instagram,linkedin_connections,linkedin_lastupdated,twitter_followers, twitter_lastupdated,
				 social_media_total_score, is_social_media_sharing_complete,is_website_listing_complete,is_speaker_coach_assign,is_video_promotion_complete,is_orientation_attend,is_reception_invitation_accept,event_id,website_name,website_url,participation_types,speaker_requests,speaker_expertise,acknowledgement,profile_completeness,$version_val from all_speakers WHERE `event_id` = '".$event_id."';");

	
	mysqli_query($connect,"SET SESSION group_concat_max_len = 1000000");
	$speakers_data1 = mysqli_query($connect,"SELECT group_concat(id) as row_id FROM all_speakers_upload_temp WHERE event_id = '".$event_id."' ");
			if(mysqli_num_rows($speakers_data1) > 0)
       		{  
			   	$res1 = mysqli_fetch_array($speakers_data1);
			   	$row_id = $res1['row_id'];
			   	$resource_ids_array1 = explode(",",$row_id);

			   	foreach ($resource_ids_array1 as $resource_id) { 

			   	 $query_sql = mysqli_query($connect,"SELECT speaker_ref_id FROM all_speakers_upload_temp WHERE id=".$resource_id);
		         $query_res = mysqli_fetch_array($query_sql);
		         $speaker_ref_id = $query_res['speaker_ref_id'];
		   
			   	if($speaker_ref_id!=0)
			   	{

			   		$query_sql_sp = mysqli_query($connect,"select * from all_speakers_upload_temp WHERE `speaker_ref_id`=".$speaker_ref_id);
			   		$query_res_sp = mysqli_fetch_array($query_sql_sp);
		            $name = mysqli_real_escape_string($connect,$query_res_sp['speaker_name']);
		            $email = mysqli_real_escape_string($connect,$query_res_sp['email_id']);
		            $company = mysqli_real_escape_string($connect,$query_res_sp['company']);
		            $phone = mysqli_real_escape_string($connect,$query_res_sp['phone']);
		            $speaker_types_value = mysqli_real_escape_string($connect,$query_res_sp['speaker_type']);
		            $status_value = mysqli_real_escape_string($connect,$query_res_sp['status']);
		            $title = mysqli_real_escape_string($connect,$query_res_sp['title']);
		            $address1 = mysqli_real_escape_string($connect,$query_res_sp['address1']);
		            $address2 = mysqli_real_escape_string($connect,$query_res_sp['address2']);
		            $city = mysqli_real_escape_string($connect,$query_res_sp['city']);
		            $state = mysqli_real_escape_string($connect,$query_res_sp['state']);
		            $country = mysqli_real_escape_string($connect,$query_res_sp['country']);
		            $zip = mysqli_real_escape_string($connect,$query_res_sp['zip']);
		            $speaker_manager = mysqli_real_escape_string($connect,$query_res_sp['speaker_manager']);
		            $speaker_manager_email = mysqli_real_escape_string($connect,$query_res_sp['speaker_manager_email']);
		            $speaker_manager_phone = mysqli_real_escape_string($connect,$query_res_sp['speaker_manager_phone']);
		            $linkedin_url = mysqli_real_escape_string($connect,$query_res_sp['linkedin_url']);
		            $twitter_handle = mysqli_real_escape_string($connect,$query_res_sp['linkedin_handle']);
		            $speaker_requests_value = mysqli_real_escape_string($connect,$query_res_sp['speaker_requests']);
		            $presentation_title1 = mysqli_real_escape_string($connect,$query_res_sp['presentation_title1']);
		            $acknowledgements = mysqli_real_escape_string($connect,$query_res_sp['acknowledgement']);
		        

			   		$fetch_resource_details = mysqli_query($connect, "UPDATE `all_speakers` SET `speaker_name`='".$name."', `email_id`='".$email."', `company`='".$company."',`phone`='".$phone."',`speaker_type`='".$speaker_types_value."',status='".$status_value."', `title`='".$title."',`address1`=  '".$address1."',`address2`='".$address2."', `city`='".$city."',`state`='".$state."',`country`='".$country."',`zip`='".$zip."',`speaker_manager`='".$speaker_manager."',`speaker_manager_email`='".$speaker_manager_email."', `speaker_manager_phone`='".$speaker_manager_phone."',`linkedin_url` = '".$linkedin_url."' ,`linkedin_handle`='".$twitter_handle."',`speaker_requests` ='".$speaker_requests_value."',`presentation_title1`='".mysqli_real_escape_string($connect,$presentation_title1)."',  `acknowledgement`='".strtolower($acknowledgements)."'   WHERE id=".$speaker_ref_id);

			   		    $result_qry = mysqli_query($connect,"select count(id) as exist_cnt  from all_reverted_info where event_id='".$event_id."' and operation_type='Speaker'");
						$result_qry_row = mysqli_fetch_array($result_qry);
						$cnt = $result_qry_row['exist_cnt'];

						if($cnt>0)
						{
							$update_qry = mysqli_query($connect, "UPDATE  `all_reverted_info` SET `is_reverted`='1', `last_reverted_by`='".$logged_in_user."',`updated_at`=now()  WHERE event_id='".$event_id."' and operation_type='Speaker'");
						}else
						{
							$insert_query = mysqli_query($connect,"INSERT INTO `all_reverted_info` (`operation_type`,`tanent_id`,`event_id`,`is_reverted`,`last_reverted_by`) VALUES ('Speaker','0','".$event_id."',1,'".$logged_in_user."')");
						}

			   	}else
			   	{

			   		$result_qry_1 = mysqli_query($connect,"select count(id) as tot_cnt  from all_speakers_upload_temp WHERE id='".$resource_id."' and  `event_id` = '".$event_id."' and is_duplicate=0");
					$result_qry_row_1 = mysqli_fetch_array($result_qry_1);
					$totcnt = $result_qry_row_1['tot_cnt'];

					if($totcnt>0)
					{
						$result_qry = mysqli_query($connect,"select count(id) as exist_cnt  from all_reverted_info where event_id='".$event_id."' and operation_type='Speaker'");
						$result_qry_row = mysqli_fetch_array($result_qry);
						$cnt = $result_qry_row['exist_cnt'];

						if($cnt>0)
						{
							$update_qry = mysqli_query($connect, "UPDATE  `all_reverted_info` SET `is_reverted`='1', `last_reverted_by`='".$logged_in_user."',`updated_at`=now()  WHERE event_id='".$event_id."' and operation_type='Speaker'");
						}else
						{
							$insert_query = mysqli_query($connect,"INSERT INTO `all_reverted_info` (`operation_type`,`tanent_id`,`event_id`,`is_reverted`,`last_reverted_by`) VALUES ('Speaker','0','".$event_id."',1,'".$logged_in_user."')");
						}

					}

				$fetch_resource_details = "INSERT INTO `all_speakers` (`tanent_id`,`speaker_name`,`speaker_type`, `email_id`, `company`, `topic_choosen`, `time_slot_from`,`time_slot_to`, `linkedin_handle`,`short_bio`, `title`, `head_shot`,`linkedin_url`, `address1`,`address2`,`city`,`state`,`willing_to_promote`,`willing_to_promote_yes`,`presentation_title1`, `presentation_description1`,`presentation_title2`, `presentation_description2`, `presentation_title3`, `presentation_description3`,`speaker_manager`, `phone`,`speaker_manager_phone`, `speaker_manager_email`,`other_documents`,`status`,`updated_date`,`participation`,`your_quote`,`twitter`,`address`,`country`,`zip`,`facebook`, `instagram`,`linkedin_connections`,`linkedin_lastupdated`,`twitter_followers`, `twitter_lastupdated`,`social_media_total_score`, `is_social_media_sharing_complete`,`is_website_listing_complete`,`is_speaker_coach_assign`,`is_video_promotion_complete`,`is_orientation_attend`,`is_reception_invitation_accept`,`event_id`,`website_name`,`website_url`,`participation_types`,`speaker_requests`,`speaker_expertise`,`acknowledgement`,`profile_completeness`) 

			select tanent_id,speaker_name,speaker_type, email_id, company,topic_choosen, time_slot_from,time_slot_to, linkedin_handle,short_bio, title, head_shot,linkedin_url, address1,address2,city,state,willing_to_promote,willing_to_promote_yes,presentation_title1, presentation_description1,presentation_title2, presentation_description2, presentation_title3, presentation_description3,speaker_manager, phone,speaker_manager_phone, speaker_manager_email, other_documents,status,updated_date,participation,your_quote,twitter,address,country,zip,facebook, instagram,linkedin_connections,linkedin_lastupdated,twitter_followers, twitter_lastupdated,
					 social_media_total_score, is_social_media_sharing_complete,is_website_listing_complete,is_speaker_coach_assign,is_video_promotion_complete,is_orientation_attend,is_reception_invitation_accept,event_id,website_name,website_url,participation_types,speaker_requests,speaker_expertise,acknowledgement,profile_completeness from all_speakers_upload_temp WHERE id='".$resource_id."' and  `event_id` = '".$event_id."' and is_duplicate=0";

				mysqli_query($connect,$fetch_resource_details);

				$result_qry1 = mysqli_query($connect,"select count(id) as spk_cnt from all_speakers_upload_temp WHERE id='".$resource_id."' and  `event_id` = '".$event_id."' and is_duplicate=0");
				$result_qry_row1 = mysqli_fetch_array($result_qry1);
				$total_spk_cnt = $result_qry_row1['spk_cnt'];

				for($i=0;$i<$total_spk_cnt;$i++)
				{
					//**** add log
					mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','create speaker','0','".$logged_in_user."',now(),'created speakers from excel upload')");

				}

			}

		  }
		}

	if($fetch_resource_details){
		$all_speakers_array = calculate_speaker_dashboard_count($event_id);
		 $speakers_data1 = mysqli_query($connect,"SELECT group_concat(id) as status_id FROM all_status WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($speakers_data1) > 0)
            {  
                $res1 = mysqli_fetch_array($speakers_data1);
                $row_id = $res1['status_id'];
                $status_ids_array1 = explode(",",$row_id);

                foreach ($status_ids_array1 as $statusid) { 
                if($statusid!=0)
                {

                    $query_sql_sp = mysqli_query($connect,"SELECT count(*) as count_spk FROM all_speakers WHERE all_speakers.status='".$statusid."' and all_speakers.event_id='".$event_id."'");
                    $query_res_sp = mysqli_fetch_array($query_sql_sp);
                    $count_spk_res = mysqli_real_escape_string($connect,$query_res_sp['count_spk']);
                
                    $update_status_details = mysqli_query($connect, "UPDATE `all_status` SET `count_of_speaker_usage`='".$count_spk_res."'   WHERE id=".$statusid);

                }

             }
           }

            $speakers_data2 = mysqli_query($connect,"SELECT group_concat(id) as type_id FROM all_speaker_types WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($speakers_data2) > 0)
            {  
                $res2 = mysqli_fetch_array($speakers_data2);
                $row_id2 = $res2['type_id'];
                $status_ids_array2 = explode(",",$row_id2);

                foreach ($status_ids_array2 as $typeid2) { 
                if($typeid2!=0)
                {

                    $query_sql_sp2 = mysqli_query($connect,"SELECT count(*) as count_spk FROM all_speakers WHERE find_in_set('".$typeid2."',all_speakers.speaker_type) and all_speakers.event_id='".$event_id."'");
                    $query_res_sp2 = mysqli_fetch_array($query_sql_sp2);
                    $count_spk_res2 = mysqli_real_escape_string($connect,$query_res_sp2['count_spk']);
                
                    $update_status_details2 = mysqli_query($connect, "UPDATE `all_speaker_types` SET `count_of_speaker_usage`='".$count_spk_res2."'   WHERE id=".$typeid2);

                }

             }
           }
		echo 'success';
		// $all_speakers_array = calculate_speaker_dashboard_count($event_id);
		// $status_update = $common->calculate_speaker_status_count($event_id);
		// $type_update = $common->calculate_speaker_type_count($event_id);
	}else{
		echo 'failed';
	}
}

function speaker_upload_cancel(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
		$logged_in_user= $_SESSION['user_id'];	
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);

	mysqli_query($connect, "INSERT INTO all_logs(operation,table_name,created_by,event_id) VALUES ('Cancel upload speakers','all_speakers','".$logged_in_user."','".$event_id."')");

	$speakers_data1 =mysqli_query($connect, "DELETE FROM all_speakers_upload_temp WHERE event_id=".$event_id."");;
		
	if($speakers_data1){
		echo 'success';
	}else{
		echo 'failed';
	}
}

function speaker_upload_revert(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
		$logged_in_user= $_SESSION['user_id'];	
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);

	mysqli_query($connect, "INSERT INTO all_logs(operation,table_name,created_by,event_id) VALUES ('Revert upload speakers','all_speakers','".$logged_in_user."','".$event_id."')");

	mysqli_query($connect,"SET SESSION group_concat_max_len = 1000000");
	$speakers_data1 = mysqli_query($connect,"SELECT group_concat(speaker_ref_id) as speaker_id FROM all_speakers_upload_bkp WHERE event_id = '".$event_id."' ");
			if(mysqli_num_rows($speakers_data1) > 0)
       		{  
       			$query_sql_cnt_bkp = mysqli_query($connect,"SELECT count(id) as bkp_count FROM all_speakers_upload_bkp WHERE event_id='".$event_id."'");
				 $query_res_bkp = mysqli_fetch_array($query_sql_cnt_bkp);
				 $all_bkp_count = $query_res_bkp['bkp_count'];
				 if($all_bkp_count>0)
				 {
       			mysqli_query($connect, "DELETE FROM all_speakers WHERE id NOT IN (select speaker_ref_id from all_speakers_upload_bkp where event_id='".$event_id."') AND event_id='".$event_id."'");
       		     }

			   	$res1 = mysqli_fetch_array($speakers_data1);
			   	$row_id = $res1['speaker_id'];
			   	$resource_ids_array1 = explode(",",$row_id);

			   	$result_qry = mysqli_query($connect,"select count(id) as exist_cnt  from all_reverted_info where event_id='".$event_id."' and operation_type='Speaker'");
				$result_qry_row = mysqli_fetch_array($result_qry);
				$cnt = $result_qry_row['exist_cnt'];

				if($cnt>0)
				{
					$update_qry = mysqli_query($connect, "UPDATE  `all_reverted_info` SET `is_reverted`='0', `last_reverted_by`='".$logged_in_user."',`updated_at`=now()  WHERE event_id='".$event_id."' and operation_type='Speaker'");
				}else
				{
					$insert_query = mysqli_query($connect,"INSERT INTO `all_reverted_info` (`operation_type`,`tanent_id`,`event_id`,`is_reverted`,`last_reverted_by`) VALUES ('Speaker','0','".$event_id."',0,'".$logged_in_user."')");
				}

			   	foreach ($resource_ids_array1 as $speakerid) {

			   		$query_sql_sp = mysqli_query($connect,"select * from all_speakers_upload_bkp WHERE `speaker_ref_id`='".$speakerid."'");
			   		$query_res_sp = mysqli_fetch_array($query_sql_sp);
		            $name = mysqli_real_escape_string($connect,$query_res_sp['speaker_name']);
		            $email = mysqli_real_escape_string($connect,$query_res_sp['email_id']);
		            $company = mysqli_real_escape_string($connect,$query_res_sp['company']);
		            $phone = mysqli_real_escape_string($connect,$query_res_sp['phone']);
		            $speaker_types_value = mysqli_real_escape_string($connect,$query_res_sp['speaker_type']);
		            $status_value = mysqli_real_escape_string($connect,$query_res_sp['status']);
		            $title = mysqli_real_escape_string($connect,$query_res_sp['title']);
		            $address1 = mysqli_real_escape_string($connect,$query_res_sp['address1']);
		            $address2 = mysqli_real_escape_string($connect,$query_res_sp['address2']);
		            $city = mysqli_real_escape_string($connect,$query_res_sp['city']);
		            $state = mysqli_real_escape_string($connect,$query_res_sp['state']);
		            $country = mysqli_real_escape_string($connect,$query_res_sp['country']);
		            $zip = mysqli_real_escape_string($connect,$query_res_sp['zip']);
		            $speaker_manager = mysqli_real_escape_string($connect,$query_res_sp['speaker_manager']);
		            $speaker_manager_email = mysqli_real_escape_string($connect,$query_res_sp['speaker_manager_email']);
		            $speaker_manager_phone = mysqli_real_escape_string($connect,$query_res_sp['speaker_manager_phone']);
		            $linkedin_url = mysqli_real_escape_string($connect,$query_res_sp['linkedin_url']);
		            $twitter_handle = mysqli_real_escape_string($connect,$query_res_sp['linkedin_handle']);
		            $speaker_requests_value = mysqli_real_escape_string($connect,$query_res_sp['speaker_requests']);
		            $presentation_title1 = mysqli_real_escape_string($connect,$query_res_sp['presentation_title1']);
		            $acknowledgements = mysqli_real_escape_string($connect,$query_res_sp['acknowledgement']);
		        	

			   		$fetch_resource_details = mysqli_query($connect, "UPDATE `all_speakers` SET `speaker_name`='".$name."', `email_id`='".$email."', `company`='".$company."',`phone`='".$phone."',`speaker_type`='".$speaker_types_value."',status='".$status_value."', `title`='".$title."',`address1`=  '".$address1."',`address2`='".$address2."', `city`='".$city."',`state`='".$state."',`country`='".$country."',`zip`='".$zip."',`speaker_manager`='".$speaker_manager."',`speaker_manager_email`='".$speaker_manager_email."', `speaker_manager_phone`='".$speaker_manager_phone."',`linkedin_url` = '".$linkedin_url."' ,`linkedin_handle`='".$twitter_handle."',`speaker_requests` ='".$speaker_requests_value."',
							 `presentation_title1`='".mysqli_real_escape_string($connect,$presentation_title1)."',  `acknowledgement`='".strtolower($acknowledgements)."'   WHERE id=".$speakerid);

			   		if($fetch_resource_details){
			   		mysqli_query($connect, "DELETE FROM all_speakers_upload_bkp WHERE event_id='".$event_id."' and speaker_ref_id='".$speakerid."'");
			   		}
			   		echo 'success';
		  }
		  // $all_speakers_array = calculate_speaker_dashboard_count($event_id);
		  // $status_update = $common->calculate_speaker_status_count($event_id);
		  // $type_update = $common->calculate_speaker_type_count($event_id);
		}
		
		$all_speakers_array = calculate_speaker_dashboard_count($event_id);
		// $status_update = $common->calculate_speaker_status_count($event_id);
		// $type_update = $common->calculate_speaker_type_count($event_id);

	// if($fetch_resource_details){
		
	// }else{
	// 	echo 'failed';
	// }
}

function get_revert_flag_data(){

	$connect = $GLOBALS['connect'];
	$event_id =  $_POST['event_id'];

	 $query_sql = mysqli_query($connect,"SELECT ifnull(max(created_at),0) as last_created_at FROM all_crud_logs WHERE operation='upload speakers' and event_id='".$event_id."'");
	 $query_res = mysqli_fetch_array($query_sql);
	 $last_created_at = $query_res['last_created_at'];

		 if($last_created_at!=0)
		 {
		 	  $now = time(); // or your date as well
		      $your_date = strtotime($last_created_at);
		      $datediff = $now - $your_date;
		      $final_days= round($datediff / (60 * 60 * 24));

		    if($final_days < 7){
			 	$fetch_notes = mysqli_query($connect,"SELECT count(*) as is_sent,(select ifnull(max(is_reverted),0) from all_reverted_info where event_id='".$event_id."' and operation_type='Speaker') as is_revert_flag,
			 		(select count(id) from tbl_sendlatermaildetails where createdon>'".$last_created_at."' and event_id='".$event_id."' and (type='Speaker' OR type='Speaker-bulkmail' OR type='missing-info-collect' OR type='missing-document-collect')) as scheduld_cnt
			 	 FROM all_logs WHERE event_id = '".$event_id."' AND created_at>'".$last_created_at."' AND (all_logs.operation='sent email to speaker scheduled' OR all_logs.operation='sent email to speaker' OR
		 		all_logs.operation='request missing information' OR all_logs.operation='request missing documents' OR
		 		all_logs.operation='request missing information scheduled' OR all_logs.operation='request missing documents scheduled' ) ");
	 		}else
				{
					$fetch_notes = mysqli_query($connect,"SELECT 0 as is_sent,0 as is_revert_flag,0 as scheduld_cnt FROM all_logs WHERE event_id = '".$event_id."' ");
				}

		 }else
		 {
		 	$fetch_notes = mysqli_query($connect,"SELECT 0 as is_sent,0 as is_revert_flag,0 as scheduld_cnt FROM all_logs WHERE event_id = '".$event_id."' ");
		 }
	

	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function fetch_all_sponsor_after_upload(){

	$connect = $GLOBALS['connect'];
	$event_id =  $_POST['event_id'];

	$fetch_notes = mysqli_query($connect,"select id,sponsor_contact_person,sponsor_contact_email_address,sponsor_company_name,sponsor_contact_number,is_duplicate from all_sponsors_upload_temp where event_id='".$event_id."' ORDER BY is_duplicate desc ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function sponsor_upload_proceed(){
	$res_array = array();
	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
		$logged_in_user= $_SESSION['user_id'];	
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	$fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
    $res_sql = mysqli_fetch_array($fetch_sql);
    $session_tanent_id=$res_sql['tanent_id'];

	mysqli_query($connect, "DELETE FROM all_sponsors_upload_bkp WHERE event_id=".$event_id."");

	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,created_by,table_name) VALUES ('".$session_tanent_id."','".$event_id."''Proceed upload sponsors','".$logged_in_user."','Proceed upload sponsors')");

	$insert_sponsor = mysqli_query($connect, "INSERT INTO `all_sponsors_upload_bkp` (`tanent_id`,`sponsor_ref_id`,`sponsor_company_name`,`created_by`, `sponsor_type`, `sponsor_contact_person`, `sponsor_contact_number`,
 	`sponsor_contact_email_address`, `sponsor_role`,`secondary1_sponsor_contact_person`, `secondary1_sponsor_contact_number`, `secondary1_sponsor_contact_email_address`, `secondary1_sponsor_role`,`secondary2_sponsor_contact_person`, `secondary2_sponsor_contact_number`, `secondary2_sponsor_contact_email_address`, `secondary2_sponsor_role`, 
	 `sponsor_bio`, `facebook_url`, `twitter_url`, `linkedin_url`, `instagram_url`, `address1`,`address2`,`city`,`state`, `banner_image`,`status`, `other_documents`,`updated_date`,`event_id`,`company_url`,`country`,`zipcode`,`sponsor_logo`,`total_social_media_reach`,`total_email_reach`,`other_contact_name`,`other_contact_number`,`other_email_address`,`other_role`,`potential_funding_ask`,`committed_funding`,`estimated_time_to_close`,`close_date`)

             	select tanent_id,id,sponsor_company_name,$logged_in_user, sponsor_type, sponsor_contact_person, sponsor_contact_number, sponsor_contact_email_address, sponsor_role,secondary1_sponsor_contact_person, secondary1_sponsor_contact_number, secondary1_sponsor_contact_email_address, secondary1_sponsor_role,secondary2_sponsor_contact_person, secondary2_sponsor_contact_number, secondary2_sponsor_contact_email_address, secondary2_sponsor_role, sponsor_bio, facebook_url, twitter_url, linkedin_url, instagram_url, address1,address2,city,state, banner_image,status,other_documents,updated_date,$event_id,company_url,country,zipcode,sponsor_logo,total_social_media_reach,total_email_reach,other_contact_name,other_contact_number,other_email_address,other_role,potential_funding_ask,committed_funding,estimated_time_to_close,close_date from all_sponsors WHERE `event_id` = '".$event_id."'");

	$version_val=0;
	$query_sql_ver = mysqli_query($connect,"select ifnull(max(version),0) as version  from all_sponsors_upload_bkp_archive where event_id='".$event_id."'");
	$query_res_ver = mysqli_fetch_array($query_sql_ver);
	$version_val = $query_res_ver['version'];
	$version_val=$version_val+1;

	$insert_speaker_arch = mysqli_query($connect, "INSERT INTO `all_sponsors_upload_bkp_archive` (`tanent_id`,`sponsor_ref_id`,`sponsor_company_name`,`created_by`, `sponsor_type`, `sponsor_contact_person`, `sponsor_contact_number`,
 	`sponsor_contact_email_address`, `sponsor_role`,`secondary1_sponsor_contact_person`, `secondary1_sponsor_contact_number`, `secondary1_sponsor_contact_email_address`, `secondary1_sponsor_role`,`secondary2_sponsor_contact_person`, `secondary2_sponsor_contact_number`, `secondary2_sponsor_contact_email_address`, `secondary2_sponsor_role`, 
	 `sponsor_bio`, `facebook_url`, `twitter_url`, `linkedin_url`, `instagram_url`, `address1`,`address2`,`city`,`state`, `banner_image`,`status`, `other_documents`,`updated_date`,`event_id`,`company_url`,`country`,`zipcode`,`sponsor_logo`,`total_social_media_reach`,`total_email_reach`,`other_contact_name`,`other_contact_number`,`other_email_address`,`other_role`,`potential_funding_ask`,`committed_funding`,`estimated_time_to_close`,`close_date`,`version`) 

	select tanent_id,id,sponsor_company_name,$logged_in_user, sponsor_type, sponsor_contact_person, sponsor_contact_number, sponsor_contact_email_address, sponsor_role,secondary1_sponsor_contact_person, secondary1_sponsor_contact_number, secondary1_sponsor_contact_email_address, secondary1_sponsor_role,secondary2_sponsor_contact_person, secondary2_sponsor_contact_number, secondary2_sponsor_contact_email_address, secondary2_sponsor_role, sponsor_bio, facebook_url, twitter_url, linkedin_url, instagram_url, address1,address2,city,state, banner_image,status,other_documents,updated_date,$event_id,company_url,country,zipcode,sponsor_logo,total_social_media_reach,total_email_reach,other_contact_name,other_contact_number,other_email_address,other_role,potential_funding_ask,committed_funding,estimated_time_to_close,close_date,$version_val from all_sponsors WHERE `event_id` = '".$event_id."'");

	mysqli_query($connect,"SET SESSION group_concat_max_len = 1000000");
	$speakers_data1 = mysqli_query($connect,"SELECT group_concat(id) as row_id FROM all_sponsors_upload_temp WHERE event_id = '".$event_id."' ");
			if(mysqli_num_rows($speakers_data1) > 0)
       		{  
			   	$res1 = mysqli_fetch_array($speakers_data1);
			   	$row_id = $res1['row_id'];
			   	$resource_ids_array1 = explode(",",$row_id);

			   	foreach ($resource_ids_array1 as $resource_id) { 

			   	 $query_sql = mysqli_query($connect,"SELECT sponsor_ref_id FROM all_sponsors_upload_temp WHERE id=".$resource_id);
		         $query_res = mysqli_fetch_array($query_sql);
		         $speaker_ref_id = $query_res['sponsor_ref_id'];
		   
			   	if($speaker_ref_id!=0)
			   	{

			   		$query_sql_sp = mysqli_query($connect,"SELECT * from all_sponsors_upload_temp WHERE `sponsor_ref_id`=".$speaker_ref_id);
			   		$query_res_sp = mysqli_fetch_array($query_sql_sp);
		            $sponsor_company_name = $query_res_sp['sponsor_company_name'];
		            $sponsor_contact_person = $query_res_sp['sponsor_contact_person'];
		            $sponsor_contact_number = $query_res_sp['sponsor_contact_number'];
		            $sponsor_contact_email_address = $query_res_sp['sponsor_contact_email_address'];
		            $sponsor_role = $query_res_sp['sponsor_role'];
		            $secondary1_sponsor_contact_person = $query_res_sp['secondary1_sponsor_contact_person'];
		            $secondary1_sponsor_contact_number = $query_res_sp['secondary1_sponsor_contact_number'];
		            $secondary1_sponsor_contact_email_address = $query_res_sp['secondary1_sponsor_contact_email_address'];
		            $secondary1_sponsor_role = $query_res_sp['secondary1_sponsor_role'];
		            $secondary2_sponsor_contact_person = $query_res_sp['secondary2_sponsor_contact_person'];
		            $secondary2_sponsor_contact_number = $query_res_sp['secondary2_sponsor_contact_number'];
		            $secondary2_sponsor_contact_email_address = $query_res_sp['secondary2_sponsor_contact_email_address'];
		            $secondary2_sponsor_role = $query_res_sp['secondary2_sponsor_role'];
		            $sponsor_bio = $query_res_sp['sponsor_bio'];
		            $facebook_url = mysqli_real_escape_string($connect,$query_res_sp['facebook_url']);
		            $twitter_url = mysqli_real_escape_string($connect,$query_res_sp['twitter_url']);
		            $linkedin_url = mysqli_real_escape_string($connect,$query_res_sp['linkedin_url']);
		            $instagram_url = mysqli_real_escape_string($connect,$query_res_sp['instagram_url']);
		            $address1 = $query_res_sp['address1'];
		            $address2 = $query_res_sp['address1'];
		            $city = $query_res_sp['city'];
		            $state = $query_res_sp['state'];
		        
			   		$fetch_resource_details = mysqli_query($connect, "UPDATE `all_sponsors` SET  `sponsor_company_name`='".mysqli_real_escape_string($connect,$sponsor_company_name)."',`sponsor_contact_person`='".mysqli_real_escape_string($connect,$sponsor_contact_person)."', `sponsor_contact_number`='".$sponsor_contact_number."', `sponsor_contact_email_address`='".mysqli_real_escape_string($connect,$sponsor_contact_email_address)."',`sponsor_role`='".mysqli_real_escape_string($connect,$sponsor_role)."',`secondary1_sponsor_contact_person`='".mysqli_real_escape_string($connect,$secondary1_sponsor_contact_person)."', `secondary1_sponsor_contact_number`='".$secondary1_sponsor_contact_number."', `secondary1_sponsor_contact_email_address`='".mysqli_real_escape_string($connect,$secondary1_sponsor_contact_email_address)."', `secondary1_sponsor_role`='".mysqli_real_escape_string($connect,$secondary1_sponsor_role)."',`secondary2_sponsor_contact_person`='".mysqli_real_escape_string($connect,$secondary2_sponsor_contact_person)."', `secondary2_sponsor_contact_number`='".$secondary2_sponsor_contact_number."', `secondary2_sponsor_contact_email_address`='".mysqli_real_escape_string($connect,$secondary2_sponsor_contact_email_address)."', `secondary2_sponsor_role`='".mysqli_real_escape_string($connect,$secondary2_sponsor_role)."', `sponsor_bio`='".mysqli_real_escape_string($connect,$sponsor_bio)."', `facebook_url`='".$facebook_url."', `twitter_url`='".$twitter_url."', `linkedin_url`='".$linkedin_url."', `instagram_url`='".$instagram_url."', `address1`='".mysqli_real_escape_string($connect,$address1)."',`address2`='".mysqli_real_escape_string($connect,$address2)."',`city`='".mysqli_real_escape_string($connect,$city)."',`state`='".$state."' WHERE id=".$speaker_ref_id);

			   			$result_qry = mysqli_query($connect,"select count(id) as exist_cnt  from all_reverted_info where event_id='".$event_id."' and operation_type='Sponsor'");
						$result_qry_row = mysqli_fetch_array($result_qry);
						$cnt = $result_qry_row['exist_cnt'];

						if($cnt>0)
						{
							$update_qry = mysqli_query($connect, "UPDATE  `all_reverted_info` SET `is_reverted`='1', `last_reverted_by`='".$logged_in_user."',`updated_at`=now()  WHERE event_id='".$event_id."' and operation_type='Sponsor'");
						}else
						{
							$insert_query = mysqli_query($connect,"INSERT INTO `all_reverted_info` (`operation_type`,`tanent_id`,`event_id`,`is_reverted`,`last_reverted_by`) VALUES ('Sponsor','0','".$event_id."',1,'".$logged_in_user."')");
						}


			   	}else
			   	{

			   		$result_qry_1 = mysqli_query($connect,"select count(id) as tot_cnt  from all_sponsors_upload_temp WHERE id='".$resource_id."' and  `event_id` = '".$event_id."' and is_duplicate=0");
					$result_qry_row_1 = mysqli_fetch_array($result_qry_1);
					$totcnt = $result_qry_row_1['tot_cnt'];

					if($totcnt>0)
					{
						$result_qry = mysqli_query($connect,"select count(id) as exist_cnt  from all_reverted_info where event_id='".$event_id."' and operation_type='Sponsor'");
						$result_qry_row = mysqli_fetch_array($result_qry);
						$cnt = $result_qry_row['exist_cnt'];

						if($cnt>0)
						{
							$update_qry = mysqli_query($connect, "UPDATE  `all_reverted_info` SET `is_reverted`='1', `last_reverted_by`='".$logged_in_user."',`updated_at`=now()  WHERE event_id='".$event_id."' and operation_type='Sponsor'");
						}else
						{
							$insert_query = mysqli_query($connect,"INSERT INTO `all_reverted_info` (`operation_type`,`tanent_id`,`event_id`,`is_reverted`,`last_reverted_by`) VALUES ('Sponsor','0','".$event_id."',1,'".$logged_in_user."')");
						}

					}

				$fetch_resource_details = "INSERT INTO `all_sponsors` (`tanent_id`,`sponsor_company_name`, `sponsor_contact_person`, `sponsor_contact_number`, `sponsor_contact_email_address`,`sponsor_role`,`secondary1_sponsor_contact_person`, `secondary1_sponsor_contact_number`, `secondary1_sponsor_contact_email_address`, `secondary1_sponsor_role`,`secondary2_sponsor_contact_person`, `secondary2_sponsor_contact_number`, `secondary2_sponsor_contact_email_address`, `secondary2_sponsor_role`, `sponsor_bio`, `facebook_url`, `twitter_url`, `linkedin_url`, `instagram_url`, `address1`,`address2`,`city`,`state`,`event_id`) 

			select tanent_id,sponsor_company_name,sponsor_contact_person, sponsor_contact_number, sponsor_contact_email_address,sponsor_role, secondary1_sponsor_contact_person,secondary1_sponsor_contact_number, secondary1_sponsor_contact_email_address,secondary1_sponsor_role, secondary2_sponsor_contact_person, secondary2_sponsor_contact_number,secondary2_sponsor_contact_email_address, secondary2_sponsor_role,sponsor_bio,facebook_url,twitter_url,linkedin_url,instagram_url,address1,address2,city,state,event_id from all_sponsors_upload_temp WHERE id='".$resource_id."' and  `event_id` = '".$event_id."' and is_duplicate=0";

			mysqli_query($connect,$fetch_resource_details);

				$result_qry1 = mysqli_query($connect,"select count(id) as spk_cnt from all_sponsors_upload_temp WHERE id='".$resource_id."' and  `event_id` = '".$event_id."' and is_duplicate=0");
				$result_qry_row1 = mysqli_fetch_array($result_qry1);
				$total_spk_cnt = $result_qry_row1['spk_cnt'];

				for($i=0;$i<$total_spk_cnt;$i++)
				{
					//**** add log
					mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','create sponsor','0','".$logged_in_user."',now(),'created sponsors from excel upload')");

				}
			}

		  }
		}

	if($fetch_resource_details){
		$all_speakers_array = calculate_sponsor_dashboard_count($event_id);

        $speakers_data1 = mysqli_query($connect,"SELECT group_concat(id) as status_id FROM all_status WHERE event_id = '".$event_id."' and status_for='sponsor' ");
            if(mysqli_num_rows($speakers_data1) > 0)
            {  
                $res1 = mysqli_fetch_array($speakers_data1);
                $row_id = $res1['status_id'];
                $status_ids_array1 = explode(",",$row_id);

                foreach ($status_ids_array1 as $statusid) { 
                if($statusid!=0)
                {

                    $query_sql_sp = mysqli_query($connect,"SELECT count(*) as count_spk FROM all_sponsors WHERE all_sponsors.status='".$statusid."' and all_sponsors.event_id='".$event_id."'");
                    $query_res_sp = mysqli_fetch_array($query_sql_sp);
                    $count_spk_res = mysqli_real_escape_string($connect,$query_res_sp['count_spk']);
                
                    $update_status_details = mysqli_query($connect, "UPDATE `all_status` SET `count_of_speaker_usage`='".$count_spk_res."'   WHERE id=".$statusid);

                }

             }
           }

          $speakers_data2 = mysqli_query($connect,"SELECT group_concat(id) as type_id FROM all_sponsor_types WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($speakers_data2) > 0)
            {  
                $res2 = mysqli_fetch_array($speakers_data2);
                $row_id2 = $res2['type_id'];
                $status_ids_array2 = explode(",",$row_id2);

                foreach ($status_ids_array2 as $typeid) { 
                if($typeid!=0)
                {

                    $query_sql_sp2 = mysqli_query($connect,"SELECT count(*) as count_spk FROM all_sponsors WHERE find_in_set('".$typeid."',all_sponsors.sponsor_type) and all_sponsors.event_id='".$event_id."'");
                    $query_res_sp2 = mysqli_fetch_array($query_sql_sp2);
                    $count_spk_res2 = mysqli_real_escape_string($connect,$query_res_sp2['count_spk']);
                
                    $update_status_details2 = mysqli_query($connect, "UPDATE `all_sponsor_types` SET `total_enrolled`='".$count_spk_res2."'   WHERE id=".$typeid);

                }

             }
           }
		$res_array['status'] = 'success';
		$res_array['encoded_eventid'] = base64_encode($event_id).':'.base64_encode(rand(100,999));
		echo json_encode($res_array);
	}else{
		$res_array['status'] = 'failed';
		$res_array['encoded_eventid'] = base64_encode($event_id).':'.base64_encode(rand(100,999));
		echo json_encode($res_array);
	}
}

function sponsor_upload_cancel(){

	$connect = $GLOBALS['connect'];
	$res_array = array();
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);

	mysqli_query($connect, "INSERT INTO all_logs(operation,table_name,created_by,event_id) VALUES ('Cancel upload sponsors','all_sponsors','".$logged_in_user."','".$event_id."')");
	$speakers_data1 =mysqli_query($connect, "DELETE FROM all_sponsors_upload_temp WHERE event_id=".$event_id."");;
		
	if($speakers_data1){
		$res_array['status'] = 'success';
		$res_array['encoded_eventid'] = base64_encode($event_id).':'.base64_encode(rand(100,999));
		echo json_encode($res_array);
		
	}else{
		
		$res_array['status'] = 'failed';
		$res_array['encoded_eventid'] = base64_encode($event_id).':'.base64_encode(rand(100,999));
		echo json_encode($res_array);
	}
}

function sponsor_upload_revert(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
		$logged_in_user= $_SESSION['user_id'];	
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);

	mysqli_query($connect, "INSERT INTO all_logs(operation,table_name,created_by,event_id) VALUES ('Revert upload sponsors','all_sponsors','".$logged_in_user."','".$event_id."')");

	mysqli_query($connect,"SET SESSION group_concat_max_len = 1000000");
	$speakers_data1 = mysqli_query($connect,"SELECT group_concat(sponsor_ref_id) as sponsor_ref_id FROM all_sponsors_upload_bkp WHERE event_id = '".$event_id."' ");
			if(mysqli_num_rows($speakers_data1) > 0)
       		{  
       			$query_sql_cnt_bkp = mysqli_query($connect,"SELECT count(id) as bkp_count FROM all_sponsors_upload_bkp WHERE event_id='".$event_id."'");
				 $query_res_bkp = mysqli_fetch_array($query_sql_cnt_bkp);
				 $all_bkp_count = $query_res_bkp['bkp_count'];
				 if($all_bkp_count>0)
				 {
       			mysqli_query($connect, "DELETE FROM all_sponsors WHERE id NOT IN (select sponsor_ref_id from all_sponsors_upload_bkp where event_id='".$event_id."') AND event_id='".$event_id."'");
       			 }

			   	$res1 = mysqli_fetch_array($speakers_data1);
			   	$row_id = $res1['sponsor_ref_id'];
			   	$resource_ids_array1 = explode(",",$row_id);

			   	$result_qry = mysqli_query($connect,"select count(id) as exist_cnt  from all_reverted_info where event_id='".$event_id."' and operation_type='Sponsor'");
				$result_qry_row = mysqli_fetch_array($result_qry);
				$cnt = $result_qry_row['exist_cnt'];

				if($cnt>0)
				{
					$update_qry = mysqli_query($connect, "UPDATE  `all_reverted_info` SET `is_reverted`='0', `last_reverted_by`='".$logged_in_user."',`updated_at`=now()  WHERE event_id='".$event_id."' and operation_type='Sponsor'");
				}else
				{
					$insert_query = mysqli_query($connect,"INSERT INTO `all_reverted_info` (`operation_type`,`tanent_id`,`event_id`,`is_reverted`,`last_reverted_by`) VALUES ('Sponsor','0','".$event_id."',0,'".$logged_in_user."')");
				}

			   	foreach ($resource_ids_array1 as $speakerid) {

			   		$query_sql_sp = mysqli_query($connect,"select * from all_sponsors_upload_bkp WHERE `sponsor_ref_id`='".$speakerid."'");
			   		$query_res_sp = mysqli_fetch_array($query_sql_sp);
		            $sponsor_company_name = mysqli_real_escape_string($connect,$query_res_sp['sponsor_company_name']);
		            $sponsor_contact_person = mysqli_real_escape_string($connect,$query_res_sp['sponsor_contact_person']);
		            $sponsor_contact_number = mysqli_real_escape_string($connect,$query_res_sp['sponsor_contact_number']);
		            $sponsor_contact_email_address = mysqli_real_escape_string($connect,$query_res_sp['sponsor_contact_email_address']);
		            $sponsor_role = mysqli_real_escape_string($connect,$query_res_sp['sponsor_role']);
		            $secondary1_sponsor_contact_person = mysqli_real_escape_string($connect,$query_res_sp['secondary1_sponsor_contact_person']);
		            $secondary1_sponsor_contact_number = mysqli_real_escape_string($connect,$query_res_sp['secondary1_sponsor_contact_number']);
		            $secondary1_sponsor_contact_email_address = mysqli_real_escape_string($connect,$query_res_sp['secondary1_sponsor_contact_email_address']);
		            $secondary1_sponsor_role = mysqli_real_escape_string($connect,$query_res_sp['secondary1_sponsor_role']);
		            $secondary2_sponsor_contact_person = mysqli_real_escape_string($connect,$query_res_sp['secondary2_sponsor_contact_person']);
		            $secondary2_sponsor_contact_number = mysqli_real_escape_string($connect,$query_res_sp['secondary2_sponsor_contact_number']);
		            $secondary2_sponsor_contact_email_address = mysqli_real_escape_string($connect,$query_res_sp['secondary2_sponsor_contact_email_address']);
		            $secondary2_sponsor_role = mysqli_real_escape_string($connect,$query_res_sp['secondary2_sponsor_role']);
		            $sponsor_bio = mysqli_real_escape_string($connect,$query_res_sp['sponsor_bio']);
		            $facebook_url = mysqli_real_escape_string($connect,$query_res_sp['facebook_url']);
		            $twitter_url = mysqli_real_escape_string($connect,$query_res_sp['twitter_url']);
		            $linkedin_url = mysqli_real_escape_string($connect,$query_res_sp['linkedin_url']);
		            $instagram_url = mysqli_real_escape_string($connect,$query_res_sp['instagram_url']);
		            $address1 = mysqli_real_escape_string($connect,$query_res_sp['address1']);
		            $address2 = mysqli_real_escape_string($connect,$query_res_sp['address1']);
		            $city = mysqli_real_escape_string($connect,$query_res_sp['city']);
		            $state = mysqli_real_escape_string($connect,$query_res_sp['state']);
		        	

			   		$fetch_resource_details = mysqli_query($connect, "UPDATE `all_sponsors` SET  `sponsor_company_name`='".$sponsor_company_name."',`sponsor_contact_person`='".$sponsor_contact_person."', `sponsor_contact_number`='".$sponsor_contact_number."', `sponsor_contact_email_address`='".$sponsor_contact_email_address."',`sponsor_role`='".$sponsor_role."',`secondary1_sponsor_contact_person`='".$secondary1_sponsor_contact_person."', `secondary1_sponsor_contact_number`='".$secondary1_sponsor_contact_number."', `secondary1_sponsor_contact_email_address`='".$secondary1_sponsor_contact_email_address."', `secondary1_sponsor_role`='".$secondary1_sponsor_role."',`secondary2_sponsor_contact_person`='".$secondary2_sponsor_contact_person."', `secondary2_sponsor_contact_number`='".$secondary2_sponsor_contact_number."', `secondary2_sponsor_contact_email_address`='".$secondary2_sponsor_contact_email_address."', `secondary2_sponsor_role`='".$secondary2_sponsor_role."', `sponsor_bio`='".$sponsor_bio."', `facebook_url`='".$facebook_url."', `twitter_url`='".$twitter_url."', `linkedin_url`='".$linkedin_url."', `instagram_url`='".$instagram_url."', `address1`='".$address1."',`address2`='".$address2."',`city`='".$city."',`state`='".$state."' WHERE id=".$speakerid);

			   		if($fetch_resource_details){
			   		mysqli_query($connect, "DELETE FROM all_sponsors_upload_bkp WHERE event_id='".$event_id."' and sponsor_ref_id='".$speakerid."'");
			   		}
			   		echo 'success';

		  }
		}
		$all_speakers_array = calculate_sponsor_dashboard_count($event_id);
	//if($fetch_resource_details){
		
	// }else{
	// 	echo 'failed';
	// }
}

function sponsor_get_revert_flag_data(){

	$connect = $GLOBALS['connect'];
	$event_id =  $_POST['event_id'];

	 $query_sql = mysqli_query($connect,"SELECT ifnull(max(created_at),0) as last_created_at FROM all_crud_logs WHERE operation='upload sponsor' and event_id='".$event_id."'");
	 $query_res = mysqli_fetch_array($query_sql);
	 $last_created_at = $query_res['last_created_at'];

	 if($last_created_at!=0)
	 {
	 		  $now = time(); // or your date as well
		      $your_date = strtotime($last_created_at);
		      $datediff = $now - $your_date;
		      $final_days= round($datediff / (60 * 60 * 24));
		      
		    if($final_days < 7){
		 	$fetch_notes = mysqli_query($connect,"SELECT count(*) as is_sent,(select ifnull(max(is_reverted),0) from all_reverted_info where event_id='".$event_id."' and operation_type='Sponsor') as is_revert_flag,
		 		(select count(id) from tbl_sendlatermaildetails where createdon>'".$last_created_at."' and event_id='".$event_id."' and (type='Sponser' OR type='Sponser-bulkmail' OR type='missing-info-collect-sponsor' OR type='missing-document-collect-sponsor')) as scheduld_cnt
		 	 FROM all_logs WHERE event_id = '".$event_id."' AND created_at>'".$last_created_at."' AND (all_logs.operation='sent email to sponsor scheduled' OR all_logs.operation='sent email to sponsor' OR
	 		all_logs.operation='request missing information sponsor scheduled' OR all_logs.operation='request missing documents sponsor scheduled' OR
	 		all_logs.operation='request missing information sponsor' OR all_logs.operation='request missing documents sponsor' ) ");
		 }else
		 {
		 	$fetch_notes = mysqli_query($connect,"SELECT 0 as is_sent,0 as is_revert_flag,0 as scheduld_cnt FROM all_logs");
		 }

	 }else
	 {
	 	$fetch_notes = mysqli_query($connect,"SELECT 0 as is_sent,0 as is_revert_flag,0 as scheduld_cnt FROM all_logs");
	 }

	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function fetch_all_master_after_upload(){
	$res_array = array();
	$connect = $GLOBALS['connect'];
	$event_id =  $_POST['event_id'];

	$fetch_notes = mysqli_query($connect,"SELECT master_name,email_id,company,phone,is_duplicate from all_masters_upload_temp where event_id='".$event_id."' ORDER BY is_duplicate desc ");
	
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	
	echo json_encode($res_array);
}

function master_upload_proceed(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
		$logged_in_user= $_SESSION['user_id'];	
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	$fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_events where id='".$event_id."' ");       
    $res_sql = mysqli_fetch_array($fetch_sql);
    $session_tanent_id=$res_sql['tanent_id'];

	mysqli_query($connect, "DELETE FROM all_masters_upload_bkp WHERE event_id=".$event_id."");
	mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','Proceed upload master','0','".$logged_in_user."',now(),'Proceed upload Speaker')");

	$insert_speaker = mysqli_query($connect, "INSERT INTO `all_masters_upload_bkp` (`master_id`,`tanent_id`,`master_name`,`phone`,`master_type`,`email_id`, `company`,`job_title`,`linkedin_url`,`created_by`,`event_id`,`twitter_url`,`is_approved`) 
	select id,tanent_id,master_name,phone,master_type,email_id,company,job_title,linkedin_url,$logged_in_user,event_id,twitter_url,is_approved from all_masters WHERE `event_id` = '".$event_id."';");
	$version_val=0;
	$query_sql_ver = mysqli_query($connect,"select ifnull(max(version),0) as version  from all_masters_upload_bkp_archive where event_id='".$event_id."'");
	$query_res_ver = mysqli_fetch_array($query_sql_ver);
	$version_val = $query_res_ver['version'];
	$version_val=$version_val+1;

	$insert_speaker_arch = mysqli_query($connect, "INSERT INTO `all_masters_upload_bkp_archive` (`master_ref_id`,`tanent_id`,`master_name`,`phone`,`master_type`,`email_id`, `company`,`job_title`,`linkedin_url`,`created_by`,`event_id`,`twitter_url`,`is_approved`,`version`) 

	select id,tanent_id,master_name,phone,master_type,email_id,company,job_title,linkedin_url,$logged_in_user,event_id,twitter_url,is_approved,$version_val from all_masters WHERE `event_id` = '".$event_id."';");

	
	mysqli_query($connect,"SET SESSION group_concat_max_len = 1000000");
	$speakers_data1 = mysqli_query($connect,"SELECT group_concat(id) as row_id FROM all_masters_upload_temp WHERE event_id = '".$event_id."' ");
			if(mysqli_num_rows($speakers_data1) > 0)
       		{  
			   	$res1 = mysqli_fetch_array($speakers_data1);
			   	$row_id = $res1['row_id'];
			   	$resource_ids_array1 = explode(",",$row_id);
		
			   	foreach ($resource_ids_array1 as $resource_id) { 

			   	 $query_sql = mysqli_query($connect,"SELECT master_id FROM all_masters_upload_temp WHERE id=".$resource_id);
		         $query_res = mysqli_fetch_array($query_sql);
		         $master_ref_id = $query_res['master_id'];
		   
			   	if($master_ref_id!=0)
			   	{

			   		$query_sql_sp = mysqli_query($connect,"select * from all_masters_upload_temp WHERE `master_id`=".$master_ref_id);
			   		$query_res_sp = mysqli_fetch_array($query_sql_sp);
		            $name = mysqli_real_escape_string($connect,$query_res_sp['master_name']);
		            $email = mysqli_real_escape_string($connect,$query_res_sp['email_id']);
		            $company = mysqli_real_escape_string($connect,$query_res_sp['company']);
		            $phone = mysqli_real_escape_string($connect,$query_res_sp['phone']);
		            $master_types_value = mysqli_real_escape_string($connect,$query_res_sp['master_type']);
		            $job_title = mysqli_real_escape_string($connect,$query_res_sp['job_title']);
		            $linkedin_url = mysqli_real_escape_string($connect,$query_res_sp['linkedin_url']);

			   		$fetch_resource_details = mysqli_query($connect, "UPDATE  `all_masters` SET `master_name`='".$name."', `email_id`='".$email."', `company`='".$company."',`phone`='".$phone."',`master_type`= '".$master_types_value."',`job_title`='".$job_title."',`linkedin_url` = '".$linkedin_url."'  WHERE id=".$master_ref_id);

			   		$result_qry = mysqli_query($connect,"select count(id) as exist_cnt  from all_reverted_info where event_id='".$event_id."' and operation_type='Master'");
						$result_qry_row = mysqli_fetch_array($result_qry);
						$cnt = $result_qry_row['exist_cnt'];

						if($cnt>0)
						{
							$update_qry = mysqli_query($connect, "UPDATE  `all_reverted_info` SET `is_reverted`='1', `last_reverted_by`='".$logged_in_user."',`updated_at`=now()  WHERE event_id='".$event_id."' and operation_type='Master'");
						}else
						{
							$insert_query = mysqli_query($connect,"INSERT INTO `all_reverted_info` (`operation_type`,`tanent_id`,`event_id`,`is_reverted`,`last_reverted_by`) VALUES ('Master','0','".$event_id."',1,'".$logged_in_user."')");
						}
						

			   	}else
			   	{

			   		$result_qry_1 = mysqli_query($connect,"select count(id) as tot_cnt  from all_masters_upload_temp WHERE id='".$resource_id."' and  `event_id` = '".$event_id."' and is_duplicate=0");
					$result_qry_row_1 = mysqli_fetch_array($result_qry_1);
					$totcnt = $result_qry_row_1['tot_cnt'];

					if($totcnt>0)
					{
						$result_qry = mysqli_query($connect,"select count(id) as exist_cnt  from all_reverted_info where event_id='".$event_id."' and operation_type='Master'");
						$result_qry_row = mysqli_fetch_array($result_qry);
						$cnt = $result_qry_row['exist_cnt'];

						if($cnt>0)
						{
							$update_qry = mysqli_query($connect, "UPDATE  `all_reverted_info` SET `is_reverted`='1', `last_reverted_by`='".$logged_in_user."',`updated_at`=now()  WHERE event_id='".$event_id."' and operation_type='Master'");
						}else
						{
							$insert_query = mysqli_query($connect,"INSERT INTO `all_reverted_info` (`operation_type`,`tanent_id`,`event_id`,`is_reverted`,`last_reverted_by`) VALUES ('Master','0','".$event_id."',1,'".$logged_in_user."')");
						}

					}

				$fetch_resource_details ="INSERT INTO `all_masters` (`tanent_id`,`master_name`,`phone`,`master_type`,`email_id`, `company`,`job_title`,`linkedin_url`,`event_id`,`twitter_url`,`is_approved`) 

				select tanent_id,master_name,phone,master_type,email_id,company,job_title,linkedin_url,event_id,twitter_url,is_approved from all_masters_upload_temp WHERE id='".$resource_id."' and  `event_id` = '".$event_id."' and is_duplicate=0";

				mysqli_query($connect,$fetch_resource_details);

				$result_qry1 = mysqli_query($connect,"select count(id) as spk_cnt from all_masters_upload_temp WHERE id='".$resource_id."' and  `event_id` = '".$event_id."' and is_duplicate=0");
				$result_qry_row1 = mysqli_fetch_array($result_qry1);
				$total_spk_cnt = $result_qry_row1['spk_cnt'];

				for($i=0;$i<$total_spk_cnt;$i++)
				{
					//**** add log
					mysqli_query($connect, "INSERT INTO all_crud_logs(tanent_id,event_id,operation,action_pk_id,created_by,created_at,sql_qry) VALUES ('".$session_tanent_id."','".$event_id."','create master','0','".$logged_in_user."',now(),'created master from excel upload')");

				}
			}

		  }
		}
			

	if($fetch_resource_details){
			//updaing master counts
		$all_masters_count_sp = calculate_master_dashboard_count($event_id);
		//****************   calculating master types counts **********************//
		$masters_data1 = mysqli_query($connect,"SELECT group_concat(id) as type_id FROM all_master_types WHERE event_id = '".$event_id."' ");
            if(mysqli_num_rows($masters_data1) > 0)
            {  
                $res1 = mysqli_fetch_array($masters_data1);
                $row_id = $res1['type_id'];
                $status_ids_array1 = explode(",",$row_id);

                foreach ($status_ids_array1 as $typeid) { 
                if($typeid!=0)
                {

                    $query_sql_sp = mysqli_query($connect,"SELECT count(*) as count_masters FROM all_masters WHERE find_in_set('".$typeid."',all_masters.master_type) and all_masters.event_id='".$event_id."'");
                    $query_res_sp = mysqli_fetch_array($query_sql_sp);
                    $count_master_res = mysqli_real_escape_string($connect,$query_res_sp['count_masters']);
                
                    $update_status_details = mysqli_query($connect, "UPDATE `all_master_types` SET `total_masters_enrolled`='".$count_master_res."'   WHERE id=".$typeid);

                }

             }
           }
		echo 'success';
	}else{
		echo 'failed';
	}
}

function master_upload_cancel(){

	$connect = $GLOBALS['connect'];
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);

	mysqli_query($connect, "INSERT INTO all_logs(operation,table_name,created_by,event_id) VALUES ('Cancel upload masters','all_masters','".$logged_in_user."','".$event_id."')");
	$speakers_data1 =mysqli_query($connect, "DELETE FROM all_masters_upload_temp WHERE event_id=".$event_id."");;
		
	if($speakers_data1){
		echo 'success';
	}else{
		echo 'failed';
	}
}


function master_upload_revert(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
		$logged_in_user= $_SESSION['user_id'];	
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);

	mysqli_query($connect, "INSERT INTO all_logs(operation,table_name,created_by,event_id) VALUES ('Revert upload masters','all_masters','".$logged_in_user."','".$event_id."')");

	mysqli_query($connect,"SET SESSION group_concat_max_len = 1000000");
	$speakers_data1 = mysqli_query($connect,"SELECT group_concat(master_id) as master_id FROM all_masters_upload_bkp WHERE event_id = '".$event_id."' ");
			if(mysqli_num_rows($speakers_data1) > 0)
       		{  
       			$query_sql_cnt_bkp = mysqli_query($connect,"SELECT count(id) as bkp_count FROM all_masters_upload_bkp WHERE event_id='".$event_id."'");
				 $query_res_bkp = mysqli_fetch_array($query_sql_cnt_bkp);
				 $all_bkp_count = $query_res_bkp['bkp_count'];
				 if($all_bkp_count>0)
				 {
       				$fetch_resource_details = mysqli_query($connect, "DELETE FROM all_masters WHERE id NOT IN (select master_id from all_masters_upload_bkp where event_id='".$event_id."') AND event_id='".$event_id."'");
       			}

			   	$res1 = mysqli_fetch_array($speakers_data1);
			   	$row_id = $res1['master_id'];
			   	$resource_ids_array1 = explode(",",$row_id);

			   	$result_qry = mysqli_query($connect,"select count(id) as exist_cnt  from all_reverted_info where event_id='".$event_id."' and operation_type='Master'");
				$result_qry_row = mysqli_fetch_array($result_qry);
				$cnt = $result_qry_row['exist_cnt'];

				if($cnt>0)
				{
					$update_qry = mysqli_query($connect, "UPDATE  `all_reverted_info` SET `is_reverted`='0', `last_reverted_by`='".$logged_in_user."',`updated_at`=now()  WHERE event_id='".$event_id."' and operation_type='Master'");
				}else
				{
					$insert_query = mysqli_query($connect,"INSERT INTO `all_reverted_info` (`operation_type`,`tanent_id`,`event_id`,`is_reverted`,`last_reverted_by`) VALUES ('Master','0','".$event_id."',0,'".$logged_in_user."')");
				}

			   	foreach ($resource_ids_array1 as $masterid) {

			   		$query_sql_sp = mysqli_query($connect,"select * from all_masters_upload_bkp WHERE `master_id`='".$masterid."'");
			   		$query_res_sp = mysqli_fetch_array($query_sql_sp);
		            $name = mysqli_real_escape_string($connect,$query_res_sp['master_name']);
		            $email = mysqli_real_escape_string($connect,$query_res_sp['email_id']);
		            $company = mysqli_real_escape_string($connect,$query_res_sp['company']);
		            $phone = mysqli_real_escape_string($connect,$query_res_sp['phone']);
		            $master_types_value = mysqli_real_escape_string($connect,$query_res_sp['master_type']);
		            $job_title = mysqli_real_escape_string($connect,$query_res_sp['job_title']);
		            $linkedin_url = mysqli_real_escape_string($connect,$query_res_sp['linkedin_url']);
		        	

			   		$fetch_resource_details = mysqli_query($connect, "UPDATE  `all_masters` SET `master_name`='".$name."', `email_id`='".$email."', `company`='".$company."',`phone`='".$phone."',`master_type`= '".$master_types_value."',`job_title`='".$job_title."',`linkedin_url` = '".$linkedin_url."'  WHERE id=".$masterid);;

			   		if($fetch_resource_details){
			   		mysqli_query($connect, "DELETE FROM all_masters_upload_bkp WHERE event_id='".$event_id."' and master_id='".$masterid."'");
			   		}
			   		echo 'success';

		  }
		}

	//if($fetch_resource_details){
		
	// }else{
	// 	echo 'failed';
	// }
}

function master_get_revert_flag_data(){

	$connect = $GLOBALS['connect'];
	$event_id =  $_POST['event_id'];

	 $query_sql = mysqli_query($connect,"SELECT ifnull(max(created_at),0) as last_created_at FROM all_crud_logs WHERE operation='upload masters' and event_id='".$event_id."'");
	 $query_res = mysqli_fetch_array($query_sql);
	 $last_created_at = $query_res['last_created_at'];

	 if($last_created_at!=0)
	 {
	 	 	  $now = time(); // or your date as well
		      $your_date = strtotime($last_created_at);
		      $datediff = $now - $your_date;
		      $final_days= round($datediff / (60 * 60 * 24));
		      
		    if($final_days < 7){
			 	$fetch_notes = mysqli_query($connect,"SELECT count(*) as is_sent,(select ifnull(max(is_reverted),0) from all_reverted_info where event_id='".$event_id."' and operation_type='Master') as is_revert_flag,
			 		(select count(id) from tbl_sendlatermaildetails where createdon>'".$last_created_at."' and event_id='".$event_id."' and (type='Master' OR type='Master-bulkmail')) as scheduld_cnt
			 	 FROM all_logs WHERE event_id = '".$event_id."' AND created_at>'".$last_created_at."' AND (all_logs.operation='sent email to master' OR all_logs.operation='sent email to master scheduled') ");
			 }else
			 {
			 	$fetch_notes = mysqli_query($connect,"SELECT 0 as is_sent,0 as is_revert_flag FROM all_logs");
			 }

	 }else
	 {
	 	$fetch_notes = mysqli_query($connect,"SELECT 0 as is_sent,0 as is_revert_flag FROM all_logs");
	 }

	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function StatusNameCheck(){
	$connect = $GLOBALS['connect'];
	$status_name =  mysqli_real_escape_string($connect, $_POST['status']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	 // $id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"SELECT * from all_status where status_name = '".$status_name."' AND (event_id = '".$event_id."' OR default_flag=1) ");
	 echo $count = mysqli_num_rows($sql);
	}

function StatusNameCheck_for_edit(){
	$connect = $GLOBALS['connect'];
	$status_name =  mysqli_real_escape_string($connect, $_POST['status']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	$id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"SELECT * from all_status where status_name = '".$status_name."' AND (event_id = '".$event_id."' OR default_flag=1) AND id != '".$id."' ");
	 echo $count = mysqli_num_rows($sql);
	}

function speaker_type_NameCheck(){
	$connect = $GLOBALS['connect'];
	$speaker_type_name =  mysqli_real_escape_string($connect, $_POST['speaker_type_name']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);

	$sql = mysqli_query($connect,"SELECT * from all_speaker_types where speaker_type_name = '".$speaker_type_name."' AND (event_id = '".$event_id."' OR Isdefault=1) ");
	 echo $count = mysqli_num_rows($sql);
	}

function speaker_type_NameCheck_for_edit(){
	$connect = $GLOBALS['connect'];
	$speaker_type_name =  mysqli_real_escape_string($connect, $_POST['speaker_type_name']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	$id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"SELECT * from all_speaker_types where speaker_type_name = '".$speaker_type_name."' AND (event_id = '".$event_id."' OR Isdefault=1) AND id != '".$id."' ");
	 echo $count = mysqli_num_rows($sql);
	}

function master_type_Check(){
	$connect = $GLOBALS['connect'];
	$master_type_name =  mysqli_real_escape_string($connect, $_POST['master_type_name']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	 // $id =  mysqli_real_escape_string($connect, $_POST['id']);
	$sql = mysqli_query($connect,"SELECT * from all_master_types where master_type_name = '".$master_type_name."' AND (event_id = '".$event_id."' OR is_default=1) ");
	 echo $count = mysqli_num_rows($sql);
	}

function master_type_Check_for_edit(){
	$connect = $GLOBALS['connect'];
	$master_type_name =  mysqli_real_escape_string($connect, $_POST['master_type_name']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	$id =  mysqli_real_escape_string($connect, $_POST['id']);

	$sql = mysqli_query($connect,"SELECT * from all_master_types where master_type_name = '".$master_type_name."' AND (event_id = '".$event_id."' OR is_default=1) AND id != '".$id."' ");
	 echo $count = mysqli_num_rows($sql);
	}

function speaker_email_check(){
	$connect = $GLOBALS['connect'];
	$speaker_email_address =  mysqli_real_escape_string($connect, $_POST['speaker_email_address']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);

	$sql = mysqli_query($connect,"SELECT * from all_speakers where email_id = '".$speaker_email_address."' AND event_id = '".$event_id."'");
	 echo $count = mysqli_num_rows($sql);
	}

function speaker_email_check_for_edit(){
	$connect = $GLOBALS['connect'];
	$speaker_email_address =  mysqli_real_escape_string($connect, $_POST['speaker_email_address']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	$id =  mysqli_real_escape_string($connect, $_POST['id']);

	$sql = mysqli_query($connect,"SELECT * from all_speakers where email_id = '".$speaker_email_address."' AND event_id = '".$event_id."' AND id != '".$id."'");
	
	  echo $count = mysqli_num_rows($sql);
	}

function master_email_check(){
	$connect = $GLOBALS['connect'];
	$master_email_address =  mysqli_real_escape_string($connect, $_POST['master_email_address']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);

	$sql = mysqli_query($connect,"SELECT * from all_masters where email_id = '".$master_email_address."' AND event_id = '".$event_id."'");
	 echo $count = mysqli_num_rows($sql);
	}

function master_email_check_for_edit(){
	$connect = $GLOBALS['connect'];
	$master_email_address =  mysqli_real_escape_string($connect, $_POST['master_email_address']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);
	$id =  mysqli_real_escape_string($connect, $_POST['id']);

	$sql = mysqli_query($connect,"SELECT * from all_masters where email_id = '".$master_email_address."' AND event_id = '".$event_id."' AND id != '".$id."'");
	 echo $count = mysqli_num_rows($sql);
	}

	function check_sponsor_contact_email_address(){
		
	$connect = $GLOBALS['connect'];
	$final_array = array();
	$sponsor_contact_email_address = trim(mysqli_real_escape_string($connect, $_POST['sponsor_contact_email_address']) );
	$event_id = trim(mysqli_real_escape_string($connect, $_POST['event_id']) );

	$check_duplicate = mysqli_query($connect,"SELECT * FROM `all_sponsors` where `sponsor_contact_email_address`= '".$sponsor_contact_email_address."' and `event_id`= '".$event_id."'  ");
	echo $count = mysqli_num_rows($check_duplicate);

	
	// if(mysqli_num_rows($check_duplicate) > 0){
	// 	$inner_array = array();
	// 		$inner_array['status'] = 'success';
	// 		$inner_array['status_code'] = 200;
	// 		$inner_array['is_duplicate'] = true;	
	// 		$final_array[] = $inner_array;
	// 		echo json_encode($final_array);

	// }else{
	// 	$inner_array = array();
	// 	$inner_array['status'] = 'failed';
	// 	$inner_array['status_code'] = 400;
	// 	$inner_array['is_duplicate'] = false;
	// 	$final_array[] = $inner_array;
	// 	echo json_encode($final_array);
	// }
}

function fetch_speakers_for_popup(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
	$user_id= $_SESSION['user_id'];	
	$event_id =  $_POST['event_id'];

	$fetch_notes = mysqli_query($connect,"select als.event_id,als.id,als.speaker_name,als.email_id,als.company,als.phone,(select status_name from all_status where id=als.`status`) as status_name,ifnull(als.social_media_total_score,0) as social_media_total_score
                from all_speakers als,all_users au where FIND_IN_SET(als.event_id, au.event_id)  AND  au.user_id='".$user_id."' and  als.event_id not in ('".$event_id."') and als.email_id not in (select email_id from  all_speakers where event_id='".$event_id."') group by als.email_id having count(*)>0");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function fetch_sponsors_for_popup(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
	$user_id= $_SESSION['user_id'];	
	$event_id =  $_POST['event_id'];

	$fetch_notes = mysqli_query($connect,"select id,sponsor_company_name,sponsor_contact_person,sponsor_contact_email_address,sponsor_contact_number,(select status_name from all_status where id=all_sponsors.`status`) as status_name,(select GROUP_CONCAT(d.sponsor_type_name) as sponsor_types from all_sponsor_types d where find_in_set(d.id,all_sponsors.sponsor_type)) as sponsor_types from all_sponsors,all_users where FIND_IN_SET(all_sponsors.event_id, all_users.event_id)  AND  all_users.user_id='".$user_id."' and all_sponsors.event_id not in ('".$event_id."') and all_sponsors.sponsor_contact_email_address not in (select sponsor_contact_email_address from  all_sponsors where event_id='".$event_id."') group by all_sponsors.sponsor_contact_email_address having count(*)>0");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}	

function fetch_masters_for_popup(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
	$user_id= $_SESSION['user_id'];	
	$event_id =  $_POST['event_id'];

	$fetch_notes = mysqli_query($connect,"select am.id,am.master_name,am.email_id,am.company,am.job_title from all_masters am,all_users au where FIND_IN_SET(am.event_id, au.event_id)  AND  au.user_id='".$user_id."' and am.event_id not in ('".$event_id."') and am.email_id not in (select email_id from  all_masters where event_id='".$event_id."') group by am.email_id having count(*)>0");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function fetch_speakers_for_total_spk_listing(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
	$user_id= $_SESSION['user_id'];	
	$fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
    $res_sql = mysqli_fetch_array($fetch_sql);
    $tanent_id= $res_sql['tanent_id'];

    $fetch_notes = mysqli_query($connect,"SELECT als.id,als.speaker_name,als.email_id,als.company,als.phone,als.social_media_total_score,(SELECT event_name from all_events where all_events.id=als.event_id) as participated from all_speakers als WHERE tanent_id='".$tanent_id."'");
	// $fetch_notes = mysqli_query($connect,"SELECT als.id,als.speaker_name,als.email_id,als.company,als.phone,als.social_media_total_score,(SELECT event_name from all_events where all_events.id=als.event_id) as participated from all_speakers als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."'  and als.event_id != 0 AND als.event_id != '' AND als.email_id!=''");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}	

function fetch_speakers_for_total_sponsor_listing(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
	$user_id= $_SESSION['user_id'];	
	$fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
    $res_sql = mysqli_fetch_array($fetch_sql);
    $tanent_id= $res_sql['tanent_id'];

    $fetch_notes = mysqli_query($connect,"SELECT als.id,als.sponsor_company_name,als.sponsor_contact_person,als.sponsor_contact_email_address,als.sponsor_contact_number,(SELECT event_name from all_events where all_events.id=als.event_id) as participated from all_sponsors als WHERE tanent_id='".$tanent_id."'");
	// $fetch_notes = mysqli_query($connect,"SELECT als.id,als.sponsor_company_name,als.sponsor_contact_person,als.sponsor_contact_email_address,als.sponsor_contact_number,(SELECT event_name from all_events where all_events.id=als.event_id) as participated from all_sponsors als,all_users au where FIND_IN_SET(als.event_id, au.event_id) AND  au.user_id='".$user_id."'  and als.sponsor_contact_email_address !='' AND als.event_id != ''");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}	


function fetch_email_templates_for_popup(){

	$connect = $GLOBALS['connect'];
	if(!isset($_SESSION)){ session_start(); }
	$user_id= $_SESSION['user_id'];	
	$event_id =  $_POST['event_id'];
	$fetch_sql = mysqli_query($connect,"SELECT tanent_id from all_users where user_id='".$user_id."' ");
    $res_sql = mysqli_fetch_array($fetch_sql);
    $tanent_id= $res_sql['tanent_id'];

	$fetch_notes = mysqli_query($connect,"SELECT * FROM (select id,template_name,template_type,
	(select event_name from all_events where id=all_email_templates.event_id) as event_name,
	(select GROUP_CONCAT(d.status_name) as status_names from all_status d where find_in_set(d.id,all_email_templates.status_id)) as status_names from all_email_templates where (event_id!='all' AND event_id!='".$event_id."' AND tanent_id='".$tanent_id."') and template_name not in  (select template_name from  all_email_templates where event_id='".$event_id."') order by updated_date desc) AS t GROUP BY template_name having count(*)>0");
	
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function add_new_coloboration_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$uniq_token = mysqli_real_escape_string($connect, $_POST['uniq_token']);

	$insert_note = mysqli_query($connect,"INSERT INTO new_coloboration_notes(notes,uniqueid,created_by) VALUES('$note_val','$uniq_token','$loggedin_userid') ");
	if($insert_note){
		echo 'success';
	}else{
		echo 'failed';
	}
}

function fetch_coloboration_notes_by_uniqueid(){

	$connect = $GLOBALS['connect'];
	 $uniq_token =  $_POST['uniq_token'];

	$fetch_notes = mysqli_query($connect,"SELECT sn.id as id, sn.notes, sn.uniqueid as speaker_id, sn.created_by,STR_TO_DATE(sn.created_at, '%Y-%m-$d') as created_at,date_format(sn.created_at, '%d-%b-%Y') as createdon, au.first_name as created_by_name  FROM new_coloboration_notes sn, all_users au WHERE au.user_id = sn.created_by AND  sn.uniqueid ='$uniq_token' ORDER BY sn.id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function update_new_coloboration_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$uniq_token = mysqli_real_escape_string($connect, $_POST['uniq_token']);
	$note_id = mysqli_real_escape_string($connect, $_POST['note_id']);
	$current_time = date('Y-m-d H:i:s');

	$update_note = mysqli_query($connect,"UPDATE new_coloboration_notes SET notes ='$note_val',created_by='$loggedin_userid',created_at = '$current_time',is_updated = '1' WHERE uniqueid = '$uniq_token' AND id  = '$note_id' ");
	if($update_note){
		echo 'success';
	}else{
		echo 'failed';
	}

}

function update_ep_colb_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$ep_id = mysqli_real_escape_string($connect, $_POST['ep_id']);
	$note_id = mysqli_real_escape_string($connect, $_POST['note_id']);
	$current_time = date('Y-m-d H:i:s');

	$update_note = mysqli_query($connect,"UPDATE event_presentation_coloboration_notes SET notes ='$note_val',created_by='$loggedin_userid',created_at = '$current_time' WHERE ep_id = '$ep_id' AND id  = '$note_id' ");
	if($update_note){
		echo 'success';
	}else{
		echo 'failed';
	}

}

function fetch_ep_coloboration_notes_by_id(){

	$connect = $GLOBALS['connect'];
	 $ep_id =  $_POST['ep_id'];
	$fetch_notes = mysqli_query($connect,"SELECT epn.id,epn.notes,epn.event_id,epn.ep_id,date_format(epn.created_at, '%d-%b-%Y') as created_at,ifnull((select speaker_name from all_speakers where id=epn.created_by), (select first_name from all_users where user_id=epn.created_by)) as addedby FROM event_presentation_coloboration_notes epn WHERE ep_id ='".$ep_id."' ORDER BY id DESC ");
	$res_array = array();
	if(mysqli_num_rows($fetch_notes) > 0){
		
		while ($res = mysqli_fetch_array($fetch_notes)) { 
			$res_array[] = $res;
		}
	}
	 echo json_encode($res_array);
}

function add_ep_colloboration_note(){

	$connect = $GLOBALS['connect'];
	$note_val = mysqli_real_escape_string($connect, $_POST['note_val']);
	$loggedin_userid = mysqli_real_escape_string($connect, $_POST['loggedin_userid']);
	$ep_id = mysqli_real_escape_string($connect, $_POST['ep_id']);
	$event_id = mysqli_real_escape_string($connect, $_POST['event_id']);

	$insert_note = mysqli_query($connect,"INSERT INTO event_presentation_coloboration_notes(notes,event_id,ep_id,created_by) VALUES('$note_val','$event_id','$ep_id','$loggedin_userid') ");
	if($insert_note){
		echo 'success';
	}else{
		echo 'failed';
	}
}

?>